var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to2, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to2, key) && key !== except)
        __defProp(to2, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to2;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/api.ts
var api_exports = {};
__export(api_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(api_exports);

// node_modules/hono/dist/compose.js
var compose = (middleware, onError, onNotFound) => {
  return (context, next) => {
    let index = -1;
    return dispatch(0);
    async function dispatch(i) {
      if (i <= index) {
        throw new Error("next() called multiple times");
      }
      index = i;
      let res;
      let isError = false;
      let handler2;
      if (middleware[i]) {
        handler2 = middleware[i][0][0];
        context.req.routeIndex = i;
      } else {
        handler2 = i === middleware.length && next || void 0;
      }
      if (handler2) {
        try {
          res = await handler2(context, () => dispatch(i + 1));
        } catch (err) {
          if (err instanceof Error && onError) {
            context.error = err;
            res = await onError(err, context);
            isError = true;
          } else {
            throw err;
          }
        }
      } else {
        if (context.finalized === false && onNotFound) {
          res = await onNotFound(context);
        }
      }
      if (res && (context.finalized === false || isError)) {
        context.res = res;
      }
      return context;
    }
  };
};

// node_modules/hono/dist/request/constants.js
var GET_MATCH_RESULT = /* @__PURE__ */ Symbol();

// node_modules/hono/dist/utils/body.js
var parseBody = async (request, options = /* @__PURE__ */ Object.create(null)) => {
  const { all = false, dot = false } = options;
  const headers = request instanceof HonoRequest ? request.raw.headers : request.headers;
  const contentType = headers.get("Content-Type");
  if (contentType?.startsWith("multipart/form-data") || contentType?.startsWith("application/x-www-form-urlencoded")) {
    return parseFormData(request, { all, dot });
  }
  return {};
};
async function parseFormData(request, options) {
  const formData = await request.formData();
  if (formData) {
    return convertFormDataToBodyData(formData, options);
  }
  return {};
}
function convertFormDataToBodyData(formData, options) {
  const form = /* @__PURE__ */ Object.create(null);
  formData.forEach((value, key) => {
    const shouldParseAllValues = options.all || key.endsWith("[]");
    if (!shouldParseAllValues) {
      form[key] = value;
    } else {
      handleParsingAllValues(form, key, value);
    }
  });
  if (options.dot) {
    Object.entries(form).forEach(([key, value]) => {
      const shouldParseDotValues = key.includes(".");
      if (shouldParseDotValues) {
        handleParsingNestedValues(form, key, value);
        delete form[key];
      }
    });
  }
  return form;
}
var handleParsingAllValues = (form, key, value) => {
  if (form[key] !== void 0) {
    if (Array.isArray(form[key])) {
      ;
      form[key].push(value);
    } else {
      form[key] = [form[key], value];
    }
  } else {
    if (!key.endsWith("[]")) {
      form[key] = value;
    } else {
      form[key] = [value];
    }
  }
};
var handleParsingNestedValues = (form, key, value) => {
  if (/(?:^|\.)__proto__\./.test(key)) {
    return;
  }
  let nestedForm = form;
  const keys = key.split(".");
  keys.forEach((key2, index) => {
    if (index === keys.length - 1) {
      nestedForm[key2] = value;
    } else {
      if (!nestedForm[key2] || typeof nestedForm[key2] !== "object" || Array.isArray(nestedForm[key2]) || nestedForm[key2] instanceof File) {
        nestedForm[key2] = /* @__PURE__ */ Object.create(null);
      }
      nestedForm = nestedForm[key2];
    }
  });
};

// node_modules/hono/dist/utils/url.js
var splitPath = (path3) => {
  const paths = path3.split("/");
  if (paths[0] === "") {
    paths.shift();
  }
  return paths;
};
var splitRoutingPath = (routePath) => {
  const { groups, path: path3 } = extractGroupsFromPath(routePath);
  const paths = splitPath(path3);
  return replaceGroupMarks(paths, groups);
};
var extractGroupsFromPath = (path3) => {
  const groups = [];
  path3 = path3.replace(/\{[^}]+\}/g, (match2, index) => {
    const mark = `@${index}`;
    groups.push([mark, match2]);
    return mark;
  });
  return { groups, path: path3 };
};
var replaceGroupMarks = (paths, groups) => {
  for (let i = groups.length - 1; i >= 0; i--) {
    const [mark] = groups[i];
    for (let j = paths.length - 1; j >= 0; j--) {
      if (paths[j].includes(mark)) {
        paths[j] = paths[j].replace(mark, groups[i][1]);
        break;
      }
    }
  }
  return paths;
};
var patternCache = {};
var getPattern = (label, next) => {
  if (label === "*") {
    return "*";
  }
  const match2 = label.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/);
  if (match2) {
    const cacheKey = `${label}#${next}`;
    if (!patternCache[cacheKey]) {
      if (match2[2]) {
        patternCache[cacheKey] = next && next[0] !== ":" && next[0] !== "*" ? [cacheKey, match2[1], new RegExp(`^${match2[2]}(?=/${next})`)] : [label, match2[1], new RegExp(`^${match2[2]}$`)];
      } else {
        patternCache[cacheKey] = [label, match2[1], true];
      }
    }
    return patternCache[cacheKey];
  }
  return null;
};
var tryDecode = (str, decoder) => {
  try {
    return decoder(str);
  } catch {
    return str.replace(/(?:%[0-9A-Fa-f]{2})+/g, (match2) => {
      try {
        return decoder(match2);
      } catch {
        return match2;
      }
    });
  }
};
var tryDecodeURI = (str) => tryDecode(str, decodeURI);
var getPath = (request) => {
  const url = request.url;
  const start = url.indexOf("/", url.indexOf(":") + 4);
  let i = start;
  for (; i < url.length; i++) {
    const charCode = url.charCodeAt(i);
    if (charCode === 37) {
      const queryIndex = url.indexOf("?", i);
      const hashIndex = url.indexOf("#", i);
      const end = queryIndex === -1 ? hashIndex === -1 ? void 0 : hashIndex : hashIndex === -1 ? queryIndex : Math.min(queryIndex, hashIndex);
      const path3 = url.slice(start, end);
      return tryDecodeURI(path3.includes("%25") ? path3.replace(/%25/g, "%2525") : path3);
    } else if (charCode === 63 || charCode === 35) {
      break;
    }
  }
  return url.slice(start, i);
};
var getPathNoStrict = (request) => {
  const result = getPath(request);
  return result.length > 1 && result.at(-1) === "/" ? result.slice(0, -1) : result;
};
var mergePath = (base, sub, ...rest) => {
  if (rest.length) {
    sub = mergePath(sub, ...rest);
  }
  return `${base?.[0] === "/" ? "" : "/"}${base}${sub === "/" ? "" : `${base?.at(-1) === "/" ? "" : "/"}${sub?.[0] === "/" ? sub.slice(1) : sub}`}`;
};
var checkOptionalParameter = (path3) => {
  if (path3.charCodeAt(path3.length - 1) !== 63 || !path3.includes(":")) {
    return null;
  }
  const segments = path3.split("/");
  const results = [];
  let basePath = "";
  segments.forEach((segment) => {
    if (segment !== "" && !/\:/.test(segment)) {
      basePath += "/" + segment;
    } else if (/\:/.test(segment)) {
      if (/\?/.test(segment)) {
        if (results.length === 0 && basePath === "") {
          results.push("/");
        } else {
          results.push(basePath);
        }
        const optionalSegment = segment.replace("?", "");
        basePath += "/" + optionalSegment;
        results.push(basePath);
      } else {
        basePath += "/" + segment;
      }
    }
  });
  return results.filter((v2, i, a2) => a2.indexOf(v2) === i);
};
var _decodeURI = (value) => {
  if (!/[%+]/.test(value)) {
    return value;
  }
  if (value.indexOf("+") !== -1) {
    value = value.replace(/\+/g, " ");
  }
  return value.indexOf("%") !== -1 ? tryDecode(value, decodeURIComponent_) : value;
};
var _getQueryParam = (url, key, multiple) => {
  let encoded;
  if (!multiple && key && !/[%+]/.test(key)) {
    let keyIndex2 = url.indexOf("?", 8);
    if (keyIndex2 === -1) {
      return void 0;
    }
    if (!url.startsWith(key, keyIndex2 + 1)) {
      keyIndex2 = url.indexOf(`&${key}`, keyIndex2 + 1);
    }
    while (keyIndex2 !== -1) {
      const trailingKeyCode = url.charCodeAt(keyIndex2 + key.length + 1);
      if (trailingKeyCode === 61) {
        const valueIndex = keyIndex2 + key.length + 2;
        const endIndex = url.indexOf("&", valueIndex);
        return _decodeURI(url.slice(valueIndex, endIndex === -1 ? void 0 : endIndex));
      } else if (trailingKeyCode == 38 || isNaN(trailingKeyCode)) {
        return "";
      }
      keyIndex2 = url.indexOf(`&${key}`, keyIndex2 + 1);
    }
    encoded = /[%+]/.test(url);
    if (!encoded) {
      return void 0;
    }
  }
  const results = {};
  encoded ??= /[%+]/.test(url);
  let keyIndex = url.indexOf("?", 8);
  while (keyIndex !== -1) {
    const nextKeyIndex = url.indexOf("&", keyIndex + 1);
    let valueIndex = url.indexOf("=", keyIndex);
    if (valueIndex > nextKeyIndex && nextKeyIndex !== -1) {
      valueIndex = -1;
    }
    let name = url.slice(
      keyIndex + 1,
      valueIndex === -1 ? nextKeyIndex === -1 ? void 0 : nextKeyIndex : valueIndex
    );
    if (encoded) {
      name = _decodeURI(name);
    }
    keyIndex = nextKeyIndex;
    if (name === "") {
      continue;
    }
    let value;
    if (valueIndex === -1) {
      value = "";
    } else {
      value = url.slice(valueIndex + 1, nextKeyIndex === -1 ? void 0 : nextKeyIndex);
      if (encoded) {
        value = _decodeURI(value);
      }
    }
    if (multiple) {
      if (!(results[name] && Array.isArray(results[name]))) {
        results[name] = [];
      }
      ;
      results[name].push(value);
    } else {
      results[name] ??= value;
    }
  }
  return key ? results[key] : results;
};
var getQueryParam = _getQueryParam;
var getQueryParams = (url, key) => {
  return _getQueryParam(url, key, true);
};
var decodeURIComponent_ = decodeURIComponent;

// node_modules/hono/dist/request.js
var tryDecodeURIComponent = (str) => tryDecode(str, decodeURIComponent_);
var HonoRequest = class {
  /**
   * `.raw` can get the raw Request object.
   *
   * @see {@link https://hono.dev/docs/api/request#raw}
   *
   * @example
   * ```ts
   * // For Cloudflare Workers
   * app.post('/', async (c) => {
   *   const metadata = c.req.raw.cf?.hostMetadata?
   *   ...
   * })
   * ```
   */
  raw;
  #validatedData;
  // Short name of validatedData
  #matchResult;
  routeIndex = 0;
  /**
   * `.path` can get the pathname of the request.
   *
   * @see {@link https://hono.dev/docs/api/request#path}
   *
   * @example
   * ```ts
   * app.get('/about/me', (c) => {
   *   const pathname = c.req.path // `/about/me`
   * })
   * ```
   */
  path;
  bodyCache = {};
  constructor(request, path3 = "/", matchResult = [[]]) {
    this.raw = request;
    this.path = path3;
    this.#matchResult = matchResult;
    this.#validatedData = {};
  }
  param(key) {
    return key ? this.#getDecodedParam(key) : this.#getAllDecodedParams();
  }
  #getDecodedParam(key) {
    const paramKey = this.#matchResult[0][this.routeIndex][1][key];
    const param = this.#getParamValue(paramKey);
    return param && /\%/.test(param) ? tryDecodeURIComponent(param) : param;
  }
  #getAllDecodedParams() {
    const decoded = {};
    const keys = Object.keys(this.#matchResult[0][this.routeIndex][1]);
    for (const key of keys) {
      const value = this.#getParamValue(this.#matchResult[0][this.routeIndex][1][key]);
      if (value !== void 0) {
        decoded[key] = /\%/.test(value) ? tryDecodeURIComponent(value) : value;
      }
    }
    return decoded;
  }
  #getParamValue(paramKey) {
    return this.#matchResult[1] ? this.#matchResult[1][paramKey] : paramKey;
  }
  query(key) {
    return getQueryParam(this.url, key);
  }
  queries(key) {
    return getQueryParams(this.url, key);
  }
  header(name) {
    if (name) {
      return this.raw.headers.get(name) ?? void 0;
    }
    const headerData = {};
    this.raw.headers.forEach((value, key) => {
      headerData[key] = value;
    });
    return headerData;
  }
  async parseBody(options) {
    return parseBody(this, options);
  }
  #cachedBody = (key) => {
    const { bodyCache, raw: raw2 } = this;
    const cachedBody = bodyCache[key];
    if (cachedBody) {
      return cachedBody;
    }
    const anyCachedKey = Object.keys(bodyCache)[0];
    if (anyCachedKey) {
      return bodyCache[anyCachedKey].then((body) => {
        if (anyCachedKey === "json") {
          body = JSON.stringify(body);
        }
        return new Response(body)[key]();
      });
    }
    return bodyCache[key] = raw2[key]();
  };
  /**
   * `.json()` can parse Request body of type `application/json`
   *
   * @see {@link https://hono.dev/docs/api/request#json}
   *
   * @example
   * ```ts
   * app.post('/entry', async (c) => {
   *   const body = await c.req.json()
   * })
   * ```
   */
  json() {
    return this.#cachedBody("text").then((text) => JSON.parse(text));
  }
  /**
   * `.text()` can parse Request body of type `text/plain`
   *
   * @see {@link https://hono.dev/docs/api/request#text}
   *
   * @example
   * ```ts
   * app.post('/entry', async (c) => {
   *   const body = await c.req.text()
   * })
   * ```
   */
  text() {
    return this.#cachedBody("text");
  }
  /**
   * `.arrayBuffer()` parse Request body as an `ArrayBuffer`
   *
   * @see {@link https://hono.dev/docs/api/request#arraybuffer}
   *
   * @example
   * ```ts
   * app.post('/entry', async (c) => {
   *   const body = await c.req.arrayBuffer()
   * })
   * ```
   */
  arrayBuffer() {
    return this.#cachedBody("arrayBuffer");
  }
  /**
   * `.bytes()` parses the request body as a `Uint8Array`.
   *
   * @see {@link https://hono.dev/docs/api/request#bytes}
   *
   * @example
   * ```ts
   * app.post('/entry', async (c) => {
   *   const body = await c.req.bytes()
   * })
   * ```
   */
  bytes() {
    return this.#cachedBody("arrayBuffer").then((buffer) => new Uint8Array(buffer));
  }
  /**
   * Parses the request body as a `Blob`.
   * @example
   * ```ts
   * app.post('/entry', async (c) => {
   *   const body = await c.req.blob();
   * });
   * ```
   * @see https://hono.dev/docs/api/request#blob
   */
  blob() {
    return this.#cachedBody("blob");
  }
  /**
   * Parses the request body as `FormData`.
   * @example
   * ```ts
   * app.post('/entry', async (c) => {
   *   const body = await c.req.formData();
   * });
   * ```
   * @see https://hono.dev/docs/api/request#formdata
   */
  formData() {
    return this.#cachedBody("formData");
  }
  /**
   * Adds validated data to the request.
   *
   * @param target - The target of the validation.
   * @param data - The validated data to add.
   */
  addValidatedData(target, data) {
    this.#validatedData[target] = data;
  }
  valid(target) {
    return this.#validatedData[target];
  }
  /**
   * `.url()` can get the request url strings.
   *
   * @see {@link https://hono.dev/docs/api/request#url}
   *
   * @example
   * ```ts
   * app.get('/about/me', (c) => {
   *   const url = c.req.url // `http://localhost:8787/about/me`
   *   ...
   * })
   * ```
   */
  get url() {
    return this.raw.url;
  }
  /**
   * `.method()` can get the method name of the request.
   *
   * @see {@link https://hono.dev/docs/api/request#method}
   *
   * @example
   * ```ts
   * app.get('/about/me', (c) => {
   *   const method = c.req.method // `GET`
   * })
   * ```
   */
  get method() {
    return this.raw.method;
  }
  get [GET_MATCH_RESULT]() {
    return this.#matchResult;
  }
  /**
   * `.matchedRoutes()` can return a matched route in the handler
   *
   * @deprecated
   *
   * Use matchedRoutes helper defined in "hono/route" instead.
   *
   * @see {@link https://hono.dev/docs/api/request#matchedroutes}
   *
   * @example
   * ```ts
   * app.use('*', async function logger(c, next) {
   *   await next()
   *   c.req.matchedRoutes.forEach(({ handler, method, path }, i) => {
   *     const name = handler.name || (handler.length < 2 ? '[handler]' : '[middleware]')
   *     console.log(
   *       method,
   *       ' ',
   *       path,
   *       ' '.repeat(Math.max(10 - path.length, 0)),
   *       name,
   *       i === c.req.routeIndex ? '<- respond from here' : ''
   *     )
   *   })
   * })
   * ```
   */
  get matchedRoutes() {
    return this.#matchResult[0].map(([[, route]]) => route);
  }
  /**
   * `routePath()` can retrieve the path registered within the handler
   *
   * @deprecated
   *
   * Use routePath helper defined in "hono/route" instead.
   *
   * @see {@link https://hono.dev/docs/api/request#routepath}
   *
   * @example
   * ```ts
   * app.get('/posts/:id', (c) => {
   *   return c.json({ path: c.req.routePath })
   * })
   * ```
   */
  get routePath() {
    return this.#matchResult[0].map(([[, route]]) => route)[this.routeIndex].path;
  }
};

// node_modules/hono/dist/utils/html.js
var HtmlEscapedCallbackPhase = {
  Stringify: 1,
  BeforeStream: 2,
  Stream: 3
};
var raw = (value, callbacks) => {
  const escapedString = new String(value);
  escapedString.isEscaped = true;
  escapedString.callbacks = callbacks;
  return escapedString;
};
var resolveCallback = async (str, phase, preserveCallbacks, context, buffer) => {
  if (typeof str === "object" && !(str instanceof String)) {
    if (!(str instanceof Promise)) {
      str = str.toString();
    }
    if (str instanceof Promise) {
      str = await str;
    }
  }
  const callbacks = str.callbacks;
  if (!callbacks?.length) {
    return Promise.resolve(str);
  }
  if (buffer) {
    buffer[0] += str;
  } else {
    buffer = [str];
  }
  const resStr = Promise.all(callbacks.map((c) => c({ phase, buffer, context }))).then(
    (res) => Promise.all(
      res.filter(Boolean).map((str2) => resolveCallback(str2, phase, false, context, buffer))
    ).then(() => buffer[0])
  );
  if (preserveCallbacks) {
    return raw(await resStr, callbacks);
  } else {
    return resStr;
  }
};

// node_modules/hono/dist/context.js
var TEXT_PLAIN = "text/plain; charset=UTF-8";
var setDefaultContentType = (contentType, headers) => {
  return {
    "Content-Type": contentType,
    ...headers
  };
};
var createResponseInstance = (body, init) => new Response(body, init);
var Context = class {
  #rawRequest;
  #req;
  /**
   * `.env` can get bindings (environment variables, secrets, KV namespaces, D1 database, R2 bucket etc.) in Cloudflare Workers.
   *
   * @see {@link https://hono.dev/docs/api/context#env}
   *
   * @example
   * ```ts
   * // Environment object for Cloudflare Workers
   * app.get('*', async c => {
   *   const counter = c.env.COUNTER
   * })
   * ```
   */
  env = {};
  #var;
  finalized = false;
  /**
   * `.error` can get the error object from the middleware if the Handler throws an error.
   *
   * @see {@link https://hono.dev/docs/api/context#error}
   *
   * @example
   * ```ts
   * app.use('*', async (c, next) => {
   *   await next()
   *   if (c.error) {
   *     // do something...
   *   }
   * })
   * ```
   */
  error;
  #status;
  #executionCtx;
  #res;
  #layout;
  #renderer;
  #notFoundHandler;
  #preparedHeaders;
  #matchResult;
  #path;
  /**
   * Creates an instance of the Context class.
   *
   * @param req - The Request object.
   * @param options - Optional configuration options for the context.
   */
  constructor(req, options) {
    this.#rawRequest = req;
    if (options) {
      this.#executionCtx = options.executionCtx;
      this.env = options.env;
      this.#notFoundHandler = options.notFoundHandler;
      this.#path = options.path;
      this.#matchResult = options.matchResult;
    }
  }
  /**
   * `.req` is the instance of {@link HonoRequest}.
   */
  get req() {
    this.#req ??= new HonoRequest(this.#rawRequest, this.#path, this.#matchResult);
    return this.#req;
  }
  /**
   * @see {@link https://hono.dev/docs/api/context#event}
   * The FetchEvent associated with the current request.
   *
   * @throws Will throw an error if the context does not have a FetchEvent.
   */
  get event() {
    if (this.#executionCtx && "respondWith" in this.#executionCtx) {
      return this.#executionCtx;
    } else {
      throw Error("This context has no FetchEvent");
    }
  }
  /**
   * @see {@link https://hono.dev/docs/api/context#executionctx}
   * The ExecutionContext associated with the current request.
   *
   * @throws Will throw an error if the context does not have an ExecutionContext.
   */
  get executionCtx() {
    if (this.#executionCtx) {
      return this.#executionCtx;
    } else {
      throw Error("This context has no ExecutionContext");
    }
  }
  /**
   * @see {@link https://hono.dev/docs/api/context#res}
   * The Response object for the current request.
   */
  get res() {
    return this.#res ||= createResponseInstance(null, {
      headers: this.#preparedHeaders ??= new Headers()
    });
  }
  /**
   * Sets the Response object for the current request.
   *
   * @param _res - The Response object to set.
   */
  set res(_res) {
    if (this.#res && _res) {
      _res = createResponseInstance(_res.body, _res);
      for (const [k2, v2] of this.#res.headers.entries()) {
        if (k2 === "content-type") {
          continue;
        }
        if (k2 === "set-cookie") {
          const cookies = this.#res.headers.getSetCookie();
          _res.headers.delete("set-cookie");
          for (const cookie of cookies) {
            _res.headers.append("set-cookie", cookie);
          }
        } else {
          _res.headers.set(k2, v2);
        }
      }
    }
    this.#res = _res;
    this.finalized = true;
  }
  /**
   * `.render()` can create a response within a layout.
   *
   * @see {@link https://hono.dev/docs/api/context#render-setrenderer}
   *
   * @example
   * ```ts
   * app.get('/', (c) => {
   *   return c.render('Hello!')
   * })
   * ```
   */
  render = (...args) => {
    this.#renderer ??= (content) => this.html(content);
    return this.#renderer(...args);
  };
  /**
   * Sets the layout for the response.
   *
   * @param layout - The layout to set.
   * @returns The layout function.
   */
  setLayout = (layout) => this.#layout = layout;
  /**
   * Gets the current layout for the response.
   *
   * @returns The current layout function.
   */
  getLayout = () => this.#layout;
  /**
   * `.setRenderer()` can set the layout in the custom middleware.
   *
   * @see {@link https://hono.dev/docs/api/context#render-setrenderer}
   *
   * @example
   * ```tsx
   * app.use('*', async (c, next) => {
   *   c.setRenderer((content) => {
   *     return c.html(
   *       <html>
   *         <body>
   *           <p>{content}</p>
   *         </body>
   *       </html>
   *     )
   *   })
   *   await next()
   * })
   * ```
   */
  setRenderer = (renderer) => {
    this.#renderer = renderer;
  };
  /**
   * `.header()` can set headers.
   *
   * @see {@link https://hono.dev/docs/api/context#header}
   *
   * @example
   * ```ts
   * app.get('/welcome', (c) => {
   *   // Set headers
   *   c.header('X-Message', 'Hello!')
   *   c.header('Content-Type', 'text/plain')
   *
   *   return c.body('Thank you for coming')
   * })
   * ```
   */
  header = (name, value, options) => {
    if (this.finalized) {
      this.#res = createResponseInstance(this.#res.body, this.#res);
    }
    const headers = this.#res ? this.#res.headers : this.#preparedHeaders ??= new Headers();
    if (value === void 0) {
      headers.delete(name);
    } else if (options?.append) {
      headers.append(name, value);
    } else {
      headers.set(name, value);
    }
  };
  status = (status) => {
    this.#status = status;
  };
  /**
   * `.set()` can set the value specified by the key.
   *
   * @see {@link https://hono.dev/docs/api/context#set-get}
   *
   * @example
   * ```ts
   * app.use('*', async (c, next) => {
   *   c.set('message', 'Hono is hot!!')
   *   await next()
   * })
   * ```
   */
  set = (key, value) => {
    this.#var ??= /* @__PURE__ */ new Map();
    this.#var.set(key, value);
  };
  /**
   * `.get()` can use the value specified by the key.
   *
   * @see {@link https://hono.dev/docs/api/context#set-get}
   *
   * @example
   * ```ts
   * app.get('/', (c) => {
   *   const message = c.get('message')
   *   return c.text(`The message is "${message}"`)
   * })
   * ```
   */
  get = (key) => {
    return this.#var ? this.#var.get(key) : void 0;
  };
  /**
   * `.var` can access the value of a variable.
   *
   * @see {@link https://hono.dev/docs/api/context#var}
   *
   * @example
   * ```ts
   * const result = c.var.client.oneMethod()
   * ```
   */
  // c.var.propName is a read-only
  get var() {
    if (!this.#var) {
      return {};
    }
    return Object.fromEntries(this.#var);
  }
  #newResponse(data, arg, headers) {
    const responseHeaders = this.#res ? new Headers(this.#res.headers) : this.#preparedHeaders ?? new Headers();
    if (typeof arg === "object" && "headers" in arg) {
      const argHeaders = arg.headers instanceof Headers ? arg.headers : new Headers(arg.headers);
      for (const [key, value] of argHeaders) {
        if (key.toLowerCase() === "set-cookie") {
          responseHeaders.append(key, value);
        } else {
          responseHeaders.set(key, value);
        }
      }
    }
    if (headers) {
      for (const [k2, v2] of Object.entries(headers)) {
        if (typeof v2 === "string") {
          responseHeaders.set(k2, v2);
        } else {
          responseHeaders.delete(k2);
          for (const v22 of v2) {
            responseHeaders.append(k2, v22);
          }
        }
      }
    }
    const status = typeof arg === "number" ? arg : arg?.status ?? this.#status;
    return createResponseInstance(data, { status, headers: responseHeaders });
  }
  newResponse = (...args) => this.#newResponse(...args);
  /**
   * `.body()` can return the HTTP response.
   * You can set headers with `.header()` and set HTTP status code with `.status`.
   * This can also be set in `.text()`, `.json()` and so on.
   *
   * @see {@link https://hono.dev/docs/api/context#body}
   *
   * @example
   * ```ts
   * app.get('/welcome', (c) => {
   *   // Set headers
   *   c.header('X-Message', 'Hello!')
   *   c.header('Content-Type', 'text/plain')
   *   // Set HTTP status code
   *   c.status(201)
   *
   *   // Return the response body
   *   return c.body('Thank you for coming')
   * })
   * ```
   */
  body = (data, arg, headers) => this.#newResponse(data, arg, headers);
  /**
   * `.text()` can render text as `Content-Type:text/plain`.
   *
   * @see {@link https://hono.dev/docs/api/context#text}
   *
   * @example
   * ```ts
   * app.get('/say', (c) => {
   *   return c.text('Hello!')
   * })
   * ```
   */
  text = (text, arg, headers) => {
    return !this.#preparedHeaders && !this.#status && !arg && !headers && !this.finalized ? new Response(text) : this.#newResponse(
      text,
      arg,
      setDefaultContentType(TEXT_PLAIN, headers)
    );
  };
  /**
   * `.json()` can render JSON as `Content-Type:application/json`.
   *
   * @see {@link https://hono.dev/docs/api/context#json}
   *
   * @example
   * ```ts
   * app.get('/api', (c) => {
   *   return c.json({ message: 'Hello!' })
   * })
   * ```
   */
  json = (object, arg, headers) => {
    return this.#newResponse(
      JSON.stringify(object),
      arg,
      setDefaultContentType("application/json", headers)
    );
  };
  html = (html, arg, headers) => {
    const res = (html2) => this.#newResponse(html2, arg, setDefaultContentType("text/html; charset=UTF-8", headers));
    return typeof html === "object" ? resolveCallback(html, HtmlEscapedCallbackPhase.Stringify, false, {}).then(res) : res(html);
  };
  /**
   * `.redirect()` can Redirect, default status code is 302.
   *
   * @see {@link https://hono.dev/docs/api/context#redirect}
   *
   * @example
   * ```ts
   * app.get('/redirect', (c) => {
   *   return c.redirect('/')
   * })
   * app.get('/redirect-permanently', (c) => {
   *   return c.redirect('/', 301)
   * })
   * ```
   */
  redirect = (location, status) => {
    const locationString = String(location);
    this.header(
      "Location",
      // Multibyes should be encoded
      // eslint-disable-next-line no-control-regex
      !/[^\x00-\xFF]/.test(locationString) ? locationString : encodeURI(locationString)
    );
    return this.newResponse(null, status ?? 302);
  };
  /**
   * `.notFound()` can return the Not Found Response.
   *
   * @see {@link https://hono.dev/docs/api/context#notfound}
   *
   * @example
   * ```ts
   * app.get('/notfound', (c) => {
   *   return c.notFound()
   * })
   * ```
   */
  notFound = () => {
    this.#notFoundHandler ??= () => createResponseInstance();
    return this.#notFoundHandler(this);
  };
};

// node_modules/hono/dist/router.js
var METHOD_NAME_ALL = "ALL";
var METHOD_NAME_ALL_LOWERCASE = "all";
var METHODS = ["get", "post", "put", "delete", "options", "patch"];
var MESSAGE_MATCHER_IS_ALREADY_BUILT = "Can not add a route since the matcher is already built.";
var UnsupportedPathError = class extends Error {
};

// node_modules/hono/dist/utils/constants.js
var COMPOSED_HANDLER = "__COMPOSED_HANDLER";

// node_modules/hono/dist/hono-base.js
var notFoundHandler = (c) => {
  return c.text("404 Not Found", 404);
};
var errorHandler = (err, c) => {
  if ("getResponse" in err) {
    const res = err.getResponse();
    return c.newResponse(res.body, res);
  }
  console.error(err);
  return c.text("Internal Server Error", 500);
};
var Hono = class _Hono {
  get;
  post;
  put;
  delete;
  options;
  patch;
  all;
  on;
  use;
  /*
    This class is like an abstract class and does not have a router.
    To use it, inherit the class and implement router in the constructor.
  */
  router;
  getPath;
  // Cannot use `#` because it requires visibility at JavaScript runtime.
  _basePath = "/";
  #path = "/";
  routes = [];
  constructor(options = {}) {
    const allMethods = [...METHODS, METHOD_NAME_ALL_LOWERCASE];
    allMethods.forEach((method) => {
      this[method] = (args1, ...args) => {
        if (typeof args1 === "string") {
          this.#path = args1;
        } else {
          this.#addRoute(method, this.#path, args1);
        }
        args.forEach((handler2) => {
          this.#addRoute(method, this.#path, handler2);
        });
        return this;
      };
    });
    this.on = (method, path3, ...handlers) => {
      for (const p of [path3].flat()) {
        this.#path = p;
        for (const m2 of [method].flat()) {
          handlers.map((handler2) => {
            this.#addRoute(m2.toUpperCase(), this.#path, handler2);
          });
        }
      }
      return this;
    };
    this.use = (arg1, ...handlers) => {
      if (typeof arg1 === "string") {
        this.#path = arg1;
      } else {
        this.#path = "*";
        handlers.unshift(arg1);
      }
      handlers.forEach((handler2) => {
        this.#addRoute(METHOD_NAME_ALL, this.#path, handler2);
      });
      return this;
    };
    const { strict, ...optionsWithoutStrict } = options;
    Object.assign(this, optionsWithoutStrict);
    this.getPath = strict ?? true ? options.getPath ?? getPath : getPathNoStrict;
  }
  #clone() {
    const clone = new _Hono({
      router: this.router,
      getPath: this.getPath
    });
    clone.errorHandler = this.errorHandler;
    clone.#notFoundHandler = this.#notFoundHandler;
    clone.routes = this.routes;
    return clone;
  }
  #notFoundHandler = notFoundHandler;
  // Cannot use `#` because it requires visibility at JavaScript runtime.
  errorHandler = errorHandler;
  /**
   * `.route()` allows grouping other Hono instance in routes.
   *
   * @see {@link https://hono.dev/docs/api/routing#grouping}
   *
   * @param {string} path - base Path
   * @param {Hono} app - other Hono instance
   * @returns {Hono} routed Hono instance
   *
   * @example
   * ```ts
   * const app = new Hono()
   * const app2 = new Hono()
   *
   * app2.get("/user", (c) => c.text("user"))
   * app.route("/api", app2) // GET /api/user
   * ```
   */
  route(path3, app2) {
    const subApp = this.basePath(path3);
    app2.routes.map((r) => {
      let handler2;
      if (app2.errorHandler === errorHandler) {
        handler2 = r.handler;
      } else {
        handler2 = async (c, next) => (await compose([], app2.errorHandler)(c, () => r.handler(c, next))).res;
        handler2[COMPOSED_HANDLER] = r.handler;
      }
      subApp.#addRoute(r.method, r.path, handler2, r.basePath);
    });
    return this;
  }
  /**
   * `.basePath()` allows base paths to be specified.
   *
   * @see {@link https://hono.dev/docs/api/routing#base-path}
   *
   * @param {string} path - base Path
   * @returns {Hono} changed Hono instance
   *
   * @example
   * ```ts
   * const api = new Hono().basePath('/api')
   * ```
   */
  basePath(path3) {
    const subApp = this.#clone();
    subApp._basePath = mergePath(this._basePath, path3);
    return subApp;
  }
  /**
   * `.onError()` handles an error and returns a customized Response.
   *
   * @see {@link https://hono.dev/docs/api/hono#error-handling}
   *
   * @param {ErrorHandler} handler - request Handler for error
   * @returns {Hono} changed Hono instance
   *
   * @example
   * ```ts
   * app.onError((err, c) => {
   *   console.error(`${err}`)
   *   return c.text('Custom Error Message', 500)
   * })
   * ```
   */
  onError = (handler2) => {
    this.errorHandler = handler2;
    return this;
  };
  /**
   * `.notFound()` allows you to customize a Not Found Response.
   *
   * @see {@link https://hono.dev/docs/api/hono#not-found}
   *
   * @param {NotFoundHandler} handler - request handler for not-found
   * @returns {Hono} changed Hono instance
   *
   * @example
   * ```ts
   * app.notFound((c) => {
   *   return c.text('Custom 404 Message', 404)
   * })
   * ```
   */
  notFound = (handler2) => {
    this.#notFoundHandler = handler2;
    return this;
  };
  /**
   * `.mount()` allows you to mount applications built with other frameworks into your Hono application.
   *
   * @see {@link https://hono.dev/docs/api/hono#mount}
   *
   * @param {string} path - base Path
   * @param {Function} applicationHandler - other Request Handler
   * @param {MountOptions} [options] - options of `.mount()`
   * @returns {Hono} mounted Hono instance
   *
   * @example
   * ```ts
   * import { Router as IttyRouter } from 'itty-router'
   * import { Hono } from 'hono'
   * // Create itty-router application
   * const ittyRouter = IttyRouter()
   * // GET /itty-router/hello
   * ittyRouter.get('/hello', () => new Response('Hello from itty-router'))
   *
   * const app = new Hono()
   * app.mount('/itty-router', ittyRouter.handle)
   * ```
   *
   * @example
   * ```ts
   * const app = new Hono()
   * // Send the request to another application without modification.
   * app.mount('/app', anotherApp, {
   *   replaceRequest: (req) => req,
   * })
   * ```
   */
  mount(path3, applicationHandler, options) {
    let replaceRequest;
    let optionHandler;
    if (options) {
      if (typeof options === "function") {
        optionHandler = options;
      } else {
        optionHandler = options.optionHandler;
        if (options.replaceRequest === false) {
          replaceRequest = (request) => request;
        } else {
          replaceRequest = options.replaceRequest;
        }
      }
    }
    const getOptions = optionHandler ? (c) => {
      const options2 = optionHandler(c);
      return Array.isArray(options2) ? options2 : [options2];
    } : (c) => {
      let executionContext = void 0;
      try {
        executionContext = c.executionCtx;
      } catch {
      }
      return [c.env, executionContext];
    };
    replaceRequest ||= (() => {
      const mergedPath = mergePath(this._basePath, path3);
      const pathPrefixLength = mergedPath === "/" ? 0 : mergedPath.length;
      return (request) => {
        const url = new URL(request.url);
        url.pathname = this.getPath(request).slice(pathPrefixLength) || "/";
        return new Request(url, request);
      };
    })();
    const handler2 = async (c, next) => {
      const res = await applicationHandler(replaceRequest(c.req.raw), ...getOptions(c));
      if (res) {
        return res;
      }
      await next();
    };
    this.#addRoute(METHOD_NAME_ALL, mergePath(path3, "*"), handler2);
    return this;
  }
  #addRoute(method, path3, handler2, baseRoutePath) {
    method = method.toUpperCase();
    path3 = mergePath(this._basePath, path3);
    const r = {
      basePath: baseRoutePath !== void 0 ? mergePath(this._basePath, baseRoutePath) : this._basePath,
      path: path3,
      method,
      handler: handler2
    };
    this.router.add(method, path3, [handler2, r]);
    this.routes.push(r);
  }
  #handleError(err, c) {
    if (err instanceof Error) {
      return this.errorHandler(err, c);
    }
    throw err;
  }
  #dispatch(request, executionCtx, env, method) {
    if (method === "HEAD") {
      return (async () => new Response(null, await this.#dispatch(request, executionCtx, env, "GET")))();
    }
    const path3 = this.getPath(request, { env });
    const matchResult = this.router.match(method, path3);
    const c = new Context(request, {
      path: path3,
      matchResult,
      env,
      executionCtx,
      notFoundHandler: this.#notFoundHandler
    });
    if (matchResult[0].length === 1) {
      let res;
      try {
        res = matchResult[0][0][0][0](c, async () => {
          c.res = await this.#notFoundHandler(c);
        });
      } catch (err) {
        return this.#handleError(err, c);
      }
      return res instanceof Promise ? res.then(
        (resolved) => resolved || (c.finalized ? c.res : this.#notFoundHandler(c))
      ).catch((err) => this.#handleError(err, c)) : res ?? this.#notFoundHandler(c);
    }
    const composed = compose(matchResult[0], this.errorHandler, this.#notFoundHandler);
    return (async () => {
      try {
        const context = await composed(c);
        if (!context.finalized) {
          throw new Error(
            "Context is not finalized. Did you forget to return a Response object or `await next()`?"
          );
        }
        return context.res;
      } catch (err) {
        return this.#handleError(err, c);
      }
    })();
  }
  /**
   * `.fetch()` will be entry point of your app.
   *
   * @see {@link https://hono.dev/docs/api/hono#fetch}
   *
   * @param {Request} request - request Object of request
   * @param {Env} Env - env Object
   * @param {ExecutionContext} - context of execution
   * @returns {Response | Promise<Response>} response of request
   *
   */
  fetch = (request, ...rest) => {
    return this.#dispatch(request, rest[1], rest[0], request.method);
  };
  /**
   * `.request()` is a useful method for testing.
   * You can pass a URL or pathname to send a GET request.
   * app will return a Response object.
   * ```ts
   * test('GET /hello is ok', async () => {
   *   const res = await app.request('/hello')
   *   expect(res.status).toBe(200)
   * })
   * ```
   * @see https://hono.dev/docs/api/hono#request
   */
  request = (input, requestInit, Env, executionCtx) => {
    if (input instanceof Request) {
      return this.fetch(requestInit ? new Request(input, requestInit) : input, Env, executionCtx);
    }
    input = input.toString();
    return this.fetch(
      new Request(
        /^https?:\/\//.test(input) ? input : `http://localhost${mergePath("/", input)}`,
        requestInit
      ),
      Env,
      executionCtx
    );
  };
  /**
   * `.fire()` automatically adds a global fetch event listener.
   * This can be useful for environments that adhere to the Service Worker API, such as non-ES module Cloudflare Workers.
   * @deprecated
   * Use `fire` from `hono/service-worker` instead.
   * ```ts
   * import { Hono } from 'hono'
   * import { fire } from 'hono/service-worker'
   *
   * const app = new Hono()
   * // ...
   * fire(app)
   * ```
   * @see https://hono.dev/docs/api/hono#fire
   * @see https://developer.mozilla.org/en-US/docs/Web/API/Service_Worker_API
   * @see https://developers.cloudflare.com/workers/reference/migrate-to-module-workers/
   */
  fire = () => {
    addEventListener("fetch", (event) => {
      event.respondWith(this.#dispatch(event.request, event, void 0, event.request.method));
    });
  };
};

// node_modules/hono/dist/router/reg-exp-router/matcher.js
var emptyParam = [];
function match(method, path3) {
  const matchers = this.buildAllMatchers();
  const match2 = ((method2, path22) => {
    const matcher = matchers[method2] || matchers[METHOD_NAME_ALL];
    const staticMatch = matcher[2][path22];
    if (staticMatch) {
      return staticMatch;
    }
    const match3 = path22.match(matcher[0]);
    if (!match3) {
      return [[], emptyParam];
    }
    const index = match3.indexOf("", 1);
    return [matcher[1][index], match3];
  });
  this.match = match2;
  return match2(method, path3);
}

// node_modules/hono/dist/router/reg-exp-router/node.js
var LABEL_REG_EXP_STR = "[^/]+";
var ONLY_WILDCARD_REG_EXP_STR = ".*";
var TAIL_WILDCARD_REG_EXP_STR = "(?:|/.*)";
var PATH_ERROR = /* @__PURE__ */ Symbol();
var regExpMetaChars = new Set(".\\+*[^]$()");
function compareKey(a2, b) {
  if (a2.length === 1) {
    return b.length === 1 ? a2 < b ? -1 : 1 : -1;
  }
  if (b.length === 1) {
    return 1;
  }
  if (a2 === ONLY_WILDCARD_REG_EXP_STR || a2 === TAIL_WILDCARD_REG_EXP_STR) {
    return 1;
  } else if (b === ONLY_WILDCARD_REG_EXP_STR || b === TAIL_WILDCARD_REG_EXP_STR) {
    return -1;
  }
  if (a2 === LABEL_REG_EXP_STR) {
    return 1;
  } else if (b === LABEL_REG_EXP_STR) {
    return -1;
  }
  return a2.length === b.length ? a2 < b ? -1 : 1 : b.length - a2.length;
}
var Node = class _Node {
  #index;
  #varIndex;
  #children = /* @__PURE__ */ Object.create(null);
  insert(tokens, index, paramMap, context, pathErrorCheckOnly) {
    if (tokens.length === 0) {
      if (this.#index !== void 0) {
        throw PATH_ERROR;
      }
      if (pathErrorCheckOnly) {
        return;
      }
      this.#index = index;
      return;
    }
    const [token, ...restTokens] = tokens;
    const pattern = token === "*" ? restTokens.length === 0 ? ["", "", ONLY_WILDCARD_REG_EXP_STR] : ["", "", LABEL_REG_EXP_STR] : token === "/*" ? ["", "", TAIL_WILDCARD_REG_EXP_STR] : token.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/);
    let node;
    if (pattern) {
      const name = pattern[1];
      let regexpStr = pattern[2] || LABEL_REG_EXP_STR;
      if (name && pattern[2]) {
        if (regexpStr === ".*") {
          throw PATH_ERROR;
        }
        regexpStr = regexpStr.replace(/^\((?!\?:)(?=[^)]+\)$)/, "(?:");
        if (/\((?!\?:)/.test(regexpStr)) {
          throw PATH_ERROR;
        }
      }
      node = this.#children[regexpStr];
      if (!node) {
        if (Object.keys(this.#children).some(
          (k2) => k2 !== ONLY_WILDCARD_REG_EXP_STR && k2 !== TAIL_WILDCARD_REG_EXP_STR
        )) {
          throw PATH_ERROR;
        }
        if (pathErrorCheckOnly) {
          return;
        }
        node = this.#children[regexpStr] = new _Node();
        if (name !== "") {
          node.#varIndex = context.varIndex++;
        }
      }
      if (!pathErrorCheckOnly && name !== "") {
        paramMap.push([name, node.#varIndex]);
      }
    } else {
      node = this.#children[token];
      if (!node) {
        if (Object.keys(this.#children).some(
          (k2) => k2.length > 1 && k2 !== ONLY_WILDCARD_REG_EXP_STR && k2 !== TAIL_WILDCARD_REG_EXP_STR
        )) {
          throw PATH_ERROR;
        }
        if (pathErrorCheckOnly) {
          return;
        }
        node = this.#children[token] = new _Node();
      }
    }
    node.insert(restTokens, index, paramMap, context, pathErrorCheckOnly);
  }
  buildRegExpStr() {
    const childKeys = Object.keys(this.#children).sort(compareKey);
    const strList = childKeys.map((k2) => {
      const c = this.#children[k2];
      return (typeof c.#varIndex === "number" ? `(${k2})@${c.#varIndex}` : regExpMetaChars.has(k2) ? `\\${k2}` : k2) + c.buildRegExpStr();
    });
    if (typeof this.#index === "number") {
      strList.unshift(`#${this.#index}`);
    }
    if (strList.length === 0) {
      return "";
    }
    if (strList.length === 1) {
      return strList[0];
    }
    return "(?:" + strList.join("|") + ")";
  }
};

// node_modules/hono/dist/router/reg-exp-router/trie.js
var Trie = class {
  #context = { varIndex: 0 };
  #root = new Node();
  insert(path3, index, pathErrorCheckOnly) {
    const paramAssoc = [];
    const groups = [];
    for (let i = 0; ; ) {
      let replaced = false;
      path3 = path3.replace(/\{[^}]+\}/g, (m2) => {
        const mark = `@\\${i}`;
        groups[i] = [mark, m2];
        i++;
        replaced = true;
        return mark;
      });
      if (!replaced) {
        break;
      }
    }
    const tokens = path3.match(/(?::[^\/]+)|(?:\/\*$)|./g) || [];
    for (let i = groups.length - 1; i >= 0; i--) {
      const [mark] = groups[i];
      for (let j = tokens.length - 1; j >= 0; j--) {
        if (tokens[j].indexOf(mark) !== -1) {
          tokens[j] = tokens[j].replace(mark, groups[i][1]);
          break;
        }
      }
    }
    this.#root.insert(tokens, index, paramAssoc, this.#context, pathErrorCheckOnly);
    return paramAssoc;
  }
  buildRegExp() {
    let regexp = this.#root.buildRegExpStr();
    if (regexp === "") {
      return [/^$/, [], []];
    }
    let captureIndex = 0;
    const indexReplacementMap = [];
    const paramReplacementMap = [];
    regexp = regexp.replace(/#(\d+)|@(\d+)|\.\*\$/g, (_2, handlerIndex, paramIndex) => {
      if (handlerIndex !== void 0) {
        indexReplacementMap[++captureIndex] = Number(handlerIndex);
        return "$()";
      }
      if (paramIndex !== void 0) {
        paramReplacementMap[Number(paramIndex)] = ++captureIndex;
        return "";
      }
      return "";
    });
    return [new RegExp(`^${regexp}`), indexReplacementMap, paramReplacementMap];
  }
};

// node_modules/hono/dist/router/reg-exp-router/router.js
var nullMatcher = [/^$/, [], /* @__PURE__ */ Object.create(null)];
var wildcardRegExpCache = /* @__PURE__ */ Object.create(null);
function buildWildcardRegExp(path3) {
  return wildcardRegExpCache[path3] ??= new RegExp(
    path3 === "*" ? "" : `^${path3.replace(
      /\/\*$|([.\\+*[^\]$()])/g,
      (_2, metaChar) => metaChar ? `\\${metaChar}` : "(?:|/.*)"
    )}$`
  );
}
function clearWildcardRegExpCache() {
  wildcardRegExpCache = /* @__PURE__ */ Object.create(null);
}
function buildMatcherFromPreprocessedRoutes(routes) {
  const trie = new Trie();
  const handlerData = [];
  if (routes.length === 0) {
    return nullMatcher;
  }
  const routesWithStaticPathFlag = routes.map(
    (route) => [!/\*|\/:/.test(route[0]), ...route]
  ).sort(
    ([isStaticA, pathA], [isStaticB, pathB]) => isStaticA ? 1 : isStaticB ? -1 : pathA.length - pathB.length
  );
  const staticMap = /* @__PURE__ */ Object.create(null);
  for (let i = 0, j = -1, len = routesWithStaticPathFlag.length; i < len; i++) {
    const [pathErrorCheckOnly, path3, handlers] = routesWithStaticPathFlag[i];
    if (pathErrorCheckOnly) {
      staticMap[path3] = [handlers.map(([h]) => [h, /* @__PURE__ */ Object.create(null)]), emptyParam];
    } else {
      j++;
    }
    let paramAssoc;
    try {
      paramAssoc = trie.insert(path3, j, pathErrorCheckOnly);
    } catch (e) {
      throw e === PATH_ERROR ? new UnsupportedPathError(path3) : e;
    }
    if (pathErrorCheckOnly) {
      continue;
    }
    handlerData[j] = handlers.map(([h, paramCount]) => {
      const paramIndexMap = /* @__PURE__ */ Object.create(null);
      paramCount -= 1;
      for (; paramCount >= 0; paramCount--) {
        const [key, value] = paramAssoc[paramCount];
        paramIndexMap[key] = value;
      }
      return [h, paramIndexMap];
    });
  }
  const [regexp, indexReplacementMap, paramReplacementMap] = trie.buildRegExp();
  for (let i = 0, len = handlerData.length; i < len; i++) {
    for (let j = 0, len2 = handlerData[i].length; j < len2; j++) {
      const map = handlerData[i][j]?.[1];
      if (!map) {
        continue;
      }
      const keys = Object.keys(map);
      for (let k2 = 0, len3 = keys.length; k2 < len3; k2++) {
        map[keys[k2]] = paramReplacementMap[map[keys[k2]]];
      }
    }
  }
  const handlerMap = [];
  for (const i in indexReplacementMap) {
    handlerMap[i] = handlerData[indexReplacementMap[i]];
  }
  return [regexp, handlerMap, staticMap];
}
function findMiddleware(middleware, path3) {
  if (!middleware) {
    return void 0;
  }
  for (const k2 of Object.keys(middleware).sort((a2, b) => b.length - a2.length)) {
    if (buildWildcardRegExp(k2).test(path3)) {
      return [...middleware[k2]];
    }
  }
  return void 0;
}
var RegExpRouter = class {
  name = "RegExpRouter";
  #middleware;
  #routes;
  constructor() {
    this.#middleware = { [METHOD_NAME_ALL]: /* @__PURE__ */ Object.create(null) };
    this.#routes = { [METHOD_NAME_ALL]: /* @__PURE__ */ Object.create(null) };
  }
  add(method, path3, handler2) {
    const middleware = this.#middleware;
    const routes = this.#routes;
    if (!middleware || !routes) {
      throw new Error(MESSAGE_MATCHER_IS_ALREADY_BUILT);
    }
    if (!middleware[method]) {
      ;
      [middleware, routes].forEach((handlerMap) => {
        handlerMap[method] = /* @__PURE__ */ Object.create(null);
        Object.keys(handlerMap[METHOD_NAME_ALL]).forEach((p) => {
          handlerMap[method][p] = [...handlerMap[METHOD_NAME_ALL][p]];
        });
      });
    }
    if (path3 === "/*") {
      path3 = "*";
    }
    const paramCount = (path3.match(/\/:/g) || []).length;
    if (/\*$/.test(path3)) {
      const re2 = buildWildcardRegExp(path3);
      if (method === METHOD_NAME_ALL) {
        Object.keys(middleware).forEach((m2) => {
          middleware[m2][path3] ||= findMiddleware(middleware[m2], path3) || findMiddleware(middleware[METHOD_NAME_ALL], path3) || [];
        });
      } else {
        middleware[method][path3] ||= findMiddleware(middleware[method], path3) || findMiddleware(middleware[METHOD_NAME_ALL], path3) || [];
      }
      Object.keys(middleware).forEach((m2) => {
        if (method === METHOD_NAME_ALL || method === m2) {
          Object.keys(middleware[m2]).forEach((p) => {
            re2.test(p) && middleware[m2][p].push([handler2, paramCount]);
          });
        }
      });
      Object.keys(routes).forEach((m2) => {
        if (method === METHOD_NAME_ALL || method === m2) {
          Object.keys(routes[m2]).forEach(
            (p) => re2.test(p) && routes[m2][p].push([handler2, paramCount])
          );
        }
      });
      return;
    }
    const paths = checkOptionalParameter(path3) || [path3];
    for (let i = 0, len = paths.length; i < len; i++) {
      const path22 = paths[i];
      Object.keys(routes).forEach((m2) => {
        if (method === METHOD_NAME_ALL || method === m2) {
          routes[m2][path22] ||= [
            ...findMiddleware(middleware[m2], path22) || findMiddleware(middleware[METHOD_NAME_ALL], path22) || []
          ];
          routes[m2][path22].push([handler2, paramCount - len + i + 1]);
        }
      });
    }
  }
  match = match;
  buildAllMatchers() {
    const matchers = /* @__PURE__ */ Object.create(null);
    Object.keys(this.#routes).concat(Object.keys(this.#middleware)).forEach((method) => {
      matchers[method] ||= this.#buildMatcher(method);
    });
    this.#middleware = this.#routes = void 0;
    clearWildcardRegExpCache();
    return matchers;
  }
  #buildMatcher(method) {
    const routes = [];
    let hasOwnRoute = method === METHOD_NAME_ALL;
    [this.#middleware, this.#routes].forEach((r) => {
      const ownRoute = r[method] ? Object.keys(r[method]).map((path3) => [path3, r[method][path3]]) : [];
      if (ownRoute.length !== 0) {
        hasOwnRoute ||= true;
        routes.push(...ownRoute);
      } else if (method !== METHOD_NAME_ALL) {
        routes.push(
          ...Object.keys(r[METHOD_NAME_ALL]).map((path3) => [path3, r[METHOD_NAME_ALL][path3]])
        );
      }
    });
    if (!hasOwnRoute) {
      return null;
    } else {
      return buildMatcherFromPreprocessedRoutes(routes);
    }
  }
};

// node_modules/hono/dist/router/smart-router/router.js
var SmartRouter = class {
  name = "SmartRouter";
  #routers = [];
  #routes = [];
  constructor(init) {
    this.#routers = init.routers;
  }
  add(method, path3, handler2) {
    if (!this.#routes) {
      throw new Error(MESSAGE_MATCHER_IS_ALREADY_BUILT);
    }
    this.#routes.push([method, path3, handler2]);
  }
  match(method, path3) {
    if (!this.#routes) {
      throw new Error("Fatal error");
    }
    const routers = this.#routers;
    const routes = this.#routes;
    const len = routers.length;
    let i = 0;
    let res;
    for (; i < len; i++) {
      const router = routers[i];
      try {
        for (let i2 = 0, len2 = routes.length; i2 < len2; i2++) {
          router.add(...routes[i2]);
        }
        res = router.match(method, path3);
      } catch (e) {
        if (e instanceof UnsupportedPathError) {
          continue;
        }
        throw e;
      }
      this.match = router.match.bind(router);
      this.#routers = [router];
      this.#routes = void 0;
      break;
    }
    if (i === len) {
      throw new Error("Fatal error");
    }
    this.name = `SmartRouter + ${this.activeRouter.name}`;
    return res;
  }
  get activeRouter() {
    if (this.#routes || this.#routers.length !== 1) {
      throw new Error("No active router has been determined yet.");
    }
    return this.#routers[0];
  }
};

// node_modules/hono/dist/router/trie-router/node.js
var emptyParams = /* @__PURE__ */ Object.create(null);
var hasChildren = (children) => {
  for (const _2 in children) {
    return true;
  }
  return false;
};
var Node2 = class _Node2 {
  #methods;
  #children;
  #patterns;
  #order = 0;
  #params = emptyParams;
  constructor(method, handler2, children) {
    this.#children = children || /* @__PURE__ */ Object.create(null);
    this.#methods = [];
    if (method && handler2) {
      const m2 = /* @__PURE__ */ Object.create(null);
      m2[method] = { handler: handler2, possibleKeys: [], score: 0 };
      this.#methods = [m2];
    }
    this.#patterns = [];
  }
  insert(method, path3, handler2) {
    this.#order = ++this.#order;
    let curNode = this;
    const parts = splitRoutingPath(path3);
    const possibleKeys = [];
    for (let i = 0, len = parts.length; i < len; i++) {
      const p = parts[i];
      const nextP = parts[i + 1];
      const pattern = getPattern(p, nextP);
      const key = Array.isArray(pattern) ? pattern[0] : p;
      if (key in curNode.#children) {
        curNode = curNode.#children[key];
        if (pattern) {
          possibleKeys.push(pattern[1]);
        }
        continue;
      }
      curNode.#children[key] = new _Node2();
      if (pattern) {
        curNode.#patterns.push(pattern);
        possibleKeys.push(pattern[1]);
      }
      curNode = curNode.#children[key];
    }
    curNode.#methods.push({
      [method]: {
        handler: handler2,
        possibleKeys: possibleKeys.filter((v2, i, a2) => a2.indexOf(v2) === i),
        score: this.#order
      }
    });
    return curNode;
  }
  #pushHandlerSets(handlerSets, node, method, nodeParams, params) {
    for (let i = 0, len = node.#methods.length; i < len; i++) {
      const m2 = node.#methods[i];
      const handlerSet = m2[method] || m2[METHOD_NAME_ALL];
      const processedSet = {};
      if (handlerSet !== void 0) {
        handlerSet.params = /* @__PURE__ */ Object.create(null);
        handlerSets.push(handlerSet);
        if (nodeParams !== emptyParams || params && params !== emptyParams) {
          for (let i2 = 0, len2 = handlerSet.possibleKeys.length; i2 < len2; i2++) {
            const key = handlerSet.possibleKeys[i2];
            const processed = processedSet[handlerSet.score];
            handlerSet.params[key] = params?.[key] && !processed ? params[key] : nodeParams[key] ?? params?.[key];
            processedSet[handlerSet.score] = true;
          }
        }
      }
    }
  }
  search(method, path3) {
    const handlerSets = [];
    this.#params = emptyParams;
    const curNode = this;
    let curNodes = [curNode];
    const parts = splitPath(path3);
    const curNodesQueue = [];
    const len = parts.length;
    let partOffsets = null;
    for (let i = 0; i < len; i++) {
      const part = parts[i];
      const isLast = i === len - 1;
      const tempNodes = [];
      for (let j = 0, len2 = curNodes.length; j < len2; j++) {
        const node = curNodes[j];
        const nextNode = node.#children[part];
        if (nextNode) {
          nextNode.#params = node.#params;
          if (isLast) {
            if (nextNode.#children["*"]) {
              this.#pushHandlerSets(handlerSets, nextNode.#children["*"], method, node.#params);
            }
            this.#pushHandlerSets(handlerSets, nextNode, method, node.#params);
          } else {
            tempNodes.push(nextNode);
          }
        }
        for (let k2 = 0, len3 = node.#patterns.length; k2 < len3; k2++) {
          const pattern = node.#patterns[k2];
          const params = node.#params === emptyParams ? {} : { ...node.#params };
          if (pattern === "*") {
            const astNode = node.#children["*"];
            if (astNode) {
              this.#pushHandlerSets(handlerSets, astNode, method, node.#params);
              astNode.#params = params;
              tempNodes.push(astNode);
            }
            continue;
          }
          const [key, name, matcher] = pattern;
          if (!part && !(matcher instanceof RegExp)) {
            continue;
          }
          const child = node.#children[key];
          if (matcher instanceof RegExp) {
            if (partOffsets === null) {
              partOffsets = new Array(len);
              let offset = path3[0] === "/" ? 1 : 0;
              for (let p = 0; p < len; p++) {
                partOffsets[p] = offset;
                offset += parts[p].length + 1;
              }
            }
            const restPathString = path3.substring(partOffsets[i]);
            const m2 = matcher.exec(restPathString);
            if (m2) {
              params[name] = m2[0];
              this.#pushHandlerSets(handlerSets, child, method, node.#params, params);
              if (hasChildren(child.#children)) {
                child.#params = params;
                const componentCount = m2[0].match(/\//)?.length ?? 0;
                const targetCurNodes = curNodesQueue[componentCount] ||= [];
                targetCurNodes.push(child);
              }
              continue;
            }
          }
          if (matcher === true || matcher.test(part)) {
            params[name] = part;
            if (isLast) {
              this.#pushHandlerSets(handlerSets, child, method, params, node.#params);
              if (child.#children["*"]) {
                this.#pushHandlerSets(
                  handlerSets,
                  child.#children["*"],
                  method,
                  params,
                  node.#params
                );
              }
            } else {
              child.#params = params;
              tempNodes.push(child);
            }
          }
        }
      }
      const shifted = curNodesQueue.shift();
      curNodes = shifted ? tempNodes.concat(shifted) : tempNodes;
    }
    if (handlerSets.length > 1) {
      handlerSets.sort((a2, b) => {
        return a2.score - b.score;
      });
    }
    return [handlerSets.map(({ handler: handler2, params }) => [handler2, params])];
  }
};

// node_modules/hono/dist/router/trie-router/router.js
var TrieRouter = class {
  name = "TrieRouter";
  #node;
  constructor() {
    this.#node = new Node2();
  }
  add(method, path3, handler2) {
    const results = checkOptionalParameter(path3);
    if (results) {
      for (let i = 0, len = results.length; i < len; i++) {
        this.#node.insert(method, results[i], handler2);
      }
      return;
    }
    this.#node.insert(method, path3, handler2);
  }
  match(method, path3) {
    return this.#node.search(method, path3);
  }
};

// node_modules/hono/dist/hono.js
var Hono2 = class extends Hono {
  /**
   * Creates an instance of the Hono class.
   *
   * @param options - Optional configuration options for the Hono instance.
   */
  constructor(options = {}) {
    super(options);
    this.router = options.router ?? new SmartRouter({
      routers: [new RegExpRouter(), new TrieRouter()]
    });
  }
};

// node_modules/hono/dist/middleware/cors/index.js
var cors = (options) => {
  const opts = {
    origin: "*",
    allowMethods: ["GET", "HEAD", "PUT", "POST", "DELETE", "PATCH"],
    allowHeaders: [],
    exposeHeaders: [],
    ...options
  };
  const findAllowOrigin = ((optsOrigin) => {
    if (typeof optsOrigin === "string") {
      if (optsOrigin === "*") {
        if (opts.credentials) {
          return (origin) => origin || null;
        }
        return () => optsOrigin;
      } else {
        return (origin) => optsOrigin === origin ? origin : null;
      }
    } else if (typeof optsOrigin === "function") {
      return optsOrigin;
    } else {
      return (origin) => optsOrigin.includes(origin) ? origin : null;
    }
  })(opts.origin);
  const findAllowMethods = ((optsAllowMethods) => {
    if (typeof optsAllowMethods === "function") {
      return optsAllowMethods;
    } else if (Array.isArray(optsAllowMethods)) {
      return () => optsAllowMethods;
    } else {
      return () => [];
    }
  })(opts.allowMethods);
  return async function cors2(c, next) {
    function set(key, value) {
      c.res.headers.set(key, value);
    }
    const allowOrigin = await findAllowOrigin(c.req.header("origin") || "", c);
    if (allowOrigin) {
      set("Access-Control-Allow-Origin", allowOrigin);
    }
    if (opts.credentials) {
      set("Access-Control-Allow-Credentials", "true");
    }
    if (opts.exposeHeaders?.length) {
      set("Access-Control-Expose-Headers", opts.exposeHeaders.join(","));
    }
    if (c.req.method === "OPTIONS") {
      if (opts.origin !== "*" || opts.credentials) {
        set("Vary", "Origin");
      }
      if (opts.maxAge != null) {
        set("Access-Control-Max-Age", opts.maxAge.toString());
      }
      const allowMethods = await findAllowMethods(c.req.header("origin") || "", c);
      if (allowMethods.length) {
        set("Access-Control-Allow-Methods", allowMethods.join(","));
      }
      let headers = opts.allowHeaders;
      if (!headers?.length) {
        const requestHeaders = c.req.header("Access-Control-Request-Headers");
        if (requestHeaders) {
          headers = requestHeaders.split(/\s*,\s*/);
        }
      }
      if (headers?.length) {
        set("Access-Control-Allow-Headers", headers.join(","));
        c.res.headers.append("Vary", "Access-Control-Request-Headers");
      }
      c.res.headers.delete("Content-Length");
      c.res.headers.delete("Content-Type");
      return new Response(null, {
        headers: c.res.headers,
        status: 204,
        statusText: "No Content"
      });
    }
    await next();
    if (opts.origin !== "*" || opts.credentials) {
      c.header("Vary", "Origin", { append: true });
    }
  };
};

// apps/server/dist/middleware/auth-slot.js
async function authSlot(c, next) {
  await next();
}

// packages/shared/dist/index.js
var INDEX_CODES = [
  "sh000001",
  "sz399001",
  "sz399006",
  "sh000688",
  "sh000300"
];
var DEFAULT_KLINE_INDICATORS = {
  ma: { periods: [5, 10, 20, 60] },
  macd: true,
  boll: true,
  kdj: true,
  rsi: { periods: [6, 12, 24] }
};

// node_modules/stock-sdk/dist/index.js
var Oo = Object.defineProperty;
var Et = (t, e) => {
  for (var r in e) Oo(t, r, { get: e[r], enumerable: true });
};
function Ue(t) {
  return new TextDecoder("gbk").decode(t);
}
function Be(t) {
  let e = t.split(";").map((n) => n.trim()).filter(Boolean), r = [];
  for (let n of e) {
    let o = n.indexOf("=");
    if (o < 0) continue;
    let i = n.slice(0, o).trim();
    i.startsWith("v_") && (i = i.slice(2));
    let s = n.slice(o + 1).trim();
    s.startsWith('"') && s.endsWith('"') && (s = s.slice(1, -1));
    let u = s.split("~");
    r.push({ key: i, fields: u });
  }
  return r;
}
function T(t) {
  if (!t || t === "") return 0;
  let e = parseFloat(t);
  return Number.isNaN(e) ? 0 : e;
}
function C(t) {
  if (!t || t === "") return null;
  let e = parseFloat(t);
  return Number.isNaN(e) ? null : e;
}
function m(t) {
  if (!t || t === "" || t === "-") return null;
  let e = parseFloat(t);
  return Number.isNaN(e) ? null : e;
}
function a(t) {
  return t == null ? null : m(String(t));
}
var Ct = "https://qt.gtimg.cn";
var Ot = "https://web.ifzq.gtimg.cn/appstock/app/minute/query";
var At = "https://assets.linkdiary.cn/shares/zh_a_list.json";
var _t = "https://assets.linkdiary.cn/shares/us_list.json";
var It = "https://assets.linkdiary.cn/shares/hk_list.json";
var Pt = "https://assets.linkdiary.cn/shares/fund_list";
var br = "https://assets.linkdiary.cn/shares/trade-data-list.txt";
var Ke = "https://push2his.eastmoney.com/api/qt/stock/kline/get";
var Dt = "https://push2his.eastmoney.com/api/qt/stock/trends2/get";
var bt = "https://33.push2his.eastmoney.com/api/qt/stock/kline/get";
var Mt = "https://63.push2his.eastmoney.com/api/qt/stock/kline/get";
var kt = "https://17.push2.eastmoney.com/api/qt/clist/get";
var Lt = "https://91.push2.eastmoney.com/api/qt/stock/get";
var Nt = "https://29.push2.eastmoney.com/api/qt/clist/get";
var xt = "https://7.push2his.eastmoney.com/api/qt/stock/kline/get";
var Ft = "https://push2his.eastmoney.com/api/qt/stock/trends2/get";
var vt = "https://79.push2.eastmoney.com/api/qt/clist/get";
var wt = "https://91.push2.eastmoney.com/api/qt/stock/get";
var Ut = "https://29.push2.eastmoney.com/api/qt/clist/get";
var Bt = "https://91.push2his.eastmoney.com/api/qt/stock/kline/get";
var Kt = "https://push2his.eastmoney.com/api/qt/stock/trends2/get";
var Ht = "https://datacenter-web.eastmoney.com/api/data/v1/get";
var ue = "https://push2his.eastmoney.com/api/qt/stock/fflow/daykline/get";
var qt = "https://push2.eastmoney.com/api/qt/clist/get";
var $t = "https://push2.eastmoney.com/api/qt/kamtbs.rtmin/get";
var le = "https://push2ex.eastmoney.com";
var L = "7eea3edcaed734bea9cbfc24409ed989";
var v = "b2884a393a59ad64002292a3e90d46a5";
var ce = "https://push2his.eastmoney.com/api/qt/stock/kline/get";
var zt = "https://futsseapi.eastmoney.com/list/COMEX,NYMEX,COBOT,SGX,NYBOT,LME,MDEX,TOCOM,IPE";
var pe = "58b2fa8f54638b60b87d69b31969089c";
var Qt = { SHFE: 113, DCE: 114, CZCE: 115, INE: 142, CFFEX: 220, GFEX: 225 };
var ee = { cu: "SHFE", al: "SHFE", zn: "SHFE", pb: "SHFE", au: "SHFE", ag: "SHFE", rb: "SHFE", wr: "SHFE", fu: "SHFE", ru: "SHFE", bu: "SHFE", hc: "SHFE", ni: "SHFE", sn: "SHFE", sp: "SHFE", ss: "SHFE", ao: "SHFE", br: "SHFE", c: "DCE", a: "DCE", b: "DCE", m: "DCE", y: "DCE", p: "DCE", l: "DCE", v: "DCE", j: "DCE", jm: "DCE", i: "DCE", jd: "DCE", pp: "DCE", cs: "DCE", eg: "DCE", eb: "DCE", pg: "DCE", lh: "DCE", WH: "CZCE", CF: "CZCE", SR: "CZCE", TA: "CZCE", OI: "CZCE", MA: "CZCE", FG: "CZCE", RM: "CZCE", SF: "CZCE", SM: "CZCE", ZC: "CZCE", AP: "CZCE", CJ: "CZCE", UR: "CZCE", SA: "CZCE", PF: "CZCE", PK: "CZCE", PX: "CZCE", SH: "CZCE", sc: "INE", nr: "INE", lu: "INE", bc: "INE", ec: "INE", IF: "CFFEX", IC: "CFFEX", IH: "CFFEX", IM: "CFFEX", TS: "CFFEX", TF: "CFFEX", T: "CFFEX", TL: "CFFEX", si: "GFEX", lc: "GFEX", ps: "GFEX", pt: "GFEX", pd: "GFEX" };
var He = { HG: 101, GC: 101, SI: 101, QI: 101, QO: 101, MGC: 101, CL: 102, NG: 102, RB: 102, HO: 102, PA: 102, PL: 102, ZW: 103, ZM: 103, ZS: 103, ZC: 103, ZL: 103, ZR: 103, YM: 103, NQ: 103, ES: 103, SB: 108, CT: 108, LCPT: 109, LZNT: 109, LALT: 109 };
var de = "https://stock.finance.sina.com.cn/futures/api/openapi.php/OptionService.getOptionData";
var me = "https://stock.finance.sina.com.cn/futures/api/jsonp.php/{callback}/FutureOptionAllService.getOptionDayline";
var jt = "https://stock.finance.sina.com.cn/futures/api/openapi.php/StockOptionService.getStockName";
var qe = "https://stock.finance.sina.com.cn/futures/api/openapi.php/StockOptionService.getRemainderDay";
var Gt = "https://stock.finance.sina.com.cn/futures/api/openapi.php/StockOptionDaylineService.getOptionMinline";
var Yt = "https://stock.finance.sina.com.cn/futures/api/jsonp_v2.php/{callback}/StockOptionDaylineService.getSymbolInfo";
var Vt = "https://stock.finance.sina.com.cn/futures/api/openapi.php/StockOptionDaylineService.getFiveDayLine";
var Wt = "https://futsseapi.eastmoney.com/list/option/221";
var Xt = "https://datacenter-web.eastmoney.com/api/data/get";
var $e = { au: { product: "au_o", exchange: "shfe" }, ag: { product: "ag_o", exchange: "shfe" }, cu: { product: "cu_o", exchange: "shfe" }, al: { product: "al_o", exchange: "shfe" }, zn: { product: "zn_o", exchange: "shfe" }, ru: { product: "ru_o", exchange: "shfe" }, sc: { product: "sc_o", exchange: "ine" }, m: { product: "m_o", exchange: "dce" }, c: { product: "c_o", exchange: "dce" }, i: { product: "i_o", exchange: "dce" }, p: { product: "p_o", exchange: "dce" }, pp: { product: "pp_o", exchange: "dce" }, l: { product: "l_o", exchange: "dce" }, v: { product: "v_o", exchange: "dce" }, pg: { product: "pg_o", exchange: "dce" }, y: { product: "y_o", exchange: "dce" }, a: { product: "a_o", exchange: "dce" }, b: { product: "b_o", exchange: "dce" }, eg: { product: "eg_o", exchange: "dce" }, eb: { product: "eb_o", exchange: "dce" }, SR: { product: "SR_o", exchange: "czce" }, CF: { product: "CF_o", exchange: "czce" }, TA: { product: "TA_o", exchange: "czce" }, MA: { product: "MA_o", exchange: "czce" }, RM: { product: "RM_o", exchange: "czce" }, OI: { product: "OI_o", exchange: "czce" }, PK: { product: "PK_o", exchange: "czce" }, PF: { product: "PF_o", exchange: "czce" }, SA: { product: "SA_o", exchange: "czce" }, UR: { product: "UR_o", exchange: "czce" } };
var Zt = 3e4;
var ge = 500;
var fe = 500;
var he = 7;
var Jt = 3;
var er = 1e3;
var tr = 3e4;
var rr = 2;
var nr = [408, 429, 500, 502, 503, 504];
var ze = class {
  constructor(e = {}) {
    let r = e.requestsPerSecond ?? 5;
    this.maxTokens = e.maxBurst ?? r, this.tokens = this.maxTokens, this.refillRate = r / 1e3, this.lastRefillTime = Date.now();
  }
  refill() {
    let e = Date.now(), n = (e - this.lastRefillTime) * this.refillRate;
    this.tokens = Math.min(this.maxTokens, this.tokens + n), this.lastRefillTime = e;
  }
  tryAcquire() {
    return this.refill(), this.tokens >= 1 ? (this.tokens -= 1, true) : false;
  }
  getWaitTime() {
    if (this.refill(), this.tokens >= 1) return 0;
    let e = 1 - this.tokens;
    return Math.ceil(e / this.refillRate);
  }
  async acquire() {
    let e = this.getWaitTime();
    e > 0 && await this.sleep(e), this.refill(), this.tokens -= 1;
  }
  sleep(e) {
    return new Promise((r) => setTimeout(r, e));
  }
  getAvailableTokens() {
    return this.refill(), this.tokens;
  }
};
var Mr = ["Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36", "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0", "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:120.0) Gecko/20100101 Firefox/120.0", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:121.0) Gecko/20100101 Firefox/121.0", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1 Safari/605.1.15", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36 Edg/119.0.0.0"];
var or = 0;
function Ao() {
  return typeof window < "u" && typeof window.document < "u";
}
function kr() {
  if (Ao()) return;
  let t = Mr[or];
  return or = (or + 1) % Mr.length, t;
}
var w = class extends Error {
  constructor(e) {
    super(e.message), this.name = "SdkError", this.code = e.code, this.provider = e.provider, this.url = e.url, this.status = e.status, this.details = e.details, e.cause !== void 0 && (this.cause = e.cause);
  }
};
var $ = class extends w {
  constructor(r, n, o, i) {
    let s = n ? ` ${n}` : "", u = o ? `, url: ${o}` : "", l = i ? `, provider: ${i}` : "";
    super({ code: r === 429 ? "RATE_LIMITED" : "HTTP_ERROR", message: `HTTP error! status: ${r}${s}${u}${l}`, status: r, url: o, provider: i, details: { statusText: n } });
    this.status = r;
    this.name = "HttpError", this.statusText = n;
  }
};
var ye = class extends w {
  constructor(e, r, n) {
    super({ code: "NOT_FOUND", message: e, provider: r, url: n }), this.name = "NotFoundError";
  }
};
function Te(t, e) {
  let r = t;
  return !r.sdkCode && e.sdkCode && (r.sdkCode = e.sdkCode), !r.provider && e.provider && (r.provider = e.provider), !r.url && e.url && (r.url = e.url), r.status === void 0 && e.status !== void 0 && (r.status = e.status), !r.details && e.details && (r.details = e.details), r;
}
function _o(t, e) {
  return Te(t, { provider: e.provider, url: e.url });
}
function W(t) {
  if (t instanceof w || t instanceof $) return t.code;
  if (t instanceof DOMException && t.name === "AbortError") return "TIMEOUT";
  if (t instanceof TypeError) return t.sdkCode ?? "NETWORK_ERROR";
  if (t instanceof Error) return t.sdkCode;
}
function Qe(t, e = {}) {
  return t instanceof w ? _o(t, e) : t instanceof DOMException && t.name === "AbortError" ? Te(t, { sdkCode: "TIMEOUT", provider: e.provider, url: e.url, details: e.timeout ? { timeout: e.timeout } : void 0 }) : t instanceof TypeError ? Te(t, { sdkCode: "NETWORK_ERROR", provider: e.provider, url: e.url }) : t instanceof Error ? Te(t, { sdkCode: "NETWORK_ERROR", provider: e.provider, url: e.url }) : new w({ code: "NETWORK_ERROR", message: "Unknown request error", provider: e.provider, url: e.url, cause: t });
}
var te = class extends w {
  constructor(e = "Circuit breaker is OPEN") {
    super({ code: "CIRCUIT_OPEN", message: e }), this.name = "CircuitBreakerError";
  }
};
var je = class {
  constructor(e = {}) {
    this.state = "CLOSED";
    this.failureCount = 0;
    this.lastFailureTime = 0;
    this.halfOpenSuccessCount = 0;
    this.failureThreshold = e.failureThreshold ?? 5, this.resetTimeout = e.resetTimeout ?? 3e4, this.halfOpenRequests = e.halfOpenRequests ?? 1, this.onStateChange = e.onStateChange;
  }
  getState() {
    return this.checkStateTransition(), this.state;
  }
  canRequest() {
    switch (this.checkStateTransition(), this.state) {
      case "CLOSED":
        return true;
      case "OPEN":
        return false;
      case "HALF_OPEN":
        return this.halfOpenSuccessCount < this.halfOpenRequests;
    }
  }
  recordSuccess() {
    this.checkStateTransition(), this.state === "HALF_OPEN" ? (this.halfOpenSuccessCount++, this.halfOpenSuccessCount >= this.halfOpenRequests && this.transitionTo("CLOSED")) : this.state === "CLOSED" && (this.failureCount = 0);
  }
  recordFailure() {
    this.lastFailureTime = Date.now(), this.state === "HALF_OPEN" ? this.transitionTo("OPEN") : this.state === "CLOSED" && (this.failureCount++, this.failureCount >= this.failureThreshold && this.transitionTo("OPEN"));
  }
  checkStateTransition() {
    this.state === "OPEN" && Date.now() - this.lastFailureTime >= this.resetTimeout && this.transitionTo("HALF_OPEN");
  }
  transitionTo(e) {
    if (this.state === e) return;
    let r = this.state;
    this.state = e, e === "CLOSED" ? (this.failureCount = 0, this.halfOpenSuccessCount = 0) : e === "HALF_OPEN" && (this.halfOpenSuccessCount = 0), this.onStateChange?.(r, e);
  }
  reset() {
    this.transitionTo("CLOSED"), this.failureCount = 0, this.halfOpenSuccessCount = 0, this.lastFailureTime = 0;
  }
  async execute(e) {
    if (!this.canRequest()) throw new te();
    try {
      let r = await e();
      return this.recordSuccess(), r;
    } catch (r) {
      throw this.recordFailure(), r;
    }
  }
  getStats() {
    return { state: this.getState(), failureCount: this.failureCount, lastFailureTime: this.lastFailureTime, halfOpenSuccessCount: this.halfOpenSuccessCount };
  }
};
var Io = 3e4;
var Po = 1;
var Lr = ["push2his.eastmoney.com", "7.push2his.eastmoney.com", "33.push2his.eastmoney.com", "63.push2his.eastmoney.com", "91.push2his.eastmoney.com"];
var Nr = ["17.push2.eastmoney.com", "29.push2.eastmoney.com", "79.push2.eastmoney.com", "91.push2.eastmoney.com"];
function Do(t, e) {
  return e !== "eastmoney" ? [t] : t.includes("push2his.eastmoney.com") ? Lr : t.includes("push2.eastmoney.com") ? Nr : [t];
}
function bo(t) {
  return Array.from(new Set(t));
}
var Ge = class {
  constructor(e = Io, r = Po) {
    this.cooldownMs = e;
    this.failureThreshold = r;
    this.states = /* @__PURE__ */ new Map();
  }
  getCandidateUrls(e, r) {
    let n;
    try {
      n = new URL(e);
    } catch {
      return [e];
    }
    let o = Date.now(), i = Do(n.hostname, r);
    if (i.length <= 1) return [e];
    let s = i.filter((c) => {
      let p = this.states.get(c);
      return !p || p.cooldownUntil <= o;
    }), u = i.filter((c) => {
      let p = this.states.get(c);
      return p && p.cooldownUntil > o;
    });
    return bo([...s.includes(n.hostname) ? [n.hostname] : [], ...s.filter((c) => c !== n.hostname), ...u.includes(n.hostname) ? [n.hostname] : [], ...u.filter((c) => c !== n.hostname)]).map((c) => {
      let p = new URL(e);
      return p.hostname = c, p.toString();
    });
  }
  recordSuccess(e) {
    let r = this.safeGetHost(e);
    if (!r) return;
    let n = this.getState(r);
    n.failureCount = 0, n.cooldownUntil = 0, n.successCount++, n.lastErrorCode = void 0;
  }
  recordFailure(e, r) {
    let n = this.safeGetHost(e);
    if (!n) return;
    let o = this.getState(n);
    o.failureCount++, o.lastFailureAt = Date.now(), o.lastErrorCode = W(r), o.failureCount >= this.failureThreshold && (o.cooldownUntil = Date.now() + this.cooldownMs);
  }
  shouldFallback(e) {
    let r = W(e);
    return r === "NETWORK_ERROR" || r === "TIMEOUT" ? true : e instanceof $ ? e.status === 408 || e.status === 429 || e.status >= 500 : false;
  }
  getStats(e) {
    let r = Array.from(this.states.values()).map((o) => ({ ...o }));
    if (!e) return r;
    if (e !== "eastmoney") return [];
    let n = /* @__PURE__ */ new Set([...Lr, ...Nr]);
    return r.filter((o) => n.has(o.host));
  }
  safeGetHost(e) {
    try {
      return new URL(e).hostname;
    } catch {
      return null;
    }
  }
  getState(e) {
    let r = this.states.get(e);
    if (r) return r;
    let n = { host: e, failureCount: 0, successCount: 0, cooldownUntil: 0, lastFailureAt: 0 };
    return this.states.set(e, n), n;
  }
};
function Mo(t) {
  return { maxRetries: t?.maxRetries ?? Jt, baseDelay: t?.baseDelay ?? er, maxDelay: t?.maxDelay ?? tr, backoffMultiplier: t?.backoffMultiplier ?? rr, retryableStatusCodes: t?.retryableStatusCodes ?? nr, retryOnNetworkError: t?.retryOnNetworkError ?? true, retryOnTimeout: t?.retryOnTimeout ?? true, onRetry: t?.onRetry };
}
function ko(t, e) {
  let r = { ...t ?? {} };
  return e && (Object.keys(r).some((o) => o.toLowerCase() === "user-agent") || (r["User-Agent"] = e)), r;
}
function xr(t, e) {
  return e ? { timeout: e.timeout ?? t.timeout, retry: e.retry ? { ...t.retry ?? {}, ...e.retry } : t.retry ? { ...t.retry } : void 0, headers: { ...t.headers ?? {}, ...e.headers ?? {} }, userAgent: e.userAgent ?? t.userAgent, rateLimit: e.rateLimit ? { ...t.rateLimit ?? {}, ...e.rateLimit } : t.rateLimit ? { ...t.rateLimit } : void 0, rotateUserAgent: e.rotateUserAgent ?? t.rotateUserAgent, circuitBreaker: e.circuitBreaker ? { ...t.circuitBreaker ?? {}, ...e.circuitBreaker } : t.circuitBreaker ? { ...t.circuitBreaker } : void 0 } : { ...t, headers: { ...t.headers ?? {} }, retry: t.retry ? { ...t.retry } : void 0, rateLimit: t.rateLimit ? { ...t.rateLimit } : void 0, circuitBreaker: t.circuitBreaker ? { ...t.circuitBreaker } : void 0 };
}
function ir(t = {}) {
  return { timeout: t.timeout ?? Zt, retry: Mo(t.retry), headers: ko(t.headers, t.userAgent), rotateUserAgent: t.rotateUserAgent ?? false, rateLimit: t.rateLimit ? { ...t.rateLimit } : void 0, circuitBreaker: t.circuitBreaker ? { ...t.circuitBreaker } : void 0 };
}
function Fr(t, e) {
  if (e) return e;
  try {
    let r = new URL(t).hostname;
    if (r.includes("eastmoney.com")) return "eastmoney";
    if (r.includes("gtimg.cn")) return "tencent";
    if (r.includes("sina.com.cn")) return "sina";
    if (r.includes("linkdiary.cn")) return "linkdiary";
  } catch {
    return "unknown";
  }
  return "unknown";
}
var Se = class {
  constructor(e = {}) {
    this.baseUrl = e.baseUrl ?? Ct;
    let r = { timeout: e.timeout, retry: e.retry, headers: e.headers, userAgent: e.userAgent, rateLimit: e.rateLimit, rotateUserAgent: e.rotateUserAgent, circuitBreaker: e.circuitBreaker };
    this.defaultPolicy = ir(r), this.providerPolicies = {}, this.runtimeStates = /* @__PURE__ */ new Map(), this.fallbackManager = new Ge();
    for (let [n, o] of Object.entries(e.providerPolicies ?? {})) {
      let i = xr(r, o);
      this.providerPolicies[n] = ir(i);
    }
  }
  getProviderState(e) {
    let r = this.runtimeStates.get(e);
    if (r) return r;
    let n = this.providerPolicies[e] ?? this.defaultPolicy, o = { policy: n, rateLimiter: n.rateLimit ? new ze(n.rateLimit) : null, circuitBreaker: n.circuitBreaker ? new je(n.circuitBreaker) : null };
    return this.runtimeStates.set(e, o), o;
  }
  getTimeout() {
    return this.defaultPolicy.timeout;
  }
  getHostHealth(e) {
    return this.fallbackManager.getStats(e);
  }
  calculateDelay(e, r) {
    return Math.min(r.baseDelay * Math.pow(r.backoffMultiplier, e), r.maxDelay) + Math.random() * 100;
  }
  sleep(e) {
    return new Promise((r) => setTimeout(r, e));
  }
  shouldRetry(e, r, n) {
    if (r >= n.maxRetries) return false;
    let o = W(e);
    return o === "TIMEOUT" ? n.retryOnTimeout : o === "NETWORK_ERROR" ? n.retryOnNetworkError : e instanceof $ ? n.retryableStatusCodes.includes(e.status) : false;
  }
  async executeWithRetry(e, r, n, o = 0) {
    try {
      return await e();
    } catch (i) {
      let s = Qe(i, n);
      if (this.shouldRetry(s, o, r)) {
        let u = this.calculateDelay(o, r);
        return r.onRetry && r.onRetry(o + 1, s, u), await this.sleep(u), this.executeWithRetry(e, r, n, o + 1);
      }
      throw s;
    }
  }
  async performRequest(e, r, n, o = "text") {
    r.rateLimiter && await r.rateLimiter.acquire();
    let i = new AbortController(), s = setTimeout(() => i.abort(), r.policy.timeout), u = { ...r.policy.headers };
    if (r.policy.rotateUserAgent) {
      let l = kr();
      if (l) {
        for (let c of Object.keys(u)) c.toLowerCase() === "user-agent" && delete u[c];
        u["User-Agent"] = l;
      }
    }
    try {
      let l = await fetch(e, { signal: i.signal, headers: u });
      if (!l.ok) throw new $(l.status, l.statusText, e, n);
      switch (o) {
        case "json":
          return await l.json();
        case "arraybuffer":
          return await l.arrayBuffer();
        default:
          return await l.text();
      }
    } finally {
      clearTimeout(s);
    }
  }
  async get(e, r = {}) {
    let n = Fr(e, r.provider), o = this.getProviderState(n);
    if (o.circuitBreaker && !o.circuitBreaker.canRequest()) throw new te("Circuit breaker is OPEN, request rejected");
    let i = this.fallbackManager.getCandidateUrls(e, n), s;
    for (let u = 0; u < i.length; u++) {
      let l = i[u], c = u === 0 ? o.policy.retry : { ...o.policy.retry, maxRetries: 0 };
      try {
        let p = await this.executeWithRetry(() => this.performRequest(l, o, n, r.responseType), c, { provider: n, url: l, timeout: o.policy.timeout });
        return o.circuitBreaker?.recordSuccess(), this.fallbackManager.recordSuccess(l), p;
      } catch (p) {
        let d = Qe(p, { provider: n, url: l, timeout: o.policy.timeout });
        if (s = d, this.fallbackManager.recordFailure(l, d), u < i.length - 1 && this.fallbackManager.shouldFallback(d)) continue;
        throw o.circuitBreaker?.recordFailure(), d;
      }
    }
    throw o.circuitBreaker?.recordFailure(), s ?? new te("Request failed without a concrete error");
  }
  async getTencentQuote(e) {
    let r = `${this.baseUrl}/?q=${encodeURIComponent(e)}`, n = await this.get(r, { responseType: "arraybuffer", provider: "tencent" }), o = Ue(n);
    return Be(o);
  }
};
var Lo = /* @__PURE__ */ new Set(["daily", "weekly", "monthly"]);
var No = /* @__PURE__ */ new Set(["1", "5", "15", "30", "60"]);
var xo = /* @__PURE__ */ new Set(["", "qfq", "hfq"]);
function z(t, e) {
  if (!Number.isFinite(t) || !Number.isInteger(t) || t <= 0) throw new RangeError(`${e} must be a positive integer`);
}
function U(t) {
  if (!Lo.has(t)) throw new RangeError("period must be one of: daily, weekly, monthly");
}
function Re(t) {
  if (!No.has(t)) throw new RangeError("period must be one of: 1, 5, 15, 30, 60");
}
function G(t) {
  if (!xo.has(t)) throw new RangeError("adjust must be one of: '', 'qfq', 'hfq'");
}
function re(t, e) {
  z(e, "chunkSize");
  let r = [];
  for (let n = 0; n < t.length; n += e) r.push(t.slice(n, n + e));
  return r;
}
async function ne(t, e, r = false) {
  if (z(e, "concurrency"), t.length === 0) return [];
  let n = r ? new Array(t.length) : [], o = 0, i = Array.from({ length: Math.min(e, t.length) }, async () => {
    for (; ; ) {
      let s = o++;
      if (s >= t.length) return;
      let u = await t[s]();
      r ? n[s] = u : n.push(u);
    }
  });
  return await Promise.all(i), n;
}
function oe(t) {
  return t.startsWith("sh") ? "1" : t.startsWith("sz") || t.startsWith("bj") ? "0" : t.startsWith("6") ? "1" : "0";
}
function B(t) {
  return { daily: "101", weekly: "102", monthly: "103" }[t];
}
function Y(t) {
  return { "": "0", qfq: "1", hfq: "2" }[t];
}
var Ye = class {
  constructor(e = {}) {
    this.cache = /* @__PURE__ */ new Map();
    this.inflight = /* @__PURE__ */ new Map();
    this.defaultTTL = e.defaultTTL ?? 0, this.maxSize = e.maxSize ?? 1e3;
  }
  get(e) {
    let r = this.cache.get(e);
    if (r) {
      if (r.expireAt > 0 && Date.now() > r.expireAt) {
        this.cache.delete(e);
        return;
      }
      return r.lastAccess = Date.now(), r.value;
    }
  }
  set(e, r, n) {
    this.cache.size >= this.maxSize && !this.cache.has(e) && this.evictLRU();
    let o = n ?? this.defaultTTL, i = Date.now();
    this.cache.set(e, { value: r, expireAt: o > 0 ? i + o : 0, lastAccess: i });
  }
  has(e) {
    return this.get(e) !== void 0;
  }
  delete(e) {
    return this.cache.delete(e);
  }
  clear() {
    this.cache.clear(), this.inflight.clear();
  }
  get size() {
    return this.cache.size;
  }
  cleanup() {
    let e = Date.now(), r = 0;
    for (let [n, o] of this.cache) o.expireAt > 0 && e > o.expireAt && (this.cache.delete(n), r++);
    return r;
  }
  evictLRU() {
    let e = null, r = 1 / 0;
    for (let [n, o] of this.cache) o.lastAccess < r && (r = o.lastAccess, e = n);
    e && this.cache.delete(e);
  }
  async getOrFetch(e, r, n) {
    let o = this.get(e);
    if (o !== void 0) return o;
    let i = this.inflight.get(e);
    if (i) return i;
    let s = r().then((u) => (this.set(e, u, n), u)).finally(() => {
      this.inflight.delete(e);
    });
    return this.inflight.set(e, s), s;
  }
};
var vr = /* @__PURE__ */ new Map();
function X(t, e) {
  let r = vr.get(t);
  if (r) return r;
  let n = new Ye(e);
  return vr.set(t, n), n;
}
var Fo = typeof document < "u" && typeof window < "u";
var vo = 0;
function wr() {
  return `__stock_sdk_jsonp_${Date.now()}_${vo++}`;
}
function sr(t) {
  let e = t, r = e.indexOf("*/");
  r !== -1 && (e = e.slice(r + 2).trim());
  let n = e.indexOf("(");
  if (n === -1) throw new Error("Invalid JSONP response: no opening parenthesis found");
  let o = e.lastIndexOf(")");
  if (o === -1 || o <= n) throw new Error("Invalid JSONP response: no closing parenthesis found");
  let i = e.slice(n + 1, o);
  return JSON.parse(i);
}
function wo(t, e) {
  let { timeout: r = 15e3, callbackParam: n = "callback", callbackMode: o = "query" } = e;
  return new Promise((i, s) => {
    let u = wr(), l;
    if (o === "path") l = t.replace("{callback}", u);
    else {
      let S = t.includes("?") ? "&" : "?";
      l = `${t}${S}${n}=${u}`;
    }
    let c = document.createElement("script"), p = false, d = window, g = () => {
      c.parentNode && c.parentNode.removeChild(c), delete d[u];
    }, h = setTimeout(() => {
      p || (p = true, g(), s(new Error(`JSONP request timed out after ${r}ms: ${t}`)));
    }, r);
    d[u] = (S) => {
      p || (p = true, clearTimeout(h), g(), i(S));
    }, c.onerror = () => {
      p || (p = true, clearTimeout(h), g(), s(new Error(`JSONP script load failed: ${t}`)));
    }, c.src = l, document.head.appendChild(c);
  });
}
async function Uo(t, e) {
  let { timeout: r = 15e3, callbackParam: n = "callback", callbackMode: o = "query" } = e, i = wr(), s;
  if (o === "path") s = t.replace("{callback}", i);
  else {
    let c = t.includes("?") ? "&" : "?";
    s = `${t}${c}${n}=${i}`;
  }
  let u = new AbortController(), l = setTimeout(() => u.abort(), r);
  try {
    let c = await fetch(s, { signal: u.signal });
    if (!c.ok) throw new Error(`JSONP fetch failed with status ${c.status}: ${t}`);
    let p = await c.text();
    return sr(p);
  } catch (c) {
    throw c instanceof DOMException && c.name === "AbortError" ? new Error(`JSONP request timed out after ${r}ms: ${t}`) : c;
  } finally {
    clearTimeout(l);
  }
}
function N(t, e = {}) {
  return Fo ? wo(t, e) : Uo(t, e);
}
var O = { CN: "Asia/Shanghai", HK: "Asia/Hong_Kong", US: "America/New_York" };
function Bo(t) {
  if (!t) return null;
  let e = t.trim();
  if (!e) return null;
  let r = /^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2})(?::(\d{2}))?$/.exec(e);
  if (r) return { year: +r[1], month: +r[2], day: +r[3], hour: +r[4], minute: +r[5], second: r[6] ? +r[6] : 0 };
  let n = /^(\d{4})-(\d{2})-(\d{2})$/.exec(e);
  return n ? { year: +n[1], month: +n[2], day: +n[3], hour: 0, minute: 0, second: 0 } : /^\d{14}$/.test(e) ? { year: +e.slice(0, 4), month: +e.slice(4, 6), day: +e.slice(6, 8), hour: +e.slice(8, 10), minute: +e.slice(10, 12), second: +e.slice(12, 14) } : /^\d{8}$/.test(e) ? { year: +e.slice(0, 4), month: +e.slice(4, 6), day: +e.slice(6, 8), hour: 0, minute: 0, second: 0 } : null;
}
function Ur(t, e) {
  let r = Date.UTC(t.year, t.month - 1, t.day, t.hour, t.minute, t.second), o = new Intl.DateTimeFormat("en-US", { timeZone: e, hour12: false, year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit" }).formatToParts(new Date(r)), i = {};
  for (let c of o) c.type !== "literal" && (i[c.type] = c.value);
  let s = parseInt(i.hour ?? "0", 10);
  s === 24 && (s = 0);
  let u = Date.UTC(parseInt(i.year ?? "0", 10), parseInt(i.month ?? "1", 10) - 1, parseInt(i.day ?? "1", 10), s, parseInt(i.minute ?? "0", 10), parseInt(i.second ?? "0", 10)), l = r - u;
  return r + l;
}
function Ko(t, e) {
  let r = (t || "").trim(), n = /^(\d{4})-(\d{2})-(\d{2})$/.exec(r) ?? /^(\d{4})(\d{2})(\d{2})$/.exec(r);
  if (!n) return null;
  let o = /^(\d{2}):(\d{2})(?::(\d{2}))?$/.exec((e || "").trim());
  return o ? { year: +n[1], month: +n[2], day: +n[3], hour: +o[1], minute: +o[2], second: o[3] ? +o[3] : 0 } : null;
}
function ar(t, e) {
  let r = Bo(t);
  return r ? Ur(r, e) : NaN;
}
function D(t, e) {
  return { timestamp: ar(t, e), tz: e };
}
function Ve(t, e, r) {
  let n = Ko(t, e);
  return n ? { timestamp: Ur(n, r), tz: r } : { timestamp: NaN, tz: r };
}
var I = {};
Et(I, { getAShareCodeList: () => Qr, getAllHKQuotesByCodes: () => Vr, getAllQuotesByCodes: () => Yr, getAllUSQuotesByCodes: () => Wr, getFullQuotes: () => We, getFundCodeList: () => Xr, getFundFlow: () => Kr, getFundQuotes: () => qr, getHKCodeList: () => Gr, getHKQuotes: () => Xe, getPanelLargeOrder: () => Hr, getSimpleQuotes: () => Br, getTodayTimeline: () => $r, getTradingCalendar: () => Zr, getUSCodeList: () => jr, getUSQuotes: () => Ze, parseFullQuote: () => ur, parseFundFlow: () => cr, parseFundQuote: () => gr, parseHKQuote: () => dr, parsePanelLargeOrder: () => pr, parseSimpleQuote: () => lr, parseUSQuote: () => mr, search: () => en });
function ur(t) {
  let e = [];
  for (let i = 0; i < 5; i++) e.push({ price: T(t[9 + i * 2]), volume: T(t[10 + i * 2]) });
  let r = [];
  for (let i = 0; i < 5; i++) r.push({ price: T(t[19 + i * 2]), volume: T(t[20 + i * 2]) });
  let n = t[30] ?? "", o = D(n, O.CN);
  return { marketId: t[0] ?? "", name: t[1] ?? "", code: t[2] ?? "", price: T(t[3]), prevClose: T(t[4]), open: T(t[5]), volume: T(t[6]), outerVolume: T(t[7]), innerVolume: T(t[8]), bid: e, ask: r, time: n, timestamp: o.timestamp, tz: o.tz, change: T(t[31]), changePercent: T(t[32]), high: T(t[33]), low: T(t[34]), volume2: T(t[36]), amount: T(t[37]), turnoverRate: C(t[38]), pe: C(t[39]), amplitude: C(t[43]), circulatingMarketCap: C(t[44]), totalMarketCap: C(t[45]), pb: C(t[46]), limitUp: C(t[47]), limitDown: C(t[48]), volumeRatio: C(t[49]), avgPrice: C(t[51]), peStatic: C(t[52]), peDynamic: C(t[53]), high52w: C(t[67]), low52w: C(t[68]), circulatingShares: C(t[72]), totalShares: C(t[73]), raw: t };
}
function lr(t) {
  return { marketId: t[0] ?? "", name: t[1] ?? "", code: t[2] ?? "", price: T(t[3]), change: T(t[4]), changePercent: T(t[5]), volume: T(t[6]), amount: T(t[7]), marketCap: C(t[9]), marketType: t[10] ?? "", raw: t };
}
function cr(t) {
  let e = t[13] ?? "", r = D(e, O.CN);
  return { code: t[0] ?? "", mainInflow: T(t[1]), mainOutflow: T(t[2]), mainNet: T(t[3]), mainNetRatio: T(t[4]), retailInflow: T(t[5]), retailOutflow: T(t[6]), retailNet: T(t[7]), retailNetRatio: T(t[8]), totalFlow: T(t[9]), name: t[12] ?? "", date: e, timestamp: r.timestamp, tz: r.tz, raw: t };
}
function pr(t) {
  return { buyLargeRatio: T(t[0]), buySmallRatio: T(t[1]), sellLargeRatio: T(t[2]), sellSmallRatio: T(t[3]), raw: t };
}
function dr(t) {
  let e = t[30] ?? "", r = D(e, O.HK);
  return { marketId: t[0] ?? "", name: t[1] ?? "", code: t[2] ?? "", price: T(t[3]), prevClose: T(t[4]), open: T(t[5]), volume: T(t[6]), time: e, timestamp: r.timestamp, tz: r.tz, change: T(t[31]), changePercent: T(t[32]), high: T(t[33]), low: T(t[34]), amount: T(t[37]), lotSize: C(t[40]), circulatingMarketCap: C(t[44]), totalMarketCap: C(t[45]), currency: t[t.length - 3] ?? "", raw: t };
}
function mr(t) {
  let e = t[30] ?? "", r = D(e, O.US);
  return { marketId: t[0] ?? "", name: t[1] ?? "", code: t[2] ?? "", price: T(t[3]), prevClose: T(t[4]), open: T(t[5]), volume: T(t[6]), time: e, timestamp: r.timestamp, tz: r.tz, change: T(t[31]), changePercent: T(t[32]), high: T(t[33]), low: T(t[34]), amount: T(t[37]), turnoverRate: C(t[38]), pe: C(t[39]), amplitude: C(t[43]), totalMarketCap: C(t[45]), pb: C(t[47]), high52w: C(t[48]), low52w: C(t[49]), raw: t };
}
function gr(t) {
  let e = t[8] ?? "", r = D(e, O.CN);
  return { code: t[0] ?? "", name: t[1] ?? "", nav: T(t[5]), accNav: T(t[6]), change: T(t[7]), navDate: e, timestamp: r.timestamp, tz: r.tz, raw: t };
}
async function We(t, e) {
  if (!e || e.length === 0) return [];
  let r = await t.getTencentQuote(e.join(",")), n = new Set(e);
  return r.filter((o) => n.has(o.key) && o.fields && o.fields.length > 5 && o.fields[0] !== "").map((o) => ur(o.fields));
}
async function Br(t, e) {
  if (!e || e.length === 0) return [];
  let r = e.map((i) => `s_${i}`), n = await t.getTencentQuote(r.join(",")), o = new Set(r);
  return n.filter((i) => o.has(i.key) && i.fields && i.fields.length > 5 && i.fields[0] !== "").map((i) => lr(i.fields));
}
async function Kr(t, e) {
  if (!e || e.length === 0) return [];
  let r = e.map((i) => `ff_${i}`), n = await t.getTencentQuote(r.join(",")), o = new Set(r);
  return n.filter((i) => o.has(i.key) && i.fields && i.fields.length >= 14 && i.fields[0] !== "").map((i) => cr(i.fields));
}
async function Hr(t, e) {
  if (!e || e.length === 0) return [];
  let r = e.map((i) => `s_pk${i}`), n = await t.getTencentQuote(r.join(",")), o = new Set(r);
  return n.filter((i) => o.has(i.key) && i.fields && i.fields.length >= 4 && i.fields[0] !== "").map((i) => pr(i.fields));
}
async function Xe(t, e) {
  if (!e || e.length === 0) return [];
  let r = e.map((i) => `hk${i}`), n = await t.getTencentQuote(r.join(",")), o = new Set(r);
  return n.filter((i) => o.has(i.key) && i.fields && i.fields.length > 5 && i.fields[0] !== "").map((i) => dr(i.fields));
}
async function Ze(t, e) {
  if (!e || e.length === 0) return [];
  let r = e.map((i) => `us${i}`), n = await t.getTencentQuote(r.join(",")), o = new Set(r);
  return n.filter((i) => o.has(i.key) && i.fields && i.fields.length > 5 && i.fields[0] !== "").map((i) => mr(i.fields));
}
async function qr(t, e) {
  if (!e || e.length === 0) return [];
  let r = e.map((i) => `jj${i}`), n = await t.getTencentQuote(r.join(",")), o = new Set(r);
  return n.filter((i) => o.has(i.key) && i.fields && i.fields.length >= 9 && i.fields[0] !== "").map((i) => gr(i.fields));
}
async function $r(t, e) {
  let r = `${Ot}?code=${encodeURIComponent(e)}`, n = await t.get(r, { responseType: "json", provider: "tencent" });
  if (n.code !== 0) throw new Error(n.msg || "API error");
  let o = n.data?.[e];
  if (!o) {
    let g = D("", O.CN);
    return { code: e, date: "", timestamp: g.timestamp, tz: g.tz, preClose: 0, data: [] };
  }
  let i = o.data?.data ?? [], s = o.data?.date ?? "", u = o.qt?.[e] ?? [], l = parseFloat(u[4] ?? "") || 0, c = false;
  if (i.length > 0) {
    let g = i[0].split(" "), h = parseFloat(g[1]) || 0, S = parseInt(g[2], 10) || 0, f = parseFloat(g[3]) || 0;
    S > 0 && h > 0 && f / S > h * 50 && (c = true);
  }
  let p = i.map((g) => {
    let h = g.split(" "), S = h[0], f = `${S.slice(0, 2)}:${S.slice(2, 4)}`, R = parseInt(h[2], 10) || 0, E = parseFloat(h[3]) || 0, P = c ? R * 100 : R, b = P > 0 ? E / P : 0, M = Ve(s, f, O.CN);
    return { time: f, timestamp: M.timestamp, tz: M.tz, price: parseFloat(h[1]) || 0, volume: P, amount: E, avgPrice: Math.round(b * 100) / 100 };
  }), d = D(s, O.CN);
  return { code: e, date: s, timestamp: d.timestamp, tz: d.tz, preClose: l, data: p };
}
var zr = X("tencent:code-lists", { defaultTTL: 360 * 60 * 1e3, maxSize: 16 });
async function fr(t, e, r) {
  return zr.getOrFetch(e, async () => (await t.get(r, { responseType: "json" }))?.list || []);
}
function Ho(t, e) {
  let r = t.replace(/^(sh|sz|bj)/, "");
  switch (e) {
    case "sh":
      return r.startsWith("6");
    case "sz":
      return r.startsWith("0") || r.startsWith("3");
    case "bj":
      return r.startsWith("92");
    case "kc":
      return r.startsWith("688");
    case "cy":
      return r.startsWith("30");
    default:
      return true;
  }
}
async function Qr(t, e) {
  let r = false, n;
  typeof e == "boolean" ? r = !e : e && (r = e.simple ?? false, n = e.market);
  let i = await fr(t, "a-share:full", At);
  return n && (i = i.filter((s) => Ho(s, n))), r ? i.map((s) => s.replace(/^(sh|sz|bj)/, "")) : i.slice();
}
var qo = { NASDAQ: "105.", NYSE: "106.", AMEX: "107." };
async function jr(t, e) {
  let r = false, n;
  typeof e == "boolean" ? r = !e : e && (r = e.simple ?? false, n = e.market);
  let i = (await fr(t, "us:full", _t)).slice();
  if (n) {
    let s = qo[n];
    i = i.filter((u) => u.startsWith(s));
  }
  return r ? i.map((s) => s.replace(/^\d{3}\./, "")) : i;
}
async function Gr(t) {
  return (await fr(t, "hk:full", It)).slice();
}
async function Yr(t, e, r = {}) {
  let { batchSize: n = ge, concurrency: o = he, onProgress: i } = r;
  z(n, "batchSize"), z(o, "concurrency");
  let s = Math.min(n, fe), u = re(e, s), l = u.length, c = 0, p = u.map((g) => async () => {
    let h = await We(t, g);
    return c++, i && i(c, l), h;
  });
  return (await ne(p, o, true)).flat();
}
async function Vr(t, e, r = {}) {
  let { batchSize: n = ge, concurrency: o = he, onProgress: i } = r;
  z(n, "batchSize"), z(o, "concurrency");
  let s = Math.min(n, fe), u = re(e, s), l = u.length, c = 0, p = u.map((g) => async () => {
    let h = await Xe(t, g);
    return c++, i && i(c, l), h;
  });
  return (await ne(p, o, true)).flat();
}
async function Wr(t, e, r = {}) {
  let { batchSize: n = ge, concurrency: o = he, onProgress: i } = r;
  z(n, "batchSize"), z(o, "concurrency");
  let s = Math.min(n, fe), u = re(e, s), l = u.length, c = 0, p = u.map((g) => async () => {
    let h = await Ze(t, g);
    return c++, i && i(c, l), h;
  });
  return (await ne(p, o, true)).flat();
}
async function Xr(t) {
  return (await zr.getOrFetch("fund:full", async () => (await t.get(Pt, { responseType: "text" })).split(",").slice(1).filter((o) => o.trim()))).slice();
}
var $o = X("tencent:trade-calendar", { defaultTTL: 720 * 60 * 1e3, maxSize: 4 });
async function Zr(t) {
  return (await $o.getOrFetch("a-share", async () => {
    let r = await t.get(br);
    return !r || r.trim() === "" ? [] : r.trim().split(",").map((n) => n.trim()).filter((n) => n.length > 0);
  })).slice();
}
var Jr = "https://smartbox.gtimg.cn/s3/";
function zo(t) {
  return t.replace(/\\u([0-9a-fA-F]{4})/g, (e, r) => String.fromCharCode(parseInt(r, 16)));
}
function Qo(t) {
  let e = t.toUpperCase();
  return e.startsWith("QDII") || e.startsWith("ETF") || e.startsWith("LOF") || e.startsWith("KJ") || e.startsWith("JJ") || e.includes("FUND") ? "fund" : e.startsWith("GP") || e.includes("STOCK") ? "stock" : e === "ZS" || e.includes("INDEX") ? "index" : e.startsWith("ZQ") || e.includes("BOND") ? "bond" : e.startsWith("QH") || e.includes("FUTURE") ? "futures" : e.startsWith("QZ") || e.includes("OPTION") ? "option" : "other";
}
function jo(t) {
  return !t || t === "N" ? [] : t.split("^").filter(Boolean).map((r) => {
    let n = r.split("~"), o = n[0] || "", i = n[1] || "", s = zo(n[2] || ""), u = n[4] || "";
    return { code: o + i, name: s, market: o, type: u, category: Qo(u) };
  });
}
function Go(t) {
  return new Promise((e, r) => {
    let n = `${Jr}?v=2&t=all&q=${encodeURIComponent(t)}`;
    window.v_hint = "";
    let o = document.createElement("script");
    o.src = n, o.charset = "utf-8", o.onload = () => {
      let i = window.v_hint || "";
      document.body.removeChild(o), e(i);
    }, o.onerror = () => {
      document.body.removeChild(o), r(new Error("Network error calling Smartbox"));
    }, document.body.appendChild(o);
  });
}
async function Yo(t, e) {
  let r = `${Jr}?v=2&t=all&q=${encodeURIComponent(e)}`, o = (await t.get(r)).match(/v_hint="([^"]*)"/);
  return o ? o[1] : "";
}
function Vo() {
  return typeof window < "u" && typeof document < "u";
}
async function en(t, e) {
  if (!e || !e.trim()) return [];
  let r;
  return Vo() ? r = await Go(e) : r = await Yo(t, e), jo(r);
}
var y = {};
Et(y, { extractVariety: () => yr, fetchDatacenter: () => Tr, fetchDatacenterList: () => A, getBlockTradeDailyStat: () => uo, getBlockTradeDetail: () => ao, getBlockTradeMarketStat: () => so, getBoardChanges: () => Xn, getCFFEXOptionQuotes: () => Pn, getComexInventory: () => Ln, getConceptConstituents: () => Sn, getConceptKline: () => Rn, getConceptList: () => Tn, getConceptMinuteKline: () => En, getConceptSpot: () => yn, getDividendDetail: () => Cn, getDragonTigerBranchRank: () => ro, getDragonTigerDetail: () => Jn, getDragonTigerInstitution: () => to, getDragonTigerStockSeatDetail: () => no, getDragonTigerStockStats: () => eo, getFundFlowRank: () => Bn, getFuturesHistoryKline: () => An, getFuturesInventory: () => kn, getFuturesInventorySymbols: () => Mn, getFuturesMarketCode: () => Sr, getGlobalFuturesKline: () => In, getGlobalFuturesSpot: () => _n, getHKHistoryKline: () => nn, getHistoryKline: () => tn, getIndividualFundFlow: () => wn, getIndustryConstituents: () => gn, getIndustryKline: () => fn, getIndustryList: () => dn, getIndustryMinuteKline: () => hn, getIndustrySpot: () => mn, getMarginAccountInfo: () => lo, getMarginTargetList: () => co, getMarketFundFlow: () => Un, getMinuteKline: () => rn, getNorthboundFlowSummary: () => Qn, getNorthboundHistory: () => Gn, getNorthboundHoldingRank: () => jn, getNorthboundIndividual: () => Yn, getNorthboundMinute: () => zn, getOptionLHB: () => Dn, getSectorFundFlowHistory: () => Hn, getSectorFundFlowRank: () => Kn, getStockChanges: () => Wn, getUSHistoryKline: () => on, getZTPool: () => Vn });
async function hr(t, e, r, n, o = 100, i) {
  let s = [], u = 1, l = 0;
  do {
    let c = new URLSearchParams({ ...r, pn: String(u), pz: String(o), fields: n }), p = `${e}?${c.toString()}`, g = (await t.get(p, { responseType: "json" }))?.data;
    if (!g || !Array.isArray(g.diff)) break;
    u === 1 && (l = g.total ?? 0);
    let h = g.diff.map((S, f) => i(S, s.length + f + 1));
    s.push(...h), u++;
  } while (s.length < l);
  return s;
}
function K(t) {
  let [e, r, n, o, i, s, u, l, c, p, d] = t.split(",");
  return { date: e, open: m(r), close: m(n), high: m(o), low: m(i), volume: m(s), amount: m(u), amplitude: m(l), changePercent: m(c), change: m(p), turnoverRate: m(d) };
}
async function H(t, e, r) {
  let n = `${e}?${r.toString()}`, o = await t.get(n, { responseType: "json" });
  return { klines: o?.data?.klines || [], name: o?.data?.name, code: o?.data?.code };
}
async function tn(t, e, r = {}) {
  let { period: n = "daily", adjust: o = "qfq", startDate: i = "19700101", endDate: s = "20500101" } = r;
  U(n), G(o);
  let u = e.replace(/^(sh|sz|bj)/, ""), l = `${oe(e)}.${u}`, c = new URLSearchParams({ fields1: "f1,f2,f3,f4,f5,f6", fields2: "f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61,f116", ut: L, klt: B(n), fqt: Y(o), secid: l, beg: i, end: s }), p = Ke, { klines: d } = await H(t, p, c);
  return d.length === 0 ? [] : d.map((g) => {
    let h = K(g), S = D(h.date, O.CN);
    return { ...h, timestamp: S.timestamp, tz: S.tz, code: u };
  });
}
async function rn(t, e, r = {}) {
  let { period: n = "1", adjust: o = "qfq", startDate: i = "1979-09-01 09:32:00", endDate: s = "2222-01-01 09:32:00" } = r;
  Re(n), G(o);
  let u = e.replace(/^(sh|sz|bj)/, ""), l = `${oe(e)}.${u}`;
  if (n === "1") {
    let c = new URLSearchParams({ fields1: "f1,f2,f3,f4,f5,f6,f7,f8,f9,f10,f11,f12,f13", fields2: "f51,f52,f53,f54,f55,f56,f57,f58", ut: L, ndays: "5", iscr: "0", secid: l }), p = `${Dt}?${c.toString()}`, g = (await t.get(p, { responseType: "json" }))?.data?.trends;
    if (!Array.isArray(g) || g.length === 0) return [];
    let h = i.replace("T", " ").slice(0, 16), S = s.replace("T", " ").slice(0, 16);
    return g.map((f) => {
      let [R, E, P, b, M, q, V, j] = f.split(","), we = D(R, O.CN);
      return { time: R, timestamp: we.timestamp, tz: we.tz, open: m(E), close: m(P), high: m(b), low: m(M), volume: m(q), amount: m(V), avgPrice: m(j) };
    }).filter((f) => f.time >= h && f.time <= S);
  } else {
    let c = new URLSearchParams({ fields1: "f1,f2,f3,f4,f5,f6", fields2: "f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61", ut: L, klt: n, fqt: Y(o || ""), secid: l, beg: "0", end: "20500000" }), p = Ke, { klines: d } = await H(t, p, c);
    if (d.length === 0) return [];
    let g = i.replace("T", " ").slice(0, 16), h = s.replace("T", " ").slice(0, 16);
    return d.map((S) => {
      let f = K(S), R = D(f.date, O.CN);
      return { ...f, time: f.date, timestamp: R.timestamp, tz: R.tz };
    }).filter((S) => S.time >= g && S.time <= h);
  }
}
function Je(t) {
  return async function(r, n, o = {}) {
    let { period: i = "daily", adjust: s = "qfq", startDate: u = "19700101", endDate: l = "20500101" } = o;
    U(i), G(s);
    let c = t.normalizeSymbol(n), p = new URLSearchParams({ fields1: "f1,f2,f3,f4,f5,f6", fields2: "f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61", ut: L, klt: B(i), fqt: Y(s), secid: c.secid, beg: u, end: l, lmt: "1000000" }), { klines: d, name: g, code: h } = await H(r, t.url, p);
    if (d.length === 0) return [];
    let S = t.resolveResultMeta ? t.resolveResultMeta(n, c, { code: h, name: g }) : { code: h || c.fallbackCode, name: g || "" };
    return d.map((f) => {
      let R = K(f), E = D(R.date, t.tz), P = { ...R, timestamp: E.timestamp, tz: E.tz, code: S.code, name: S.name };
      return t.enrichItem(P);
    });
  };
}
var Wo = Je({ url: bt, tz: O.HK, normalizeSymbol: (t) => {
  let e = t.replace(/^hk/i, "").padStart(5, "0");
  return { secid: `116.${e}`, fallbackCode: e };
}, enrichItem: (t) => ({ ...t, currency: "HKD", lotSize: null }) });
async function nn(t, e, r = {}) {
  return Wo(t, e, r);
}
var Xo = Je({ url: Mt, tz: O.US, normalizeSymbol: (t) => ({ secid: t, fallbackCode: t.split(".")[1] || t }), resolveResultMeta: (t, e, r) => ({ code: r.code || e.fallbackCode, name: r.name || "" }), enrichItem: (t) => ({ ...t, currency: "USD" }) });
async function on(t, e, r = {}) {
  return Xo(t, e, r);
}
function sn(t) {
  let e = X(`eastmoney:board-code-map:${t.type}`, { defaultTTL: 36e5, maxSize: 4 });
  return { async getCode(r, n, o) {
    if (n.startsWith("BK")) return n;
    let s = (await e.getOrFetch("name-code-map", async () => {
      let u = await o(r);
      return Object.fromEntries(u.map((l) => [l.name, l.code]));
    }))[n];
    if (!s) throw new ye(`${t.errorPrefix}: ${n}`, "eastmoney");
    return s;
  } };
}
async function an(t, e) {
  let r = { po: "1", np: "1", ut: "bd1d9ddb04089700cf9c27f6f7426281", fltt: "2", invt: "2", fid: e.type === "concept" ? "f12" : "f3", fs: e.fsFilter }, n = e.type === "concept" ? "f2,f3,f4,f8,f12,f14,f15,f16,f17,f18,f20,f21,f24,f25,f22,f33,f11,f62,f128,f124,f107,f104,f105,f136" : "f1,f2,f3,f4,f5,f6,f7,f8,f9,f10,f12,f13,f14,f15,f16,f17,f18,f20,f21,f23,f24,f25,f26,f22,f33,f11,f62,f128,f136,f115,f152,f124,f107,f104,f105,f140,f141,f207,f208,f209,f222", o = await hr(t, e.listUrl, r, n, 100, (i, s) => ({ rank: s, name: String(i.f14 ?? ""), code: String(i.f12 ?? ""), price: a(i.f2), change: a(i.f4), changePercent: a(i.f3), totalMarketCap: a(i.f20), turnoverRate: a(i.f8), riseCount: a(i.f104), fallCount: a(i.f105), leadingStock: i.f128 ? String(i.f128) : null, leadingStockChangePercent: a(i.f136) }));
  return o.sort((i, s) => (s.changePercent ?? 0) - (i.changePercent ?? 0)), o.forEach((i, s) => {
    i.rank = s + 1;
  }), o;
}
async function un(t, e, r) {
  let n = new URLSearchParams({ fields: "f43,f44,f45,f46,f47,f48,f170,f171,f168,f169", mpi: "1000", invt: "2", fltt: "1", secid: `90.${e}` }), o = `${r}?${n.toString()}`, s = (await t.get(o, { responseType: "json" }))?.data;
  return s ? [{ key: "f43", name: "\u6700\u65B0", divide: true }, { key: "f44", name: "\u6700\u9AD8", divide: true }, { key: "f45", name: "\u6700\u4F4E", divide: true }, { key: "f46", name: "\u5F00\u76D8", divide: true }, { key: "f47", name: "\u6210\u4EA4\u91CF", divide: false }, { key: "f48", name: "\u6210\u4EA4\u989D", divide: false }, { key: "f170", name: "\u6DA8\u8DCC\u5E45", divide: true }, { key: "f171", name: "\u632F\u5E45", divide: true }, { key: "f168", name: "\u6362\u624B\u7387", divide: true }, { key: "f169", name: "\u6DA8\u8DCC\u989D", divide: true }].map(({ key: l, name: c, divide: p }) => {
    let d = s[l], g = null;
    return typeof d == "number" && !isNaN(d) && (g = p ? d / 100 : d), { item: c, value: g };
  }) : [];
}
async function ln(t, e, r) {
  let n = { po: "1", np: "1", ut: "bd1d9ddb04089700cf9c27f6f7426281", fltt: "2", invt: "2", fid: "f3", fs: `b:${e} f:!50` };
  return hr(t, r, n, "f1,f2,f3,f4,f5,f6,f7,f8,f9,f10,f12,f13,f14,f15,f16,f17,f18,f20,f21,f23,f24,f25,f22,f11,f62,f128,f136,f115,f152,f45", 100, (i, s) => ({ rank: s, code: String(i.f12 ?? ""), name: String(i.f14 ?? ""), price: a(i.f2), changePercent: a(i.f3), change: a(i.f4), volume: a(i.f5), amount: a(i.f6), amplitude: a(i.f7), high: a(i.f15), low: a(i.f16), open: a(i.f17), prevClose: a(i.f18), turnoverRate: a(i.f8), pe: a(i.f9), pb: a(i.f23) }));
}
async function cn(t, e, r, n = {}) {
  let { period: o = "daily", adjust: i = "", startDate: s = "19700101", endDate: u = "20500101" } = n;
  U(o), G(i);
  let l = new URLSearchParams({ secid: `90.${e}`, fields1: "f1,f2,f3,f4,f5,f6", fields2: "f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61", klt: B(o), fqt: Y(i), beg: s, end: u, smplmt: "10000", lmt: "1000000" }), { klines: c } = await H(t, r, l);
  return c.length === 0 ? [] : c.map((p) => K(p));
}
async function pn(t, e, r, n, o = {}) {
  let { period: i = "5" } = o;
  if (Re(i), i === "1") {
    let s = new URLSearchParams({ fields1: "f1,f2,f3,f4,f5,f6,f7,f8,f9,f10,f11,f12,f13", fields2: "f51,f52,f53,f54,f55,f56,f57,f58", iscr: "0", ndays: "1", secid: `90.${e}` }), u = `${n}?${s.toString()}`, c = (await t.get(u, { responseType: "json" }))?.data?.trends;
    return !Array.isArray(c) || c.length === 0 ? [] : c.map((p) => {
      let [d, g, h, S, f, R, E, P] = p.split(","), b = m(P);
      return { time: d, open: m(g), close: m(h), high: m(S), low: m(f), volume: m(R), amount: m(E), price: b, avgPrice: b };
    });
  } else {
    let s = new URLSearchParams({ secid: `90.${e}`, fields1: "f1,f2,f3,f4,f5,f6", fields2: "f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61", klt: i, fqt: "1", beg: "0", end: "20500101", smplmt: "10000", lmt: "1000000" }), u = `${r}?${s.toString()}`, c = (await t.get(u, { responseType: "json" }))?.data?.klines;
    return !Array.isArray(c) || c.length === 0 ? [] : c.map((p) => {
      let [d, g, h, S, f, R, E, P, b, M, q] = p.split(",");
      return { time: d, open: m(g), close: m(h), high: m(S), low: m(f), changePercent: m(b), change: m(M), volume: m(R), amount: m(E), amplitude: m(P), turnoverRate: m(q) };
    });
  }
}
function et(t) {
  let e = sn(t);
  async function r(o) {
    return an(o, t);
  }
  async function n(o, i) {
    return e.getCode(o, i, r);
  }
  return { async getList(o) {
    return r(o);
  }, async getSpot(o, i) {
    let s = await n(o, i);
    return un(o, s, t.spotUrl);
  }, async getConstituents(o, i) {
    let s = await n(o, i);
    return ln(o, s, t.consUrl);
  }, async getKline(o, i, s = {}) {
    let u = await n(o, i);
    return cn(o, u, t.klineUrl, s);
  }, async getMinuteKline(o, i, s = {}) {
    let u = await n(o, i);
    return pn(o, u, t.klineUrl, t.trendsUrl, s);
  } };
}
var Zo = { type: "industry", fsFilter: "m:90 t:2 f:!50", listUrl: kt, spotUrl: Lt, consUrl: Nt, klineUrl: xt, trendsUrl: Ft, errorPrefix: "\u672A\u627E\u5230\u884C\u4E1A\u677F\u5757" };
var Ee = et(Zo);
async function dn(t) {
  return Ee.getList(t);
}
async function mn(t, e) {
  return Ee.getSpot(t, e);
}
async function gn(t, e) {
  return Ee.getConstituents(t, e);
}
async function fn(t, e, r = {}) {
  return Ee.getKline(t, e, r);
}
async function hn(t, e, r = {}) {
  return Ee.getMinuteKline(t, e, r);
}
var Jo = { type: "concept", fsFilter: "m:90 t:3 f:!50", listUrl: vt, spotUrl: wt, consUrl: Ut, klineUrl: Bt, trendsUrl: Kt, errorPrefix: "\u672A\u627E\u5230\u6982\u5FF5\u677F\u5757" };
var Ce = et(Jo);
async function Tn(t) {
  return Ce.getList(t);
}
async function yn(t, e) {
  return Ce.getSpot(t, e);
}
async function Sn(t, e) {
  return Ce.getConstituents(t, e);
}
async function Rn(t, e, r = {}) {
  return Ce.getKline(t, e, r);
}
async function En(t, e, r = {}) {
  return Ce.getMinuteKline(t, e, r);
}
async function Tr(t, e, r) {
  let { reportName: n, columns: o = "ALL", filter: i, sortColumns: s, sortTypes: u, pageSize: l = 500, startPage: c = 1, fetchAllPages: p = true, maxPages: d = 1e3, quoteColumns: g, quoteType: h, extraParams: S } = e, f = [], R = c, E = 1, P = 0, b = 0;
  do {
    let M = new URLSearchParams({ reportName: n, columns: o, pageSize: String(l), pageNumber: String(R), source: "WEB", client: "WEB" });
    if (i && M.set("filter", i), s && M.set("sortColumns", s), u && M.set("sortTypes", u), g && M.set("quoteColumns", g), h && M.set("quoteType", h), S) for (let [St, Rt] of Object.entries(S)) M.set(St, Rt);
    let q = `${Ht}?${M.toString()}`, j = (await t.get(q, { responseType: "json" }))?.result;
    if (!j || !Array.isArray(j.data)) break;
    R === c && (E = j.pages ?? 1, P = j.count ?? j.data.length);
    let we = j.data.map((St, Rt) => r(St, f.length + Rt));
    if (f.push(...we), R++, b++, !p) break;
  } while (R <= E && b < d);
  return p && b >= d && R <= E && console.warn(`[stock-sdk] fetchDatacenter("${n}") truncated at maxPages=${d} (server reports ${E} pages). Pass a larger \`maxPages\` to fetch the full dataset.`), { data: f, total: P, pages: E };
}
async function A(t, e, r) {
  return (await Tr(t, e, r)).data;
}
function k(t) {
  if (t == null) return "";
  let e = String(t), r = e.match(/^(\d{4}-\d{2}-\d{2})/);
  return r ? r[1] : e;
}
function Z(t) {
  if (!t) return null;
  let e = t.match(/^(\d{4}-\d{2}-\d{2})/);
  return e ? e[1] : null;
}
function ei(t) {
  return { code: t.SECURITY_CODE ?? "", name: t.SECURITY_NAME_ABBR ?? "", reportDate: Z(t.REPORT_DATE), planNoticeDate: Z(t.PLAN_NOTICE_DATE), disclosureDate: Z(t.PUBLISH_DATE ?? t.PLAN_NOTICE_DATE), assignTransferRatio: t.BONUS_IT_RATIO ?? null, bonusRatio: t.BONUS_RATIO ?? null, transferRatio: t.IT_RATIO ?? null, dividendPretax: t.PRETAX_BONUS_RMB ?? null, dividendDesc: t.IMPL_PLAN_PROFILE ?? null, dividendYield: t.DIVIDENT_RATIO ?? null, eps: t.BASIC_EPS ?? null, bps: t.BVPS ?? null, capitalReserve: t.PER_CAPITAL_RESERVE ?? null, unassignedProfit: t.PER_UNASSIGN_PROFIT ?? null, netProfitYoy: t.PNP_YOY_RATIO ?? null, totalShares: t.TOTAL_SHARES ?? null, equityRecordDate: Z(t.EQUITY_RECORD_DATE), exDividendDate: Z(t.EX_DIVIDEND_DATE), payDate: Z(t.PAY_DATE), assignProgress: t.ASSIGN_PROGRESS ?? null, noticeDate: Z(t.NOTICE_DATE) };
}
async function Cn(t, e) {
  let r = e.replace(/^(sh|sz|bj)/, "");
  return A(t, { reportName: "RPT_SHAREBONUS_DET", sortColumns: "REPORT_DATE", sortTypes: "-1", pageSize: 500, filter: `(SECURITY_CODE="${r}")` }, (n) => ei(n));
}
function yr(t) {
  let e = t.match(/^([a-zA-Z]+)/);
  if (!e) throw new RangeError(`Invalid futures symbol: "${t}". Expected format: variety + contract (e.g., rb2605, RBM, IF2604)`);
  return e[1];
}
function On(t) {
  return ee[t] ?? ee[t.toLowerCase()] ?? ee[t.toUpperCase()];
}
function Sr(t) {
  let e = On(t);
  if (!e && t.length > 1 && t.endsWith("M") && (e = On(t.slice(0, -1))), !e) {
    let n = Object.keys(ee).join(", ");
    throw new RangeError(`Unknown futures variety: "${t}". Supported varieties: ${n}`);
  }
  let r = Qt[e];
  if (r === void 0) throw new RangeError(`No market code found for exchange: ${e}`);
  return r;
}
function ti(t) {
  let e = K(t), r = t.split(",");
  return { ...e, openInterest: r.length > 12 ? m(r[12]) : null };
}
async function An(t, e, r = {}) {
  let { period: n = "daily", startDate: o = "19700101", endDate: i = "20500101" } = r;
  U(n);
  let s = yr(e), l = `${Sr(s)}.${e}`, c = new URLSearchParams({ fields1: "f1,f2,f3,f4,f5,f6", fields2: "f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61,f62,f63,f64", ut: L, klt: B(n), fqt: "0", secid: l, beg: o, end: i }), { klines: p, name: d, code: g } = await H(t, ce, c);
  return p.length === 0 ? [] : p.map((h) => ({ ...ti(h), code: g || e, name: d || "" }));
}
async function _n(t, e = {}) {
  let r = e.pageSize ?? 20, n = [], o = 0, i = 0;
  do {
    let s = new URLSearchParams({ orderBy: "dm", sort: "desc", pageSize: String(r), pageIndex: String(o), token: pe, field: "dm,sc,name,p,zsjd,zde,zdf,f152,o,h,l,zjsj,vol,wp,np,ccl", blockName: "callback" }), u = `${zt}?${s.toString()}`, l = await t.get(u, { responseType: "json" });
    if (!l || !Array.isArray(l.list)) break;
    o === 0 && (i = l.total ?? 0);
    let c = l.list.map(ri);
    n.push(...c), o++;
  } while (n.length < i);
  return n;
}
function ri(t) {
  return { code: t.dm || "", name: t.name || "", price: m(String(t.p)), change: m(String(t.zde)), changePercent: m(String(t.zdf)), open: m(String(t.o)), high: m(String(t.h)), low: m(String(t.l)), prevSettle: m(String(t.zjsj)), volume: m(String(t.vol)), buyVolume: m(String(t.wp)), sellVolume: m(String(t.np)), openInterest: m(String(t.ccl)) };
}
function ni(t) {
  let e = K(t), r = t.split(",");
  return { ...e, openInterest: r.length > 12 ? m(r[12]) : null };
}
function oi(t) {
  let e = t.match(/^([A-Z]+)/);
  if (!e) throw new RangeError(`Invalid global futures symbol: "${t}". Expected format like HG00Y, CL2507`);
  return e[1];
}
async function In(t, e, r = {}) {
  let { period: n = "daily", startDate: o = "19700101", endDate: i = "20500101" } = r;
  U(n);
  let s = r.marketCode;
  if (s === void 0) {
    let g = oi(e);
    if (s = He[g], s === void 0) {
      let h = Object.keys(He).join(", ");
      throw new RangeError(`Unknown global futures variety: "${g}". Supported: ${h}. Or specify marketCode manually via options.`);
    }
  }
  let u = `${s}.${e}`, l = new URLSearchParams({ fields1: "f1,f2,f3,f4,f5,f6", fields2: "f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61,f62,f63,f64", ut: L, klt: B(n), fqt: "0", secid: u, beg: o, end: i }), { klines: c, name: p, code: d } = await H(t, ce, l);
  return c.length === 0 ? [] : c.map((g) => ({ ...ni(g), code: d || e, name: p || "" }));
}
async function Pn(t, e = {}) {
  let { pageSize: r = 2e4 } = e, n = new URLSearchParams({ orderBy: "zdf", sort: "desc", pageSize: String(r), pageIndex: "0", token: pe, field: "dm,sc,name,p,zsjd,zde,zdf,f152,vol,cje,ccl,xqj,syr,rz,zjsj,o" }), o = `${Wt}?${n.toString()}`, s = (await t.get(o, { responseType: "json" }))?.list;
  return Array.isArray(s) ? s.map((u) => ({ code: String(u.dm ?? ""), name: String(u.name ?? ""), price: a(u.p), change: a(u.zde), changePercent: a(u.zdf), volume: a(u.vol), amount: a(u.cje), openInterest: a(u.ccl), strikePrice: a(u.xqj), remainDays: a(u.syr), dailyChange: a(u.rz), prevSettle: a(u.zjsj), open: a(u.o) })) : [];
}
function ii(t) {
  return t.includes("\u51C0") ? "net" : t.includes("\u4E70") ? "buy" : t.includes("\u5356") ? "sell" : null;
}
async function Dn(t, e, r) {
  let n = new URLSearchParams({ type: "RPT_IF_BILLBOARD_TD", sty: "ALL", p: "1", ps: "200", source: "IFBILLBOARD", client: "WEB", ut: v, filter: `(SECURITY_CODE="${e}")(TRADE_DATE='${r}')` }), o = `${Xt}?${n.toString()}`, s = (await t.get(o, { responseType: "json" }))?.result?.data;
  if (!Array.isArray(s)) return [];
  function u(l) {
    if (!l) return "";
    let c = String(l), p = c.match(/^(\d{4}-\d{2}-\d{2})/);
    return p ? p[1] : c;
  }
  return s.map((l) => ({ tradeType: String(l.TRADE_TYPE ?? ""), date: u(l.TRADE_DATE), symbol: String(l.SECURITY_CODE ?? ""), targetName: String(l.TARGET_NAME ?? ""), memberName: String(l.MEMBER_NAME_ABBR ?? ""), rank: a(l.MEMBER_RANK) ?? 0, sellVolume: a(l.SELL_VOLUME), sellVolumeChange: a(l.SELL_VOLUME_CHANGE), netSellVolume: a(l.NET_SELL_VOLUME), sellVolumeRatio: a(l.SELL_VOLUME_RATIO), buyVolume: a(l.BUY_VOLUME), buyVolumeChange: a(l.BUY_VOLUME_CHANGE), netBuyVolume: a(l.NET_BUY_VOLUME), buyVolumeRatio: a(l.BUY_VOLUME_RATIO), sellPosition: a(l.SELL_POSITION), sellPositionChange: a(l.SELL_POSITION_CHANGE), netSellPosition: a(l.NET_SELL_POSITION), sellPositionRatio: a(l.SELL_POSITION_RATIO), buyPosition: a(l.BUY_POSITION), buyPositionChange: a(l.BUY_POSITION_CHANGE), netBuyPosition: a(l.NET_BUY_POSITION), buyPositionRatio: a(l.BUY_POSITION_RATIO), tradeDate: u(l.TRADE_DATE), volume: a(l.BUY_VOLUME) ?? a(l.SELL_VOLUME) ?? a(l.NET_BUY_VOLUME) ?? a(l.NET_SELL_VOLUME), volumeChange: a(l.BUY_VOLUME_CHANGE) ?? a(l.SELL_VOLUME_CHANGE), amount: a(l.BUY_POSITION) ?? a(l.SELL_POSITION) ?? a(l.NET_BUY_POSITION) ?? a(l.NET_SELL_POSITION), amountChange: a(l.BUY_POSITION_CHANGE) ?? a(l.SELL_POSITION_CHANGE), openInterest: a(l.BUY_POSITION) ?? a(l.SELL_POSITION), openInterestChange: a(l.BUY_POSITION_CHANGE) ?? a(l.SELL_POSITION_CHANGE), side: ii(String(l.TRADE_TYPE ?? "")) }));
}
var si = { gold: "EMI00069026", silver: "EMI00069027" };
function bn(t) {
  if (!t) return "";
  let e = String(t), r = e.match(/^(\d{4}-\d{2}-\d{2})/);
  return r ? r[1] : e;
}
async function Mn(t) {
  return A(t, { reportName: "RPT_FUTU_POSITIONCODE", columns: "TRADE_MARKET_CODE,TRADE_CODE,TRADE_TYPE", filter: '(IS_MAINCODE="1")', pageSize: 500, fetchAllPages: false }, (e) => ({ code: String(e.TRADE_CODE ?? ""), name: String(e.TRADE_TYPE ?? ""), marketCode: String(e.TRADE_MARKET_CODE ?? "") }));
}
async function kn(t, e, r = {}) {
  let { startDate: n = "2020-10-28", pageSize: o = 500 } = r, i = e.toUpperCase();
  return A(t, { reportName: "RPT_FUTU_STOCKDATA", columns: "SECURITY_CODE,TRADE_DATE,ON_WARRANT_NUM,ADDCHANGE", filter: `(SECURITY_CODE="${i}")(TRADE_DATE>='${n}')`, pageSize: o, sortColumns: "TRADE_DATE", sortTypes: "-1" }, (s) => ({ code: String(s.SECURITY_CODE ?? e), date: bn(s.TRADE_DATE), inventory: a(s.ON_WARRANT_NUM), change: a(s.ADDCHANGE) }));
}
async function Ln(t, e, r = {}) {
  let n = si[e];
  if (!n) throw new RangeError(`Invalid COMEX symbol: "${e}". Must be "gold" or "silver".`);
  let { pageSize: o = 500 } = r, i = { gold: "\u9EC4\u91D1", silver: "\u767D\u94F6" };
  return A(t, { reportName: "RPT_FUTUOPT_GOLDSIL", sortColumns: "REPORT_DATE", sortTypes: "-1", pageSize: o, filter: `(INDICATOR_ID1="${n}")(@STORAGE_TON<>"NULL")` }, (s) => ({ date: bn(s.REPORT_DATE), name: i[e] ?? e, storageTon: a(s.STORAGE_TON), storageOunce: a(s.STORAGE_OUNCE), inventory: a(s.STORAGE_TON), change: null, market: e }));
}
var Nn = { daily: "101", weekly: "102", monthly: "103" };
var Rr = "f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61,f62,f63,f64,f65";
function xn(t) {
  let e = t.split(",");
  return { date: e[0] ?? "", mainNetInflow: m(e[1]), smallNetInflow: m(e[2]), mediumNetInflow: m(e[3]), largeNetInflow: m(e[4]), superLargeNetInflow: m(e[5]), mainNetInflowPercent: m(e[6]), smallNetInflowPercent: m(e[7]), mediumNetInflowPercent: m(e[8]), largeNetInflowPercent: m(e[9]), superLargeNetInflowPercent: m(e[10]), close: m(e[11]), changePercent: m(e[12]) };
}
function ai(t) {
  let e = t.split(",");
  return { date: e[0] ?? "", mainNetInflow: m(e[1]), smallNetInflow: m(e[2]), mediumNetInflow: m(e[3]), largeNetInflow: m(e[4]), superLargeNetInflow: m(e[5]), mainNetInflowPercent: m(e[6]), smallNetInflowPercent: m(e[7]), mediumNetInflowPercent: m(e[8]), largeNetInflowPercent: m(e[9]), superLargeNetInflowPercent: m(e[10]), shClose: m(e[11]), shChangePercent: m(e[12]), szClose: m(e[13]), szChangePercent: m(e[14]) };
}
var Fn = { today: { fid: "f62", fields: "f12,f14,f2,f3,f62,f184,f66,f69,f72,f75,f78,f81,f84,f87,f124", changePercentField: "f3", mainNet: "f62", mainPct: "f184", superLargeNet: "f66", superLargePct: "f69", largeNet: "f72", largePct: "f75", mediumNet: "f78", mediumPct: "f81", smallNet: "f84", smallPct: "f87" }, "3day": { fid: "f267", fields: "f12,f14,f2,f127,f267,f268,f269,f270,f271,f272,f273,f274,f275,f276,f124", changePercentField: "f127", mainNet: "f267", mainPct: "f268", superLargeNet: "f269", superLargePct: "f270", largeNet: "f271", largePct: "f272", mediumNet: "f273", mediumPct: "f274", smallNet: "f275", smallPct: "f276" }, "5day": { fid: "f164", fields: "f12,f14,f2,f109,f164,f165,f166,f167,f168,f169,f170,f171,f172,f173,f124", changePercentField: "f109", mainNet: "f164", mainPct: "f165", superLargeNet: "f166", superLargePct: "f167", largeNet: "f168", largePct: "f169", mediumNet: "f170", mediumPct: "f171", smallNet: "f172", smallPct: "f173" }, "10day": { fid: "f174", fields: "f12,f14,f2,f160,f174,f175,f176,f177,f178,f179,f180,f181,f182,f183,f124", changePercentField: "f160", mainNet: "f174", mainPct: "f175", superLargeNet: "f176", superLargePct: "f177", largeNet: "f178", largePct: "f179", mediumNet: "f180", mediumPct: "f181", smallNet: "f182", smallPct: "f183" } };
var ui = { industry: "m:90+t:2", concept: "m:90+t:3", region: "m:90+t:1" };
var li = "m:0+t:6+f:!2,m:0+t:13+f:!2,m:0+t:80+f:!2,m:1+t:2+f:!2,m:1+t:23+f:!2,m:0+t:7+f:!2,m:1+t:3+f:!2";
async function vn(t, e, r = 100, n = 1e3) {
  let o = [], i = 1, s = 0;
  do {
    let u = new URLSearchParams({ ...e, pn: String(i), pz: String(r) }), l = `${qt}?${u.toString()}`, p = (await t.get(l, { responseType: "json" }))?.data;
    if (!p || !Array.isArray(p.diff) || (i === 1 && (s = p.total ?? 0), o.push(...p.diff), o.length >= s || p.diff.length < r)) break;
    i++;
  } while (o.length < s && i <= n);
  return i > n && o.length < s && console.warn(`[stock-sdk] fetchClistAllPages truncated at maxPages=${n} (server reports total=${s}, fetched=${o.length}). Pass a larger \`maxPages\` to fetch the full dataset.`), o;
}
async function wn(t, e, r = {}) {
  let { period: n = "daily" } = r, o = Nn[n];
  if (!o) throw new RangeError(`Invalid period: ${n}. Must be daily/weekly/monthly.`);
  let i = e.replace(/^(sh|sz|bj)/i, ""), s = `${oe(e)}.${i}`, u = new URLSearchParams({ lmt: "0", klt: o, secid: s, fields1: "f1,f2,f3,f7", fields2: Rr, ut: v }), l = `${ue}?${u.toString()}`, p = (await t.get(l, { responseType: "json" }))?.data?.klines;
  return !Array.isArray(p) || p.length === 0 ? [] : p.map(xn);
}
async function Un(t) {
  let e = new URLSearchParams({ lmt: "0", klt: "101", secid: "1.000001", secid2: "0.399001", fields1: "f1,f2,f3,f7", fields2: Rr, ut: v }), r = `${ue}?${e.toString()}`, o = (await t.get(r, { responseType: "json" }))?.data?.klines;
  return !Array.isArray(o) || o.length === 0 ? [] : o.map(ai);
}
async function Bn(t, e = {}) {
  let { indicator: r = "today" } = e, n = Fn[r];
  if (!n) throw new RangeError(`Invalid indicator: ${r}.`);
  let o = { fid: n.fid, po: "1", np: "1", fltt: "2", invt: "2", ut: v, fs: li, fields: n.fields };
  return (await vn(t, o, 100)).map((s) => ({ code: String(s.f12 ?? ""), name: String(s.f14 ?? ""), price: a(s.f2), changePercent: a(s[n.changePercentField]), mainNetInflow: a(s[n.mainNet]), mainNetInflowPercent: a(s[n.mainPct]), superLargeNetInflow: a(s[n.superLargeNet]), superLargeNetInflowPercent: a(s[n.superLargePct]), largeNetInflow: a(s[n.largeNet]), largeNetInflowPercent: a(s[n.largePct]), mediumNetInflow: a(s[n.mediumNet]), mediumNetInflowPercent: a(s[n.mediumPct]), smallNetInflow: a(s[n.smallNet]), smallNetInflowPercent: a(s[n.smallPct]) }));
}
async function Kn(t, e = {}) {
  let { indicator: r = "today", sectorType: n = "industry" } = e, o = Fn[r];
  if (!o) throw new RangeError(`Invalid indicator: ${r}.`);
  let i = ui[n];
  if (!i) throw new RangeError(`Invalid sectorType: ${n}.`);
  let s = `${o.fields},f204,f205`, u = { fid: o.fid, po: "1", np: "1", fltt: "2", invt: "2", ut: v, fs: i, fields: s };
  return (await vn(t, u, 100)).map((c) => ({ code: String(c.f12 ?? ""), name: String(c.f14 ?? ""), changePercent: a(c[o.changePercentField]), mainNetInflow: a(c[o.mainNet]), mainNetInflowPercent: a(c[o.mainPct]), superLargeNetInflow: a(c[o.superLargeNet]), largeNetInflow: a(c[o.largeNet]), mediumNetInflow: a(c[o.mediumNet]), smallNetInflow: a(c[o.smallNet]), topStockCode: c.f204 ? String(c.f204) : void 0, topStockName: c.f205 ? String(c.f205) : void 0 }));
}
async function Hn(t, e, r = {}) {
  let { period: n = "daily" } = r, o = Nn[n];
  if (!o) throw new RangeError(`Invalid period: ${n}. Must be daily/weekly/monthly.`);
  let i = e.includes(".") ? e : `90.${e}`, s = new URLSearchParams({ lmt: "0", klt: o, secid: i, fields1: "f1,f2,f3,f7", fields2: Rr, ut: v }), u = `${ue}?${s.toString()}`, c = (await t.get(u, { responseType: "json" }))?.data?.klines;
  return !Array.isArray(c) || c.length === 0 ? [] : c.map(xn);
}
var ci = { today: "1", "3day": "3", "5day": "5", "10day": "10", month: "M", quarter: "Q", year: "Y" };
var pi = { shanghai: "001", shenzhen: "003" };
function qn(t, e) {
  let r = t.split(",");
  return { date: e, time: r[0] ?? "", shanghaiNetInflow: m(r[1]), shenzhenNetInflow: m(r[3]), totalNetInflow: m(r[5]) };
}
async function zn(t, e = "north") {
  let r = new URLSearchParams({ fields1: "f1,f2,f3,f4", fields2: "f51,f54,f52,f58,f53,f62,f56,f57,f60,f61", ut: v }), n = `${$t}?${r.toString()}`, i = (await t.get(n, { responseType: "json" }))?.data;
  if (!i) return [];
  if (e === "south") {
    let l = i.n2s ?? [], c = i.n2sDate ?? "";
    return l.map((p) => qn(p, $n(c)));
  }
  let s = i.s2n ?? [], u = i.s2nDate ?? "";
  return s.map((l) => qn(l, $n(u)));
}
function $n(t) {
  return t ? /^\d{8}$/.test(t) ? `${t.slice(0, 4)}-${t.slice(4, 6)}-${t.slice(6, 8)}` : t : "";
}
async function Qn(t) {
  return A(t, { reportName: "RPT_MUTUAL_QUOTA", columns: "TRADE_DATE,MUTUAL_TYPE,BOARD_TYPE,MUTUAL_TYPE_NAME,FUNDS_DIRECTION,INDEX_CODE,INDEX_NAME,BOARD_CODE", quoteColumns: "status~07~BOARD_CODE,dayNetAmtIn~07~BOARD_CODE,dayAmtRemain~07~BOARD_CODE,dayAmtThreshold~07~BOARD_CODE,f104~07~BOARD_CODE,f105~07~BOARD_CODE,f106~07~BOARD_CODE,f3~03~INDEX_CODE~INDEX_f3,netBuyAmt~07~BOARD_CODE", quoteType: "0", sortColumns: "MUTUAL_TYPE", sortTypes: "1", pageSize: 2e3, fetchAllPages: false }, (e) => ({ date: k(e.TRADE_DATE), type: String(e.MUTUAL_TYPE ?? ""), boardName: String(e.MUTUAL_TYPE_NAME ?? ""), direction: String(e.FUNDS_DIRECTION ?? ""), status: String(e.status ?? ""), netBuyAmount: a(e.netBuyAmt), netInflow: a(e.dayNetAmtIn), remainAmount: a(e.dayAmtRemain), upCount: a(e.f104), flatCount: a(e.f106), downCount: a(e.f105), indexCode: String(e.INDEX_CODE ?? ""), indexName: String(e.INDEX_NAME ?? ""), indexChangePercent: a(e.INDEX_f3) }));
}
async function jn(t, e = {}) {
  let { market: r = "all", period: n = "5day", date: o } = e, i = ci[n];
  if (!i) throw new RangeError(`Invalid period: ${n}.`);
  let s = [`(INTERVAL_TYPE="${i}")`];
  return o && s.push(`(TRADE_DATE='${o}')`), r !== "all" && s.push(`(MUTUAL_TYPE="${pi[r]}")`), A(t, { reportName: "RPT_MUTUAL_STOCK_NORTHSTA", columns: "ALL", sortColumns: "ADD_MARKET_CAP", sortTypes: "-1", pageSize: 500, filter: s.join("") }, (u) => ({ date: k(u.TRADE_DATE), code: String(u.SECURITY_CODE ?? ""), name: String(u.SECURITY_NAME ?? u.SECURITY_NAME_ABBR ?? ""), close: a(u.CLOSE_PRICE), changePercent: a(u.CHANGE_RATE), holdShares: a(u.HOLD_SHARES), holdMarketValue: a(u.HOLD_MARKET_CAP), holdRatioFloat: a(u.HOLD_RATIO), holdRatioTotal: a(u.A_SHARES_RATIO), addShares: a(u.ADD_SHARES), addMarketValue: a(u.ADD_MARKET_CAP), addMarketValuePercent: a(u.ADD_MARKET_CAP_PROPORTION), sector: String(u.BOARD_NAME ?? "") }));
}
async function Gn(t, e = "north", r = {}) {
  let { startDate: n, endDate: o } = r, i = [e === "north" ? '(BOARD_TYPE="1")' : '(BOARD_TYPE="0")'];
  return n && i.push(`(TRADE_DATE>='${n}')`), o && i.push(`(TRADE_DATE<='${o}')`), A(t, { reportName: "RPT_MUTUAL_DEAL_HISTORY", columns: "ALL", sortColumns: "TRADE_DATE", sortTypes: "-1", pageSize: 500, filter: i.join("") }, (s) => ({ date: k(s.TRADE_DATE), netBuyAmount: a(s.NET_DEAL_AMT), buyAmount: a(s.BUY_AMT), sellAmount: a(s.SELL_AMT), accNetBuyAmount: a(s.ACCUM_DEAL_AMT), netInflow: a(s.FUND_INFLOW), remainAmount: a(s.QUOTA_BALANCE), topStockCode: s.LEAD_STOCKS_CODE ? String(s.LEAD_STOCKS_CODE) : null, topStockName: s.LEAD_STOCKS_NAME ? String(s.LEAD_STOCKS_NAME) : null, topStockChangePercent: a(s.LS_CHANGE_RATE) }));
}
async function Yn(t, e, r = {}) {
  let n = e.replace(/^(sh|sz|bj)/i, ""), { startDate: o, endDate: i } = r, s = [`(SECURITY_CODE="${n}")`];
  return o && s.push(`(TRADE_DATE>='${o}')`), i && s.push(`(TRADE_DATE<='${i}')`), A(t, { reportName: "RPT_MUTUAL_HOLDSTOCKNORTH_STA", columns: "ALL", sortColumns: "TRADE_DATE", sortTypes: "-1", pageSize: 500, filter: s.join("") }, (u) => ({ date: k(u.TRADE_DATE), holdShares: a(u.HOLD_SHARES), holdMarketValue: a(u.HOLD_MARKET_CAP), holdRatioFloat: a(u.HOLD_RATIO), holdRatioTotal: a(u.A_SHARES_RATIO), close: a(u.CLOSE_PRICE), changePercent: a(u.CHANGE_RATE) }));
}
var di = { zt: { path: "/getTopicZTPool", sort: "fbt:asc" }, yesterday: { path: "/getYesterdayZTPool", sort: "zs:desc" }, strong: { path: "/getTopicQSPool", sort: "zdp:desc" }, sub_new: { path: "/getTopicCXPool", sort: "ods:asc" }, broken: { path: "/getTopicZBPool", sort: "fbt:asc" }, dt: { path: "/getTopicDTPool", sort: "fund:asc" } };
var mi = { rocket_launch: "8201", quick_rebound: "8202", large_buy: "8193", limit_up_seal: "4", limit_down_open: "32", big_buy_order: "64", auction_up: "8207", high_open_5d: "8209", gap_up: "8211", high_60d: "8213", surge_60d: "8215", accelerate_down: "8204", high_dive: "8203", large_sell: "8194", limit_down_seal: "8", limit_up_open: "16", big_sell_order: "128", auction_down: "8208", low_open_5d: "8210", gap_down: "8212", low_60d: "8214", drop_60d: "8216" };
var gi = { 8201: "\u706B\u7BAD\u53D1\u5C04", 8202: "\u5FEB\u901F\u53CD\u5F39", 8193: "\u5927\u7B14\u4E70\u5165", 4: "\u5C01\u6DA8\u505C\u677F", 32: "\u6253\u5F00\u8DCC\u505C\u677F", 64: "\u6709\u5927\u4E70\u76D8", 8207: "\u7ADE\u4EF7\u4E0A\u6DA8", 8209: "\u9AD8\u5F005\u65E5\u7EBF", 8211: "\u5411\u4E0A\u7F3A\u53E3", 8213: "60\u65E5\u65B0\u9AD8", 8215: "60\u65E5\u5927\u5E45\u4E0A\u6DA8", 8204: "\u52A0\u901F\u4E0B\u8DCC", 8203: "\u9AD8\u53F0\u8DF3\u6C34", 8194: "\u5927\u7B14\u5356\u51FA", 8: "\u5C01\u8DCC\u505C\u677F", 16: "\u6253\u5F00\u6DA8\u505C\u677F", 128: "\u6709\u5927\u5356\u76D8", 8208: "\u7ADE\u4EF7\u4E0B\u8DCC", 8210: "\u4F4E\u5F005\u65E5\u7EBF", 8212: "\u5411\u4E0B\u7F3A\u53E3", 8214: "60\u65E5\u65B0\u4F4E", 8216: "60\u65E5\u5927\u5E45\u4E0B\u8DCC" };
function Er(t) {
  if (t == null) return "";
  let e = String(t).padStart(6, "0");
  return `${e.slice(0, 2)}:${e.slice(2, 4)}:${e.slice(4, 6)}`;
}
function fi(t) {
  if (!t || typeof t != "object") return "";
  let e = t;
  return `${e.days ?? ""}/${e.ct ?? ""}`;
}
function hi(t) {
  let e = a(t.p), r = a(t.tp);
  return { code: String(t.c ?? t.m ?? ""), name: String(t.n ?? ""), price: e !== null ? e / 1e3 : null, changePercent: a(t.zdp), limitPrice: r !== null ? r / 1e3 : null, amount: a(t.amount ?? t.zb), floatMarketValue: a(t.ltsz), totalMarketValue: a(t.tshare), turnoverRate: a(t.hs), continuousBoardCount: a(t.lbc), firstBoardTime: t.fbt !== void 0 && t.fbt !== null ? Er(t.fbt) : null, lastBoardTime: t.lbt !== void 0 && t.lbt !== null ? Er(t.lbt) : null, boardAmount: a(t.fund), sealAmount: a(t.fund), failedCount: a(t.zbc), industry: String(t.hybk ?? ""), ztStatistics: fi(t.zttj), amplitude: a(t.zf), speed: a(t.zs) };
}
function Ti(t) {
  if (t) return /^\d{8}$/.test(t) ? t : t.replace(/-/g, "");
}
function yi() {
  let t = new Date(Date.now() + 288e5), e = t.getUTCFullYear(), r = String(t.getUTCMonth() + 1).padStart(2, "0"), n = String(t.getUTCDate()).padStart(2, "0");
  return `${e}${r}${n}`;
}
async function Vn(t, e = "zt", r) {
  let n = di[e];
  if (!n) throw new RangeError(`Invalid ZTPool type: ${e}.`);
  let o = Ti(r) ?? yi(), i = new URLSearchParams({ ut: L, dpt: "wz.ztzt", Pageindex: "0", pagesize: "10000", sort: n.sort, date: o }), s = `${le}${n.path}?${i.toString()}`, l = (await t.get(s, { responseType: "json" }))?.data?.pool;
  return !Array.isArray(l) || l.length === 0 ? [] : l.map(hi);
}
async function Wn(t, e = "large_buy") {
  let r = mi[e];
  if (!r) throw new RangeError(`Invalid StockChangeType: ${e}.`);
  let n = new URLSearchParams({ type: r, pageindex: "0", pagesize: "5000", ut: L, dpt: "wzchanges" }), o = `${le}/getAllStockChanges?${n.toString()}`, s = (await t.get(o, { responseType: "json" }))?.data?.allstock;
  return !Array.isArray(s) || s.length === 0 ? [] : s.map((u) => {
    let l = String(u.t ?? r);
    return { time: Er(u.tm), code: String(u.c ?? ""), name: String(u.n ?? ""), changeType: e, changeTypeLabel: gi[l] ?? "", info: String(u.i ?? "") };
  });
}
async function Xn(t) {
  let e = new URLSearchParams({ ut: L, dpt: "wzchanges", pageindex: "0", pagesize: "5000" }), r = `${le}/getAllBKChanges?${e.toString()}`, o = (await t.get(r, { responseType: "json" }))?.data?.allbk;
  return !Array.isArray(o) || o.length === 0 ? [] : o.map((i) => {
    let s = i.ms ?? {}, u = s.m === 0 ? "\u5927\u7B14\u4E70\u5165" : s.m === 1 ? "\u5927\u7B14\u5356\u51FA" : "", l = {}, c = i.bkdf ?? i.bkdfdis;
    if (c && typeof c == "object") for (let [p, d] of Object.entries(c)) l[p] = Number(d) || 0;
    return { name: String(i.bkn ?? ""), changePercent: a(i.bkz), mainNetInflow: a(i.bkj), totalChangeCount: a(i.bkc), topStockCode: String(s.c ?? ""), topStockName: String(s.n ?? ""), topStockDirection: u, changeTypeDistribution: l };
  });
}
var Zn = { "1month": "01", "3month": "02", "6month": "03", "1year": "04" };
function Oe(t) {
  return /^\d{8}$/.test(t) ? `${t.slice(0, 4)}-${t.slice(4, 6)}-${t.slice(6, 8)}` : t;
}
async function Jn(t, e) {
  let r = Oe(e.startDate), n = Oe(e.endDate);
  return A(t, { reportName: "RPT_DAILYBILLBOARD_DETAILSNEW", columns: "SECURITY_CODE,SECUCODE,SECURITY_NAME_ABBR,TRADE_DATE,EXPLAIN,CLOSE_PRICE,CHANGE_RATE,BILLBOARD_NET_AMT,BILLBOARD_BUY_AMT,BILLBOARD_SELL_AMT,BILLBOARD_DEAL_AMT,ACCUM_AMOUNT,DEAL_NET_RATIO,DEAL_AMOUNT_RATIO,TURNOVERRATE,FREE_MARKET_CAP,EXPLANATION,D1_CLOSE_ADJCHRATE,D2_CLOSE_ADJCHRATE,D5_CLOSE_ADJCHRATE,D10_CLOSE_ADJCHRATE", sortColumns: "SECURITY_CODE,TRADE_DATE", sortTypes: "1,-1", pageSize: 5e3, filter: `(TRADE_DATE<='${n}')(TRADE_DATE>='${r}')` }, (o) => ({ code: String(o.SECURITY_CODE ?? ""), name: String(o.SECURITY_NAME_ABBR ?? ""), date: k(o.TRADE_DATE), close: a(o.CLOSE_PRICE), changePercent: a(o.CHANGE_RATE), netBuyAmount: a(o.BILLBOARD_NET_AMT), buyAmount: a(o.BILLBOARD_BUY_AMT), sellAmount: a(o.BILLBOARD_SELL_AMT), dealAmount: a(o.BILLBOARD_DEAL_AMT), totalAmount: a(o.ACCUM_AMOUNT), netBuyRatio: a(o.DEAL_NET_RATIO), dealAmountRatio: a(o.DEAL_AMOUNT_RATIO), turnoverRate: a(o.TURNOVERRATE), floatMarketValue: a(o.FREE_MARKET_CAP), reason: String(o.EXPLANATION ?? o.EXPLAIN ?? ""), afterChange1d: a(o.D1_CLOSE_ADJCHRATE), afterChange2d: a(o.D2_CLOSE_ADJCHRATE), afterChange5d: a(o.D5_CLOSE_ADJCHRATE), afterChange10d: a(o.D10_CLOSE_ADJCHRATE) }));
}
async function eo(t, e = "1month") {
  let r = Zn[e];
  if (!r) throw new RangeError(`Invalid period: ${e}.`);
  return A(t, { reportName: "RPT_BILLBOARD_TRADEALL", columns: "ALL", sortColumns: "BILLBOARD_TIMES,LATEST_TDATE,SECURITY_CODE", sortTypes: "-1,-1,1", pageSize: 5e3, filter: `(STATISTICS_CYCLE="${r}")` }, (n) => ({ code: String(n.SECURITY_CODE ?? ""), name: String(n.SECURITY_NAME_ABBR ?? ""), latestDate: k(n.LATEST_TDATE), close: a(n.CLOSE_PRICE), changePercent: a(n.CHANGE_RATE), count: a(n.BILLBOARD_TIMES), totalBuyAmount: a(n.BILLBOARD_BUY_AMT), totalSellAmount: a(n.BILLBOARD_SELL_AMT), totalNetAmount: a(n.BILLBOARD_NET_AMT), totalDealAmount: a(n.BILLBOARD_DEAL_AMT), buyOrgCount: a(n.ORG_BUY_TIMES), sellOrgCount: a(n.ORG_SELL_TIMES) }));
}
async function to(t, e) {
  let r = Oe(e.startDate), n = Oe(e.endDate);
  return A(t, { reportName: "RPT_ORGANIZATION_TRADE_DETAILS", columns: "ALL", sortColumns: "TRADE_DATE,SECURITY_CODE", sortTypes: "-1,1", pageSize: 5e3, filter: `(TRADE_DATE<='${n}')(TRADE_DATE>='${r}')` }, (o) => ({ code: String(o.SECURITY_CODE ?? ""), name: String(o.SECURITY_NAME_ABBR ?? ""), date: k(o.TRADE_DATE), close: a(o.CLOSE_PRICE), changePercent: a(o.CHANGE_RATE), buyOrgCount: a(o.BUY_TIMES), sellOrgCount: a(o.SELL_TIMES), orgBuyAmount: a(o.BUY_AMT), orgSellAmount: a(o.SELL_AMT), orgNetAmount: a(o.NET_AMT) }));
}
async function ro(t, e = "1month") {
  let r = Zn[e];
  if (!r) throw new RangeError(`Invalid period: ${e}.`);
  return A(t, { reportName: "RPT_BILLBOARD_TRADEDETAILS", columns: "ALL", sortColumns: "TOTAL_BUYER_SALESTIMES", sortTypes: "-1", pageSize: 5e3, filter: `(STATISTICS_CYCLE="${r}")` }, (n) => ({ code: String(n.OPERATEDEPT_CODE ?? ""), name: String(n.OPERATEDEPT_NAME ?? ""), totalBuyAmount: a(n.TOTAL_BUYAMT ?? n.BUY_AMT), totalSellAmount: a(n.TOTAL_SELLAMT ?? n.SELL_AMT), buyCount: a(n.TOTAL_BUYER_SALESTIMES ?? n.BUY_TIMES), sellCount: a(n.TOTAL_SELLER_SALESTIMES ?? n.SELL_TIMES), totalCount: a(n.TOTAL_TIMES) }));
}
async function no(t, e, r) {
  let n = e.replace(/^(sh|sz|bj)/i, ""), o = Oe(r), i = `(SECURITY_CODE="${n}")(TRADE_DATE='${o}')`, [s, u] = await Promise.all([A(t, { reportName: "RPT_BILLBOARD_DAILYDETAILSBUY", columns: "ALL", sortColumns: "BUY_AMT_REAL", sortTypes: "-1", pageSize: 100, filter: i }, (l, c) => ({ rank: a(l.RANK) ?? c + 1, branchName: String(l.OPERATEDEPT_NAME ?? ""), buyAmount: a(l.BUY_AMT_REAL ?? l.BUY_AMT), buyAmountRatio: a(l.BUY_RATIO_TOTAL ?? l.BUY_AMT_RATIO), sellAmount: a(l.SELL_AMT_REAL ?? l.SELL_AMT), sellAmountRatio: a(l.SELL_RATIO_TOTAL ?? l.SELL_AMT_RATIO), netAmount: a(l.NET_AMT), side: "buy" })), A(t, { reportName: "RPT_BILLBOARD_DAILYDETAILSSELL", columns: "ALL", sortColumns: "SELL_AMT_REAL", sortTypes: "-1", pageSize: 100, filter: i }, (l, c) => ({ rank: a(l.RANK) ?? c + 1, branchName: String(l.OPERATEDEPT_NAME ?? ""), buyAmount: a(l.BUY_AMT_REAL ?? l.BUY_AMT), buyAmountRatio: a(l.BUY_RATIO_TOTAL ?? l.BUY_AMT_RATIO), sellAmount: a(l.SELL_AMT_REAL ?? l.SELL_AMT), sellAmountRatio: a(l.SELL_RATIO_TOTAL ?? l.SELL_AMT_RATIO), netAmount: a(l.NET_AMT), side: "sell" }))]);
  return [...s, ...u];
}
function oo(t) {
  if (t) return /^\d{8}$/.test(t) ? `${t.slice(0, 4)}-${t.slice(4, 6)}-${t.slice(6, 8)}` : t;
}
function io(t) {
  if (!t) return "";
  let e = oo(t.startDate), r = oo(t.endDate), n = [];
  return e && n.push(`(TRADE_DATE>='${e}')`), r && n.push(`(TRADE_DATE<='${r}')`), n.join("");
}
async function so(t) {
  return A(t, { reportName: "PRT_BLOCKTRADE_MARKET_STA", columns: "ALL", sortColumns: "TRADE_DATE", sortTypes: "-1", pageSize: 500 }, (e) => ({ date: k(e.TRADE_DATE), shClose: a(e.CLOSE_PRICE ?? e.SH_CLOSE_PRICE), shChangePercent: a(e.CHANGE_RATE ?? e.SH_CHANGE_RATE), totalAmount: a(e.TURNOVER ?? e.TOTAL_AMOUNT), premiumAmount: a(e.PREMIUM_TURNOVER ?? e.PREMIUM_AMOUNT), premiumRatio: a(e.PREMIUM_RATIO), discountAmount: a(e.DISCOUNT_TURNOVER ?? e.DISCOUNT_AMOUNT), discountRatio: a(e.DISCOUNT_RATIO) }));
}
async function ao(t, e = {}) {
  let r = io(e);
  return A(t, { reportName: "RPT_BLOCK_TRADE_DETAIL", columns: "ALL", sortColumns: "TRADE_DATE,SECURITY_CODE", sortTypes: "-1,1", pageSize: 5e3, filter: r || void 0 }, (n) => ({ code: String(n.SECURITY_CODE ?? ""), name: String(n.SECURITY_NAME_ABBR ?? ""), date: k(n.TRADE_DATE), close: a(n.CLOSE_PRICE), changePercent: a(n.CHANGE_RATE), dealPrice: a(n.DEAL_PRICE ?? n.PRICE), dealVolume: a(n.DEAL_VOLUME ?? n.VOLUME), dealAmount: a(n.DEAL_AMT ?? n.TURNOVER), premiumRate: a(n.PREMIUM_RATIO ?? n.PREMIUM_RATE), buyBranch: String(n.BUYER_DEPT ?? n.BUYER_OPERATEDEPT_NAME ?? ""), sellBranch: String(n.SELLER_DEPT ?? n.SELLER_OPERATEDEPT_NAME ?? "") }));
}
async function uo(t, e = {}) {
  let r = io(e);
  return A(t, { reportName: "RPT_BLOCK_TRADE_STA", columns: "ALL", sortColumns: "TRADE_DATE,DEAL_AMT", sortTypes: "-1,-1", pageSize: 5e3, filter: r || void 0 }, (n) => ({ code: String(n.SECURITY_CODE ?? ""), name: String(n.SECURITY_NAME_ABBR ?? ""), date: k(n.TRADE_DATE), changePercent: a(n.CHANGE_RATE), close: a(n.CLOSE_PRICE), dealCount: a(n.DEAL_NUM ?? n.DEAL_COUNT), dealTotalAmount: a(n.DEAL_AMT ?? n.TOTAL_AMOUNT), dealTotalVolume: a(n.DEAL_VOLUME ?? n.TOTAL_VOLUME), premiumAmount: a(n.PREMIUM_AMT ?? n.PREMIUM_AMOUNT), discountAmount: a(n.DISCOUNT_AMT ?? n.DISCOUNT_AMOUNT) }));
}
async function lo(t) {
  return A(t, { reportName: "RPTA_WEB_MARGIN_DAILYTRADE", columns: "ALL", sortColumns: "STATISTICS_DATE", sortTypes: "-1", pageSize: 500 }, (e) => ({ date: k(e.STATISTICS_DATE ?? e.TRADE_DATE), finBalance: a(e.FIN_BALANCE), loanBalance: a(e.LOAN_BALANCE), finBuyAmount: a(e.FIN_BUY_AMT), loanSellAmount: a(e.LOAN_SELL_AMT), investorCount: a(e.OPERATE_INVESTOR_NUM ?? e.INVESTOR_NUM), liabilityInvestorCount: a(e.MARGIN_INVESTOR_NUM), totalGuarantee: a(e.TOTAL_GUARANTEE), avgGuaranteeRatio: a(e.AVG_GUARANTEE_RATIO) }));
}
async function co(t, e) {
  let r = e ? `(TRADE_DATE='${e}')` : void 0;
  return A(t, { reportName: "RPT_MARGIN_TRADE_DETAIL", columns: "ALL", sortColumns: "FIN_BALANCE", sortTypes: "-1", pageSize: 5e3, filter: r }, (n) => ({ code: String(n.SECURITY_CODE ?? ""), name: String(n.SECURITY_NAME_ABBR ?? ""), date: k(n.TRADE_DATE), finBalance: a(n.FIN_BALANCE), finBuyAmount: a(n.FIN_BUY_AMT), finRepayAmount: a(n.FIN_REPAY_AMT), loanBalance: a(n.LOAN_BALANCE), loanSellVolume: a(n.LOAN_SELL_VOLUME), loanRepayVolume: a(n.LOAN_REPAY_VOLUME) }));
}
var F = {};
Et(F, { getCommodityOptionKline: () => Eo, getCommodityOptionSpot: () => Ro, getETFOption5DayMinute: () => So, getETFOptionDailyKline: () => yo, getETFOptionExpireDay: () => fo, getETFOptionMinute: () => To, getETFOptionMonths: () => go, getIndexOptionKline: () => mo, getIndexOptionSpot: () => po });
function Si(t) {
  return { buyVolume: a(t[0]), buyPrice: a(t[1]), price: a(t[2]), askPrice: a(t[3]), askVolume: a(t[4]), openInterest: a(t[5]), change: a(t[6]), strikePrice: a(t[7]), symbol: t[8] ?? "" };
}
function Ri(t) {
  return { buyVolume: a(t[0]), buyPrice: a(t[1]), price: a(t[2]), askPrice: a(t[3]), askVolume: a(t[4]), openInterest: a(t[5]), change: a(t[6]), strikePrice: null, symbol: t[7] ?? "" };
}
async function po(t, e) {
  let r = `${de}?type=futures&product=${t}&exchange=cffex&pinzhong=${e}`, n = await N(r), o = n?.result?.data?.up ?? [], i = n?.result?.data?.down ?? [];
  return { calls: o.map(Si), puts: i.map(Ri) };
}
async function mo(t) {
  let e = `${me}?symbol=${t}`, r = await N(e, { callbackMode: "path" });
  return Array.isArray(r) ? r.map((n) => ({ date: n.d, open: a(n.o), high: a(n.h), low: a(n.l), close: a(n.c), volume: a(n.v) })) : [];
}
async function go(t) {
  let e = `${jt}?exchange=null&cate=${encodeURIComponent(t)}`, n = (await N(e))?.result?.data, o = n?.contractMonth ?? [];
  return { months: o.length > 1 ? o.slice(1) : o, stockId: n?.stockId ?? "", cateId: n?.cateId ?? "", cateList: n?.cateList ?? [] };
}
async function fo(t, e) {
  let r = `${qe}?exchange=null&cate=${encodeURIComponent(t)}&date=${e}`, n = await N(r), o = n?.result?.data?.remainderDays;
  if (typeof o == "number" && o < 0) {
    let s = `${qe}?exchange=null&cate=${encodeURIComponent("XD" + t)}&date=${e}`;
    n = await N(s);
  }
  let i = n?.result?.data;
  return { expireDay: i?.expireDay ?? "", remainderDays: i?.remainderDays ?? 0, stockId: i?.stockId ?? "", name: i?.other?.name ?? "" };
}
function ho(t) {
  let e = "";
  return t.map((r) => (r.d && (e = r.d), { time: r.i, date: e, price: a(r.p), volume: a(r.v), openInterest: a(r.t), avgPrice: a(r.a) }));
}
async function To(t) {
  let e = `CON_OP_${t}`, r = `${Gt}?symbol=${e}`, o = (await N(r))?.result?.data;
  return Array.isArray(o) ? ho(o) : [];
}
async function yo(t) {
  let e = `CON_OP_${t}`, r = `${Yt}?symbol=${e}`, n = await N(r, { callbackMode: "path" });
  return Array.isArray(n) ? n.map((o) => ({ date: o.d, open: a(o.o), high: a(o.h), low: a(o.l), close: a(o.c), volume: a(o.v) })) : [];
}
async function So(t) {
  let e = `CON_OP_${t}`, r = `${Vt}?symbol=${e}`, o = (await N(r))?.result?.data;
  if (!Array.isArray(o)) return [];
  let i = [];
  for (let s of o) Array.isArray(s) && i.push(...ho(s));
  return i;
}
function Ei(t) {
  return { buyVolume: a(t[0]), buyPrice: a(t[1]), price: a(t[2]), askPrice: a(t[3]), askVolume: a(t[4]), openInterest: a(t[5]), change: a(t[6]), strikePrice: a(t[7]), symbol: t[8] ?? "" };
}
function Ci(t) {
  return { buyVolume: a(t[0]), buyPrice: a(t[1]), price: a(t[2]), askPrice: a(t[3]), askVolume: a(t[4]), openInterest: a(t[5]), change: a(t[6]), strikePrice: null, symbol: t[7] ?? "" };
}
async function Ro(t, e) {
  let r = $e[t];
  if (!r) throw new RangeError(`Unknown commodity option variety: "${t}". Available: ${Object.keys($e).join(", ")}`);
  let n = `${de}?type=futures&product=${r.product}&exchange=${r.exchange}&pinzhong=${e}`, o = await N(n), i = o?.result?.data?.up ?? [], s = o?.result?.data?.down ?? [];
  return { calls: i.map(Ei), puts: s.map(Ci) };
}
async function Eo(t) {
  let e = `${me}?symbol=${t}`, r = await N(e, { callbackMode: "path" });
  return Array.isArray(r) ? r.map((n) => ({ date: n.d, open: a(n.o), high: a(n.h), low: a(n.l), close: a(n.c), volume: a(n.v) })) : [];
}
var _ = class {
  constructor(e) {
    this.client = e;
  }
};
var Ae = class extends _ {
  constructor(e) {
    super(e);
  }
  getFullQuotes(e) {
    return I.getFullQuotes(this.client, e);
  }
  getSimpleQuotes(e) {
    return I.getSimpleQuotes(this.client, e);
  }
  getHKQuotes(e) {
    return I.getHKQuotes(this.client, e);
  }
  getUSQuotes(e) {
    return I.getUSQuotes(this.client, e);
  }
  getFundQuotes(e) {
    return I.getFundQuotes(this.client, e);
  }
  getFundFlow(e) {
    return I.getFundFlow(this.client, e);
  }
  getPanelLargeOrder(e) {
    return I.getPanelLargeOrder(this.client, e);
  }
  getTodayTimeline(e) {
    return I.getTodayTimeline(this.client, e);
  }
  search(e) {
    return I.search(this.client, e);
  }
  getAShareCodeList(e) {
    return I.getAShareCodeList(this.client, e);
  }
  getUSCodeList(e) {
    return I.getUSCodeList(this.client, e);
  }
  getHKCodeList() {
    return I.getHKCodeList(this.client);
  }
  getFundCodeList() {
    return I.getFundCodeList(this.client);
  }
  async getAllAShareQuotes(e = {}) {
    let { market: r, ...n } = e, o = await this.getAShareCodeList({ market: r });
    return I.getAllQuotesByCodes(this.client, o, n);
  }
  async getAllHKShareQuotes(e = {}) {
    let r = await this.getHKCodeList();
    return I.getAllHKQuotesByCodes(this.client, r, e);
  }
  async getAllUSShareQuotes(e = {}) {
    let { market: r, ...n } = e, o = await this.getUSCodeList({ simple: true, market: r });
    return I.getAllUSQuotesByCodes(this.client, o, n);
  }
  getAllQuotesByCodes(e, r = {}) {
    return I.getAllQuotesByCodes(this.client, e, r);
  }
  batchRaw(e) {
    return this.client.getTencentQuote(e);
  }
  getTradingCalendar() {
    return I.getTradingCalendar(this.client);
  }
  getDividendDetail(e) {
    return y.getDividendDetail(this.client, e);
  }
};
var _e = class extends _ {
  constructor(e) {
    super(e);
  }
  getIndustryList() {
    return y.getIndustryList(this.client);
  }
  getIndustrySpot(e) {
    return y.getIndustrySpot(this.client, e);
  }
  getIndustryConstituents(e) {
    return y.getIndustryConstituents(this.client, e);
  }
  getIndustryKline(e, r) {
    return y.getIndustryKline(this.client, e, r);
  }
  getIndustryMinuteKline(e, r) {
    return y.getIndustryMinuteKline(this.client, e, r);
  }
  getConceptList() {
    return y.getConceptList(this.client);
  }
  getConceptSpot(e) {
    return y.getConceptSpot(this.client, e);
  }
  getConceptConstituents(e) {
    return y.getConceptConstituents(this.client, e);
  }
  getConceptKline(e, r) {
    return y.getConceptKline(this.client, e, r);
  }
  getConceptMinuteKline(e, r) {
    return y.getConceptMinuteKline(this.client, e, r);
  }
};
var Ie = class extends _ {
  constructor(e) {
    super(e);
  }
  getHistoryKline(e, r) {
    return y.getHistoryKline(this.client, e, r);
  }
  getMinuteKline(e, r) {
    return y.getMinuteKline(this.client, e, r);
  }
  getHKHistoryKline(e, r) {
    return y.getHKHistoryKline(this.client, e, r);
  }
  getUSHistoryKline(e, r) {
    return y.getUSHistoryKline(this.client, e, r);
  }
};
var Pe = class extends _ {
  constructor(e) {
    super(e);
  }
  getFuturesKline(e, r) {
    return y.getFuturesHistoryKline(this.client, e, r);
  }
  getGlobalFuturesSpot(e) {
    return y.getGlobalFuturesSpot(this.client, e);
  }
  getGlobalFuturesKline(e, r) {
    return y.getGlobalFuturesKline(this.client, e, r);
  }
  getFuturesInventorySymbols() {
    return y.getFuturesInventorySymbols(this.client);
  }
  getFuturesInventory(e, r) {
    return y.getFuturesInventory(this.client, e, r);
  }
  getComexInventory(e, r) {
    return y.getComexInventory(this.client, e, r);
  }
};
var De = class extends _ {
  constructor(e) {
    super(e);
  }
  getIndexOptionSpot(e, r) {
    return F.getIndexOptionSpot(e, r);
  }
  getIndexOptionKline(e) {
    return F.getIndexOptionKline(e);
  }
  getCFFEXOptionQuotes(e) {
    return y.getCFFEXOptionQuotes(this.client, e);
  }
  getETFOptionMonths(e) {
    return F.getETFOptionMonths(e);
  }
  getETFOptionExpireDay(e, r) {
    return F.getETFOptionExpireDay(e, r);
  }
  getETFOptionMinute(e) {
    return F.getETFOptionMinute(e);
  }
  getETFOptionDailyKline(e) {
    return F.getETFOptionDailyKline(e);
  }
  getETFOption5DayMinute(e) {
    return F.getETFOption5DayMinute(e);
  }
  getCommodityOptionSpot(e, r) {
    return F.getCommodityOptionSpot(e, r);
  }
  getCommodityOptionKline(e) {
    return F.getCommodityOptionKline(e);
  }
  getOptionLHB(e, r) {
    return y.getOptionLHB(this.client, e, r);
  }
};
function be(t, e = 2) {
  let r = Math.pow(10, e);
  return Math.round(t * r) / r;
}
function J(t, e) {
  let r = [];
  for (let n = 0; n < t.length; n++) {
    if (n < e - 1) {
      r.push(null);
      continue;
    }
    let o = 0, i = 0;
    for (let s = n - e + 1; s <= n; s++) t[s] !== null && (o += t[s], i++);
    r.push(i === e ? be(o / e) : null);
  }
  return r;
}
function Q(t, e) {
  let r = [], n = 2 / (e + 1), o = null, i = false;
  for (let s = 0; s < t.length; s++) {
    if (s < e - 1) {
      r.push(null);
      continue;
    }
    if (!i) {
      let l = 0, c = 0;
      for (let p = s - e + 1; p <= s; p++) t[p] !== null && (l += t[p], c++);
      c === e && (o = l / e, i = true), r.push(o !== null ? be(o) : null);
      continue;
    }
    let u = t[s];
    u === null ? r.push(o !== null ? be(o) : null) : (o = n * u + (1 - n) * o, r.push(be(o)));
  }
  return r;
}
function Cr(t, e) {
  let r = [], n = Array.from({ length: e }, (i, s) => s + 1), o = n.reduce((i, s) => i + s, 0);
  for (let i = 0; i < t.length; i++) {
    if (i < e - 1) {
      r.push(null);
      continue;
    }
    let s = 0, u = true;
    for (let l = 0; l < e; l++) {
      let c = t[i - e + 1 + l];
      if (c === null) {
        u = false;
        break;
      }
      s += c * n[l];
    }
    r.push(u ? be(s / o) : null);
  }
  return r;
}
function tt(t, e = {}) {
  let { periods: r = [5, 10, 20, 30, 60, 120, 250], type: n = "sma" } = e, o = n === "ema" ? Q : n === "wma" ? Cr : J, i = {};
  for (let s of r) i[`ma${s}`] = o(t, s);
  return t.map((s, u) => {
    let l = {};
    for (let c of r) l[`ma${c}`] = i[`ma${c}`][u];
    return l;
  });
}
function Co(t, e = 2) {
  let r = Math.pow(10, e);
  return Math.round(t * r) / r;
}
function rt(t, e = {}) {
  let { short: r = 12, long: n = 26, signal: o = 9 } = e, i = Q(t, r), s = Q(t, n), u = t.map((c, p) => i[p] === null || s[p] === null ? null : i[p] - s[p]), l = Q(u, o);
  return t.map((c, p) => ({ dif: u[p] !== null ? Co(u[p]) : null, dea: l[p], macd: u[p] !== null && l[p] !== null ? Co((u[p] - l[p]) * 2) : null }));
}
function Or(t, e = 2) {
  let r = Math.pow(10, e);
  return Math.round(t * r) / r;
}
function Oi(t, e, r) {
  let n = [];
  for (let o = 0; o < t.length; o++) {
    if (o < e - 1 || r[o] === null) {
      n.push(null);
      continue;
    }
    let i = 0, s = 0;
    for (let u = o - e + 1; u <= o; u++) t[u] !== null && r[o] !== null && (i += Math.pow(t[u] - r[o], 2), s++);
    n.push(s === e ? Math.sqrt(i / e) : null);
  }
  return n;
}
function nt(t, e = {}) {
  let { period: r = 20, stdDev: n = 2 } = e, o = J(t, r), i = Oi(t, r, o);
  return t.map((s, u) => {
    if (o[u] === null || i[u] === null) return { mid: null, upper: null, lower: null, bandwidth: null };
    let l = o[u] + n * i[u], c = o[u] - n * i[u], p = o[u] !== 0 ? Or((l - c) / o[u] * 100) : null;
    return { mid: o[u], upper: Or(l), lower: Or(c), bandwidth: p };
  });
}
function Ar(t, e = 2) {
  let r = Math.pow(10, e);
  return Math.round(t * r) / r;
}
function ot(t, e = {}) {
  let { period: r = 9, kPeriod: n = 3, dPeriod: o = 3 } = e, i = [], s = 50, u = 50;
  for (let l = 0; l < t.length; l++) {
    if (l < r - 1) {
      i.push({ k: null, d: null, j: null });
      continue;
    }
    let c = -1 / 0, p = 1 / 0, d = true;
    for (let f = l - r + 1; f <= l; f++) {
      if (t[f].high === null || t[f].low === null) {
        d = false;
        break;
      }
      c = Math.max(c, t[f].high), p = Math.min(p, t[f].low);
    }
    let g = t[l].close;
    if (!d || g === null || c === p) {
      i.push({ k: null, d: null, j: null });
      continue;
    }
    let h = (g - p) / (c - p) * 100;
    s = (n - 1) / n * s + 1 / n * h, u = (o - 1) / o * u + 1 / o * s;
    let S = 3 * s - 2 * u;
    i.push({ k: Ar(s), d: Ar(u), j: Ar(S) });
  }
  return i;
}
function Ai(t, e = 2) {
  let r = Math.pow(10, e);
  return Math.round(t * r) / r;
}
function it(t, e = {}) {
  let { periods: r = [6, 12, 24] } = e, n = [null];
  for (let i = 1; i < t.length; i++) t[i] === null || t[i - 1] === null ? n.push(null) : n.push(t[i] - t[i - 1]);
  let o = {};
  for (let i of r) {
    let s = [], u = 0, l = 0;
    for (let c = 0; c < t.length; c++) {
      if (c < i) {
        s.push(null), n[c] !== null && (n[c] > 0 ? u += n[c] : l += Math.abs(n[c]));
        continue;
      }
      if (c === i) u = u / i, l = l / i;
      else {
        let p = n[c] ?? 0, d = p > 0 ? p : 0, g = p < 0 ? Math.abs(p) : 0;
        u = (u * (i - 1) + d) / i, l = (l * (i - 1) + g) / i;
      }
      if (l === 0) s.push(100);
      else if (u === 0) s.push(0);
      else {
        let p = u / l;
        s.push(Ai(100 - 100 / (1 + p)));
      }
    }
    o[`rsi${i}`] = s;
  }
  return t.map((i, s) => {
    let u = {};
    for (let l of r) u[`rsi${l}`] = o[`rsi${l}`][s];
    return u;
  });
}
function _i(t, e = 2) {
  let r = Math.pow(10, e);
  return Math.round(t * r) / r;
}
function st(t, e = {}) {
  let { periods: r = [6, 10] } = e, n = {};
  for (let o of r) {
    let i = [];
    for (let s = 0; s < t.length; s++) {
      if (s < o - 1) {
        i.push(null);
        continue;
      }
      let u = -1 / 0, l = 1 / 0, c = true;
      for (let g = s - o + 1; g <= s; g++) {
        if (t[g].high === null || t[g].low === null) {
          c = false;
          break;
        }
        u = Math.max(u, t[g].high), l = Math.min(l, t[g].low);
      }
      let p = t[s].close;
      if (!c || p === null || u === l) {
        i.push(null);
        continue;
      }
      let d = (u - p) / (u - l) * 100;
      i.push(_i(d));
    }
    n[`wr${o}`] = i;
  }
  return t.map((o, i) => {
    let s = {};
    for (let u of r) s[`wr${u}`] = n[`wr${u}`][i];
    return s;
  });
}
function Ii(t, e = 2) {
  let r = Math.pow(10, e);
  return Math.round(t * r) / r;
}
function at(t, e = {}) {
  let { periods: r = [6, 12, 24] } = e, n = {};
  for (let o of r) {
    let i = J(t, o), s = [];
    for (let u = 0; u < t.length; u++) if (t[u] === null || i[u] === null || i[u] === 0) s.push(null);
    else {
      let l = (t[u] - i[u]) / i[u] * 100;
      s.push(Ii(l));
    }
    n[`bias${o}`] = s;
  }
  return t.map((o, i) => {
    let s = {};
    for (let u of r) s[`bias${u}`] = n[`bias${u}`][i];
    return s;
  });
}
function Pi(t, e = 2) {
  let r = Math.pow(10, e);
  return Math.round(t * r) / r;
}
function ut(t, e = {}) {
  let { period: r = 14 } = e, n = [], o = t.map((i) => i.high === null || i.low === null || i.close === null ? null : (i.high + i.low + i.close) / 3);
  for (let i = 0; i < t.length; i++) {
    if (i < r - 1) {
      n.push({ cci: null });
      continue;
    }
    let s = 0, u = 0;
    for (let d = i - r + 1; d <= i; d++) o[d] !== null && (s += o[d], u++);
    if (u !== r || o[i] === null) {
      n.push({ cci: null });
      continue;
    }
    let l = s / r, c = 0;
    for (let d = i - r + 1; d <= i; d++) c += Math.abs(o[d] - l);
    let p = c / r;
    if (p === 0) n.push({ cci: 0 });
    else {
      let d = (o[i] - l) / (0.015 * p);
      n.push({ cci: Pi(d) });
    }
  }
  return n;
}
function _r(t, e = 2) {
  let r = Math.pow(10, e);
  return Math.round(t * r) / r;
}
function ie(t, e = {}) {
  let { period: r = 14 } = e, n = [], o = [];
  for (let s = 0; s < t.length; s++) {
    let { high: u, low: l, close: c } = t[s];
    if (u === null || l === null || c === null) {
      o.push(null);
      continue;
    }
    if (s === 0) o.push(u - l);
    else {
      let p = t[s - 1].close;
      if (p === null) o.push(u - l);
      else {
        let d = u - l, g = Math.abs(u - p), h = Math.abs(l - p);
        o.push(Math.max(d, g, h));
      }
    }
  }
  let i = null;
  for (let s = 0; s < t.length; s++) {
    if (s < r - 1) {
      n.push({ tr: o[s] !== null ? _r(o[s]) : null, atr: null });
      continue;
    }
    if (s === r - 1) {
      let u = 0, l = 0;
      for (let c = 0; c < r; c++) o[c] !== null && (u += o[c], l++);
      l === r && (i = u / r);
    } else i !== null && o[s] !== null && (i = (i * (r - 1) + o[s]) / r);
    n.push({ tr: o[s] !== null ? _r(o[s]) : null, atr: i !== null ? _r(i) : null });
  }
  return n;
}
function lt(t, e = {}) {
  let { maPeriod: r } = e, n = [];
  if (t.length === 0) return n;
  let o = t[0].volume ?? 0;
  n.push({ obv: o, obvMa: null });
  for (let i = 1; i < t.length; i++) {
    let s = t[i], u = t[i - 1];
    if (s.close === null || u.close === null || s.volume === null || s.volume === void 0) {
      n.push({ obv: null, obvMa: null });
      continue;
    }
    s.close > u.close ? o += s.volume : s.close < u.close && (o -= s.volume), n.push({ obv: o, obvMa: null });
  }
  if (r && r > 0) for (let i = r - 1; i < n.length; i++) {
    let s = 0, u = 0;
    for (let l = i - r + 1; l <= i; l++) n[l].obv !== null && (s += n[l].obv, u++);
    u === r && (n[i].obvMa = s / r);
  }
  return n;
}
function ct(t, e = {}) {
  let { period: r = 12, signalPeriod: n } = e, o = [];
  for (let i = 0; i < t.length; i++) {
    if (i < r) {
      o.push({ roc: null, signal: null });
      continue;
    }
    let s = t[i].close, u = t[i - r].close;
    if (s === null || u === null || u === 0) {
      o.push({ roc: null, signal: null });
      continue;
    }
    let l = (s - u) / u * 100;
    o.push({ roc: l, signal: null });
  }
  if (n && n > 0) for (let i = r + n - 1; i < o.length; i++) {
    let s = 0, u = 0;
    for (let l = i - n + 1; l <= i; l++) o[l].roc !== null && (s += o[l].roc, u++);
    u === n && (o[i].signal = s / n);
  }
  return o;
}
function pt(t, e = {}) {
  let { period: r = 14, adxPeriod: n = r } = e, o = [];
  if (t.length < 2) return t.map(() => ({ pdi: null, mdi: null, adx: null, adxr: null }));
  let i = [], s = [], u = [];
  for (let f = 0; f < t.length; f++) {
    if (f === 0) {
      i.push(0), s.push(0), u.push(0), o.push({ pdi: null, mdi: null, adx: null, adxr: null });
      continue;
    }
    let R = t[f], E = t[f - 1];
    if (R.high === null || R.low === null || R.close === null || E.high === null || E.low === null || E.close === null) {
      i.push(0), s.push(0), u.push(0), o.push({ pdi: null, mdi: null, adx: null, adxr: null });
      continue;
    }
    let P = R.high - R.low, b = Math.abs(R.high - E.close), M = Math.abs(R.low - E.close);
    u.push(Math.max(P, b, M));
    let q = R.high - E.high, V = E.low - R.low;
    q > V && q > 0 ? i.push(q) : i.push(0), V > q && V > 0 ? s.push(V) : s.push(0), o.push({ pdi: null, mdi: null, adx: null, adxr: null });
  }
  let l = 0, c = 0, p = 0, d = [];
  for (let f = 1; f < t.length; f++) {
    if (f < r) {
      l += u[f], c += i[f], p += s[f], d.push(0);
      continue;
    }
    f === r ? (l = l, c = c, p = p) : (l = l - l / r + u[f], c = c - c / r + i[f], p = p - p / r + s[f]);
    let R = l > 0 ? c / l * 100 : 0, E = l > 0 ? p / l * 100 : 0;
    o[f].pdi = R, o[f].mdi = E;
    let P = R + E, b = P > 0 ? Math.abs(R - E) / P * 100 : 0;
    d.push(b);
  }
  let g = 0, h = 0, S = 0;
  for (let f = r; f < t.length; f++) {
    if (f < r * 2 - 1) {
      g += d[f - r + 1] || 0, h++;
      continue;
    }
    if (f === r * 2 - 1) g += d[f - r + 1] || 0, S = g / n, o[f].adx = S;
    else {
      let R = d[f - r + 1] || 0;
      S = (S * (n - 1) + R) / n, o[f].adx = S;
    }
  }
  for (let f = r * 2 - 1 + n; f < t.length; f++) {
    let R = o[f].adx, E = o[f - n]?.adx;
    R !== null && E !== null && (o[f].adxr = (R + E) / 2);
  }
  return o;
}
function dt(t, e = {}) {
  let { afStart: r = 0.02, afIncrement: n = 0.02, afMax: o = 0.2 } = e, i = [];
  if (t.length < 2) return t.map(() => ({ sar: null, trend: null, ep: null, af: null }));
  let s = 1, u = r, l = t[0].high ?? 0, c = t[0].low ?? 0, p = t[0], d = t[1];
  p.close !== null && d.close !== null && d.close < p.close && (s = -1, l = p.low ?? 0, c = p.high ?? 0), i.push({ sar: null, trend: null, ep: null, af: null });
  for (let g = 1; g < t.length; g++) {
    let h = t[g], S = t[g - 1];
    if (h.high === null || h.low === null || S.high === null || S.low === null) {
      i.push({ sar: null, trend: null, ep: null, af: null });
      continue;
    }
    let f = c + u * (l - c);
    s === 1 ? (f = Math.min(f, S.low, t[Math.max(0, g - 2)]?.low ?? S.low), h.low < f ? (s = -1, f = l, l = h.low, u = r) : h.high > l && (l = h.high, u = Math.min(u + n, o))) : (f = Math.max(f, S.high, t[Math.max(0, g - 2)]?.high ?? S.high), h.high > f ? (s = 1, f = l, l = h.high, u = r) : h.low < l && (l = h.low, u = Math.min(u + n, o))), c = f, i.push({ sar: c, trend: s, ep: l, af: u });
  }
  return i;
}
function mt(t, e = {}) {
  let { emaPeriod: r = 20, atrPeriod: n = 10, multiplier: o = 2 } = e, i = [], s = t.map((c) => c.close), u = Q(s, r), l = ie(t, { period: n });
  for (let c = 0; c < t.length; c++) {
    let p = u[c], d = l[c]?.atr;
    if (p === null || d === null) {
      i.push({ mid: null, upper: null, lower: null, width: null });
      continue;
    }
    let g = p + o * d, h = p - o * d, S = p > 0 ? (g - h) / p * 100 : null;
    i.push({ mid: p, upper: g, lower: h, width: S });
  }
  return i;
}
function gt(t, e = 0) {
  return t.length === 0 ? e : Math.max(...t);
}
function ft(t) {
  return { closes: t.map((e) => e.close), ohlcv: t.map((e) => ({ open: e.open, high: e.high, low: e.low, close: e.close, volume: e.volume })) };
}
var se = { ma: { key: "ma", estimateLookback: (t) => {
  let e = typeof t == "object" ? t : {}, r = e.periods ?? [5, 10, 20, 30, 60, 120, 250], n = e.type ?? "sma";
  return { bars: gt(r, 20), emaBased: n === "ema" };
}, compute: (t, e) => tt(t.closes, typeof e == "object" ? e : {}) }, macd: { key: "macd", estimateLookback: (t) => {
  let e = typeof t == "object" ? t : {}, r = e.long ?? 26, n = e.signal ?? 9;
  return { bars: r * 3 + n, emaBased: true };
}, compute: (t, e) => rt(t.closes, typeof e == "object" ? e : {}) }, boll: { key: "boll", estimateLookback: (t) => ({ bars: typeof t == "object" && t.period ? t.period : 20 }), compute: (t, e) => nt(t.closes, typeof e == "object" ? e : {}) }, kdj: { key: "kdj", estimateLookback: (t) => ({ bars: typeof t == "object" && t.period ? t.period : 9 }), compute: (t, e) => ot(t.ohlcv, typeof e == "object" ? e : {}) }, rsi: { key: "rsi", estimateLookback: (t) => {
  let e = typeof t == "object" && t.periods ? t.periods : [6, 12, 24];
  return { bars: gt(e, 14) + 1 };
}, compute: (t, e) => it(t.closes, typeof e == "object" ? e : {}) }, wr: { key: "wr", estimateLookback: (t) => {
  let e = typeof t == "object" && t.periods ? t.periods : [6, 10];
  return { bars: gt(e, 10) };
}, compute: (t, e) => st(t.ohlcv, typeof e == "object" ? e : {}) }, bias: { key: "bias", estimateLookback: (t) => {
  let e = typeof t == "object" && t.periods ? t.periods : [6, 12, 24];
  return { bars: gt(e, 12) };
}, compute: (t, e) => at(t.closes, typeof e == "object" ? e : {}) }, cci: { key: "cci", estimateLookback: (t) => ({ bars: typeof t == "object" && t.period ? t.period : 14 }), compute: (t, e) => ut(t.ohlcv, typeof e == "object" ? e : {}) }, atr: { key: "atr", estimateLookback: (t) => ({ bars: typeof t == "object" && t.period ? t.period : 14 }), compute: (t, e) => ie(t.ohlcv, typeof e == "object" ? e : {}) }, obv: { key: "obv", estimateLookback: (t) => {
  let e = typeof t == "object" && t.maPeriod ? t.maPeriod : 0;
  return { bars: Math.max(2, e) };
}, compute: (t, e) => lt(t.ohlcv, typeof e == "object" ? e : {}) }, roc: { key: "roc", estimateLookback: (t) => {
  let e = typeof t == "object" ? t : {}, r = e.period ?? 12, n = e.signalPeriod ?? 0;
  return { bars: r + n };
}, compute: (t, e) => ct(t.ohlcv, typeof e == "object" ? e : {}) }, dmi: { key: "dmi", estimateLookback: (t) => {
  let e = typeof t == "object" ? t : {}, r = e.period ?? 14, n = e.adxPeriod ?? r;
  return { bars: r * 2 + n };
}, compute: (t, e) => pt(t.ohlcv, typeof e == "object" ? e : {}) }, sar: { key: "sar", estimateLookback: () => ({ bars: 5 }), compute: (t, e) => dt(t.ohlcv, typeof e == "object" ? e : {}) }, kc: { key: "kc", estimateLookback: (t) => {
  let e = typeof t == "object" ? t : {}, r = e.emaPeriod ?? 20, n = e.atrPeriod ?? 10;
  return { bars: Math.max(r * 3, n), emaBased: true };
}, compute: (t, e) => mt(t.ohlcv, typeof e == "object" ? e : {}) } };
function Me(t) {
  return Object.keys(se).filter((e) => !!t[e]);
}
function ht(t) {
  let e = 0, r = false;
  for (let o of Me(t)) {
    let s = se[o].estimateLookback(t[o]);
    e = Math.max(e, s.bars), r || (r = !!s.emaBased);
  }
  return { maxLookback: e, hasEmaBasedIndicator: r, requiredBars: Math.ceil(e * (r ? 1.5 : 1.2)) };
}
function Tt(t, e = {}) {
  if (t.length === 0) return [];
  let r = ft(t), n = /* @__PURE__ */ new Map();
  for (let o of Me(e)) {
    let i = se[o];
    n.set(o, i.compute(r, e[o]));
  }
  return t.map((o, i) => ({ ...o, ...Object.fromEntries(Array.from(n.entries()).map(([s, u]) => [s, u[i]])) }));
}
var ke = class {
  constructor(e, r) {
    this.klineService = e;
    this.quoteService = r;
  }
  detectMarket(e) {
    return /^\d{3}\.[A-Z]+$/i.test(e) ? "US" : /^\d{5}$/.test(e) ? "HK" : "A";
  }
  calcActualStartDate(e, r, n = 1.5) {
    let o = this.toCompactDate(e), i = Math.ceil(r * n), s = new Date(parseInt(o.slice(0, 4)), parseInt(o.slice(4, 6)) - 1, parseInt(o.slice(6, 8)));
    s.setDate(s.getDate() - i);
    let u = s.getFullYear(), l = String(s.getMonth() + 1).padStart(2, "0"), c = String(s.getDate()).padStart(2, "0");
    return `${u}${l}${c}`;
  }
  calcActualStartDateByCalendar(e, r, n) {
    if (!n || n.length === 0) return;
    let o = this.normalizeDate(e), i = n.findIndex((u) => u >= o);
    i === -1 && (i = n.length - 1);
    let s = Math.max(0, i - r);
    return this.toCompactDate(n[s]);
  }
  normalizeDate(e) {
    return e.includes("-") ? e : e.length === 8 ? `${e.slice(0, 4)}-${e.slice(4, 6)}-${e.slice(6, 8)}` : e;
  }
  toCompactDate(e) {
    return e.replace(/-/g, "");
  }
  dateToTimestamp(e) {
    let r = e.includes("-") ? e : `${e.slice(0, 4)}-${e.slice(4, 6)}-${e.slice(6, 8)}`;
    return new Date(r).getTime();
  }
  async getKlineWithIndicators(e, r = {}) {
    let { startDate: n, endDate: o, indicators: i = {} } = r, s = r.market ?? this.detectMarket(e), { requiredBars: u } = ht(i), l = { A: 1.5, HK: 1.46, US: 1.45 }, c;
    if (n) if (s === "A") try {
      let h = await this.quoteService.getTradingCalendar();
      c = this.calcActualStartDateByCalendar(n, u, h) ?? this.calcActualStartDate(n, u, l[s]);
    } catch {
      c = this.calcActualStartDate(n, u, l[s]);
    }
    else c = this.calcActualStartDate(n, u, l[s]);
    let p = { period: r.period, adjust: r.adjust, startDate: c, endDate: r.endDate ? this.toCompactDate(r.endDate) : void 0 }, d;
    switch (s) {
      case "HK":
        d = await this.klineService.getHKHistoryKline(e, p);
        break;
      case "US":
        d = await this.klineService.getUSHistoryKline(e, p);
        break;
      default:
        d = await this.klineService.getHistoryKline(e, p);
    }
    if (n && d.length < u) switch (s) {
      case "HK":
        d = await this.klineService.getHKHistoryKline(e, { ...p, startDate: void 0 });
        break;
      case "US":
        d = await this.klineService.getUSHistoryKline(e, { ...p, startDate: void 0 });
        break;
      default:
        d = await this.klineService.getHistoryKline(e, { ...p, startDate: void 0 });
    }
    let g = Tt(d, i);
    if (n) {
      let h = this.dateToTimestamp(n), S = o ? this.dateToTimestamp(o) : 1 / 0;
      return g.filter((f) => {
        let R = this.dateToTimestamp(f.date);
        return R >= h && R <= S;
      });
    }
    return g;
  }
};
var Le = class extends _ {
  constructor(e) {
    super(e);
  }
  getIndividualFundFlow(e, r) {
    return y.getIndividualFundFlow(this.client, e, r);
  }
  getMarketFundFlow() {
    return y.getMarketFundFlow(this.client);
  }
  getFundFlowRank(e) {
    return y.getFundFlowRank(this.client, e);
  }
  getSectorFundFlowRank(e) {
    return y.getSectorFundFlowRank(this.client, e);
  }
  getSectorFundFlowHistory(e, r) {
    return y.getSectorFundFlowHistory(this.client, e, r);
  }
};
var Ne = class extends _ {
  constructor(e) {
    super(e);
  }
  getNorthboundMinute(e) {
    return y.getNorthboundMinute(this.client, e);
  }
  getNorthboundFlowSummary() {
    return y.getNorthboundFlowSummary(this.client);
  }
  getNorthboundHoldingRank(e) {
    return y.getNorthboundHoldingRank(this.client, e);
  }
  getNorthboundHistory(e, r) {
    return y.getNorthboundHistory(this.client, e, r);
  }
  getNorthboundIndividual(e, r) {
    return y.getNorthboundIndividual(this.client, e, r);
  }
};
var xe = class extends _ {
  constructor(e) {
    super(e);
  }
  getZTPool(e, r) {
    return y.getZTPool(this.client, e, r);
  }
  getStockChanges(e) {
    return y.getStockChanges(this.client, e);
  }
  getBoardChanges() {
    return y.getBoardChanges(this.client);
  }
};
var Fe = class extends _ {
  constructor(e) {
    super(e);
  }
  getDragonTigerDetail(e) {
    return y.getDragonTigerDetail(this.client, e);
  }
  getDragonTigerStockStats(e) {
    return y.getDragonTigerStockStats(this.client, e);
  }
  getDragonTigerInstitution(e) {
    return y.getDragonTigerInstitution(this.client, e);
  }
  getDragonTigerBranchRank(e) {
    return y.getDragonTigerBranchRank(this.client, e);
  }
  getDragonTigerStockSeatDetail(e, r) {
    return y.getDragonTigerStockSeatDetail(this.client, e, r);
  }
};
var ve = class extends _ {
  constructor(e) {
    super(e);
  }
  getBlockTradeMarketStat() {
    return y.getBlockTradeMarketStat(this.client);
  }
  getBlockTradeDetail(e) {
    return y.getBlockTradeDetail(this.client, e);
  }
  getBlockTradeDailyStat(e) {
    return y.getBlockTradeDailyStat(this.client, e);
  }
  getMarginAccountInfo() {
    return y.getMarginAccountInfo(this.client);
  }
  getMarginTargetList(e) {
    return y.getMarginTargetList(this.client, e);
  }
};
var x = (t, e) => t * 60 + e;
var Di = { A: { tz: O.CN, open: [[x(9, 30), x(11, 30)], [x(13, 0), x(15, 0)]], lunchBreak: [x(11, 30), x(13, 0)], tradingWeekdays: [1, 2, 3, 4, 5] }, HK: { tz: O.HK, open: [[x(9, 30), x(12, 0)], [x(13, 0), x(16, 0)]], lunchBreak: [x(12, 0), x(13, 0)], tradingWeekdays: [1, 2, 3, 4, 5] }, US: { tz: O.US, open: [[x(9, 30), x(16, 0)]], tradingWeekdays: [1, 2, 3, 4, 5] } };
function Ir(t, e) {
  if (t == null) return Pr(/* @__PURE__ */ new Date(), e);
  if (t instanceof Date) return Pr(t, e);
  let r = t.trim();
  if (/^\d{4}-\d{2}-\d{2}$/.test(r)) return r;
  if (/^\d{8}$/.test(r)) return `${r.slice(0, 4)}-${r.slice(4, 6)}-${r.slice(6, 8)}`;
  let n = new Date(r);
  if (!Number.isNaN(n.getTime())) return Pr(n, e);
  throw new RangeError(`Unsupported date input: ${JSON.stringify(t)}. Expected 'YYYY-MM-DD', 'YYYYMMDD', or Date.`);
}
function Pr(t, e) {
  return new Intl.DateTimeFormat("en-CA", { timeZone: e, year: "numeric", month: "2-digit", day: "2-digit" }).format(t);
}
function bi(t, e) {
  let r = new Intl.DateTimeFormat("en-US", { timeZone: e, hour12: false, weekday: "short", hour: "2-digit", minute: "2-digit" }), n = {};
  for (let l of r.formatToParts(t)) l.type !== "literal" && (n[l.type] = l.value);
  let o = parseInt(n.hour ?? "0", 10);
  o === 24 && (o = 0);
  let i = parseInt(n.minute ?? "0", 10), u = { Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6, Sun: 7 }[n.weekday ?? ""] ?? 0;
  return { minutes: o * 60 + i, weekday: u };
}
function Dr(t, e) {
  let r = 0, n = t.length;
  for (; r < n; ) {
    let o = r + n >>> 1;
    t[o] < e ? r = o + 1 : n = o;
  }
  return r;
}
var ae = class {
  constructor(e) {
    this.quoteService = e;
  }
  async isTradingDay(e) {
    let r = Ir(e, O.CN), n = await this.quoteService.getTradingCalendar(), o = Dr(n, r);
    return o < n.length && n[o] === r;
  }
  async nextTradingDay(e) {
    let r = Ir(e, O.CN), n = await this.quoteService.getTradingCalendar(), o = Dr(n, r);
    if (o < n.length && n[o] === r && (o += 1), o >= n.length) throw new RangeError(`nextTradingDay: ${r} \u4E4B\u540E\u6CA1\u6709\u53EF\u7528\u4EA4\u6613\u65E5 (\u65E5\u5386\u6700\u5927\u65E5\u671F ${n[n.length - 1] ?? "N/A"})`);
    return n[o];
  }
  async prevTradingDay(e) {
    let r = Ir(e, O.CN), n = await this.quoteService.getTradingCalendar(), i = Dr(n, r) - 1;
    if (i < 0) throw new RangeError(`prevTradingDay: ${r} \u4E4B\u524D\u6CA1\u6709\u53EF\u7528\u4EA4\u6613\u65E5 (\u65E5\u5386\u6700\u5C0F\u65E5\u671F ${n[0] ?? "N/A"})`);
    return n[i];
  }
  getMarketStatus(e = "A", r = /* @__PURE__ */ new Date()) {
    let n = Di[e], { minutes: o, weekday: i } = bi(r, n.tz);
    if (!n.tradingWeekdays.includes(i)) return "closed";
    let s = n.open[0][0], u = n.open[n.open.length - 1][1];
    if (o < s) return "pre_market";
    if (o >= u) return "after_hours";
    for (let [l, c] of n.open) if (o >= l && o < c) return "open";
    return n.lunchBreak && o >= n.lunchBreak[0] && o < n.lunchBreak[1] ? "lunch_break" : "closed";
  }
};
var yt = class {
  constructor(e = {}) {
    this.client = new Se(e), this.quoteService = new Ae(this.client), this.boardService = new _e(this.client), this.klineService = new Ie(this.client), this.futuresService = new Pe(this.client), this.optionsService = new De(this.client), this.indicatorService = new ke(this.klineService, this.quoteService), this.fundFlowService = new Le(this.client), this.northboundService = new Ne(this.client), this.marketEventService = new xe(this.client), this.dragonTigerService = new Fe(this.client), this.dataService = new ve(this.client), this.tradingCalendarService = new ae(this.quoteService);
  }
  getFullQuotes(e) {
    return this.quoteService.getFullQuotes(e);
  }
  getSimpleQuotes(e) {
    return this.quoteService.getSimpleQuotes(e);
  }
  getHKQuotes(e) {
    return this.quoteService.getHKQuotes(e);
  }
  getUSQuotes(e) {
    return this.quoteService.getUSQuotes(e);
  }
  getFundQuotes(e) {
    return this.quoteService.getFundQuotes(e);
  }
  getFundFlow(e) {
    return this.quoteService.getFundFlow(e);
  }
  getPanelLargeOrder(e) {
    return this.quoteService.getPanelLargeOrder(e);
  }
  getTodayTimeline(e) {
    return this.quoteService.getTodayTimeline(e);
  }
  getIndustryList() {
    return this.boardService.getIndustryList();
  }
  getIndustrySpot(e) {
    return this.boardService.getIndustrySpot(e);
  }
  getIndustryConstituents(e) {
    return this.boardService.getIndustryConstituents(e);
  }
  getIndustryKline(e, r) {
    return this.boardService.getIndustryKline(e, r);
  }
  getIndustryMinuteKline(e, r) {
    return this.boardService.getIndustryMinuteKline(e, r);
  }
  getConceptList() {
    return this.boardService.getConceptList();
  }
  getConceptSpot(e) {
    return this.boardService.getConceptSpot(e);
  }
  getConceptConstituents(e) {
    return this.boardService.getConceptConstituents(e);
  }
  getConceptKline(e, r) {
    return this.boardService.getConceptKline(e, r);
  }
  getConceptMinuteKline(e, r) {
    return this.boardService.getConceptMinuteKline(e, r);
  }
  getHistoryKline(e, r) {
    return this.klineService.getHistoryKline(e, r);
  }
  getMinuteKline(e, r) {
    return this.klineService.getMinuteKline(e, r);
  }
  getHKHistoryKline(e, r) {
    return this.klineService.getHKHistoryKline(e, r);
  }
  getUSHistoryKline(e, r) {
    return this.klineService.getUSHistoryKline(e, r);
  }
  search(e) {
    return this.quoteService.search(e);
  }
  getAShareCodeList(e) {
    return this.quoteService.getAShareCodeList(e);
  }
  getUSCodeList(e) {
    return this.quoteService.getUSCodeList(e);
  }
  getHKCodeList() {
    return this.quoteService.getHKCodeList();
  }
  getFundCodeList() {
    return this.quoteService.getFundCodeList();
  }
  getAllAShareQuotes(e = {}) {
    return this.quoteService.getAllAShareQuotes(e);
  }
  getAllHKShareQuotes(e = {}) {
    return this.quoteService.getAllHKShareQuotes(e);
  }
  getAllUSShareQuotes(e = {}) {
    return this.quoteService.getAllUSShareQuotes(e);
  }
  getAllQuotesByCodes(e, r = {}) {
    return this.quoteService.getAllQuotesByCodes(e, r);
  }
  batchRaw(e) {
    return this.quoteService.batchRaw(e);
  }
  getTradingCalendar() {
    return this.quoteService.getTradingCalendar();
  }
  isTradingDay(e) {
    return this.tradingCalendarService.isTradingDay(e);
  }
  nextTradingDay(e) {
    return this.tradingCalendarService.nextTradingDay(e);
  }
  prevTradingDay(e) {
    return this.tradingCalendarService.prevTradingDay(e);
  }
  getMarketStatus(e = "A") {
    return this.tradingCalendarService.getMarketStatus(e);
  }
  getDividendDetail(e) {
    return this.quoteService.getDividendDetail(e);
  }
  getFuturesKline(e, r) {
    return this.futuresService.getFuturesKline(e, r);
  }
  getGlobalFuturesSpot(e) {
    return this.futuresService.getGlobalFuturesSpot(e);
  }
  getGlobalFuturesKline(e, r) {
    return this.futuresService.getGlobalFuturesKline(e, r);
  }
  getFuturesInventorySymbols() {
    return this.futuresService.getFuturesInventorySymbols();
  }
  getFuturesInventory(e, r) {
    return this.futuresService.getFuturesInventory(e, r);
  }
  getComexInventory(e, r) {
    return this.futuresService.getComexInventory(e, r);
  }
  getIndexOptionSpot(e, r) {
    return this.optionsService.getIndexOptionSpot(e, r);
  }
  getIndexOptionKline(e) {
    return this.optionsService.getIndexOptionKline(e);
  }
  getCFFEXOptionQuotes(e) {
    return this.optionsService.getCFFEXOptionQuotes(e);
  }
  getETFOptionMonths(e) {
    return this.optionsService.getETFOptionMonths(e);
  }
  getETFOptionExpireDay(e, r) {
    return this.optionsService.getETFOptionExpireDay(e, r);
  }
  getETFOptionMinute(e) {
    return this.optionsService.getETFOptionMinute(e);
  }
  getETFOptionDailyKline(e) {
    return this.optionsService.getETFOptionDailyKline(e);
  }
  getETFOption5DayMinute(e) {
    return this.optionsService.getETFOption5DayMinute(e);
  }
  getCommodityOptionSpot(e, r) {
    return this.optionsService.getCommodityOptionSpot(e, r);
  }
  getCommodityOptionKline(e) {
    return this.optionsService.getCommodityOptionKline(e);
  }
  getOptionLHB(e, r) {
    return this.optionsService.getOptionLHB(e, r);
  }
  getKlineWithIndicators(e, r = {}) {
    return this.indicatorService.getKlineWithIndicators(e, r);
  }
  getIndividualFundFlow(e, r) {
    return this.fundFlowService.getIndividualFundFlow(e, r);
  }
  getMarketFundFlow() {
    return this.fundFlowService.getMarketFundFlow();
  }
  getFundFlowRank(e) {
    return this.fundFlowService.getFundFlowRank(e);
  }
  getSectorFundFlowRank(e) {
    return this.fundFlowService.getSectorFundFlowRank(e);
  }
  getSectorFundFlowHistory(e, r) {
    return this.fundFlowService.getSectorFundFlowHistory(e, r);
  }
  getNorthboundMinute(e) {
    return this.northboundService.getNorthboundMinute(e);
  }
  getNorthboundFlowSummary() {
    return this.northboundService.getNorthboundFlowSummary();
  }
  getNorthboundHoldingRank(e) {
    return this.northboundService.getNorthboundHoldingRank(e);
  }
  getNorthboundHistory(e, r) {
    return this.northboundService.getNorthboundHistory(e, r);
  }
  getNorthboundIndividual(e, r) {
    return this.northboundService.getNorthboundIndividual(e, r);
  }
  getZTPool(e, r) {
    return this.marketEventService.getZTPool(e, r);
  }
  getStockChanges(e) {
    return this.marketEventService.getStockChanges(e);
  }
  getBoardChanges() {
    return this.marketEventService.getBoardChanges();
  }
  getDragonTigerDetail(e) {
    return this.dragonTigerService.getDragonTigerDetail(e);
  }
  getDragonTigerStockStats(e) {
    return this.dragonTigerService.getDragonTigerStockStats(e);
  }
  getDragonTigerInstitution(e) {
    return this.dragonTigerService.getDragonTigerInstitution(e);
  }
  getDragonTigerBranchRank(e) {
    return this.dragonTigerService.getDragonTigerBranchRank(e);
  }
  getDragonTigerStockSeatDetail(e, r) {
    return this.dragonTigerService.getDragonTigerStockSeatDetail(e, r);
  }
  getBlockTradeMarketStat() {
    return this.dataService.getBlockTradeMarketStat();
  }
  getBlockTradeDetail(e) {
    return this.dataService.getBlockTradeDetail(e);
  }
  getBlockTradeDailyStat(e) {
    return this.dataService.getBlockTradeDailyStat(e);
  }
  getMarginAccountInfo() {
    return this.dataService.getMarginAccountInfo();
  }
  getMarginTargetList(e) {
    return this.dataService.getMarginTargetList(e);
  }
};

// apps/server/dist/sdk.js
var sdk = new yt({
  timeout: 1e4,
  rateLimit: { requestsPerSecond: 5, maxBurst: 10 },
  retry: { maxRetries: 3, baseDelay: 800 },
  circuitBreaker: { failureThreshold: 5, resetTimeout: 3e4 },
  providerPolicies: {
    eastmoney: {
      rateLimit: { requestsPerSecond: 3, maxBurst: 3 },
      circuitBreaker: { failureThreshold: 3, resetTimeout: 3e4 }
    }
  }
});

// apps/server/dist/cache.js
var store = /* @__PURE__ */ new Map();
function getCached(key) {
  const entry = store.get(key);
  if (!entry)
    return void 0;
  if (Date.now() > entry.expiresAt) {
    store.delete(key);
    return void 0;
  }
  return entry.value;
}
async function withCache(key, ttlMs, fn2) {
  const hit = getCached(key);
  if (hit !== void 0)
    return hit;
  const value = await fn2();
  store.set(key, { value, expiresAt: Date.now() + ttlMs });
  return value;
}
var CACHE_TTL = {
  overview: 6e4,
  allQuotes: 45e3,
  kline: 3e5,
  sector: 6e4,
  search: 3e4
};

// apps/server/dist/utils.js
function normalizeQuote(raw2) {
  const rawCode = String(raw2.code ?? raw2.symbol ?? "");
  const code = normalizeCode(rawCode);
  return {
    code,
    name: String(raw2.name ?? ""),
    price: Number(raw2.price ?? raw2.current ?? 0),
    change: Number(raw2.change ?? 0),
    changePercent: Number(raw2.changePercent ?? raw2.changepercent ?? 0),
    open: num(raw2.open),
    high: num(raw2.high),
    low: num(raw2.low),
    preClose: num(raw2.preClose ?? raw2.yesterdayClose),
    volume: num(raw2.volume),
    amount: num(raw2.amount),
    turnoverRate: num(raw2.turnoverRate),
    pe: num(raw2.pe ?? raw2.peRatio),
    pb: num(raw2.pb),
    marketCap: num(raw2.marketCap),
    ...raw2
  };
}
function num(v2) {
  if (v2 === void 0 || v2 === null || v2 === "")
    return void 0;
  const n = Number(v2);
  return Number.isFinite(n) ? n : void 0;
}
function normalizeCode(code) {
  const c = code.trim().toLowerCase();
  if (/^(sh|sz|bj)\d+$/i.test(c))
    return c;
  if (/^\d{6}$/.test(c)) {
    if (c.startsWith("6") || c.startsWith("5"))
      return `sh${c}`;
    if (c.startsWith("0") || c.startsWith("3"))
      return `sz${c}`;
    if (c.startsWith("4") || c.startsWith("8"))
      return `bj${c}`;
  }
  return c;
}
function marketFromCode(code) {
  if (code.startsWith("sh"))
    return "sh";
  if (code.startsWith("sz"))
    return "sz";
  if (code.startsWith("bj"))
    return "bj";
  return "other";
}

// apps/server/dist/routes/market.js
var marketRoutes = new Hono2();
marketRoutes.get("/overview", async (c) => {
  try {
    const data = await withCache("market:overview", CACHE_TTL.overview, async () => {
      const indicesRaw = await sdk.getSimpleQuotes([...INDEX_CODES]);
      const indices = (Array.isArray(indicesRaw) ? indicesRaw : []).map(normalizeQuote);
      let industryTop = [];
      let conceptTop = [];
      try {
        const industries = await sdk.getIndustryList();
        industryTop = industries.map((item) => ({
          code: item.code,
          name: item.name,
          changePercent: Number(item.changePercent ?? 0),
          price: Number(item.price ?? 0)
        })).sort((a2, b) => b.changePercent - a2.changePercent).slice(0, 10);
      } catch {
      }
      try {
        const concepts = await sdk.getConceptList();
        conceptTop = concepts.map((item) => ({
          code: item.code,
          name: item.name,
          changePercent: Number(item.changePercent ?? 0),
          price: Number(item.price ?? 0)
        })).sort((a2, b) => b.changePercent - a2.changePercent).slice(0, 10);
      } catch {
      }
      let northbound;
      try {
        const summary = await sdk.getNorthboundFlowSummary();
        northbound = summary[0] ?? void 0;
      } catch {
        northbound = void 0;
      }
      let fundFlow;
      try {
        fundFlow = await sdk.getMarketFundFlow();
      } catch {
        fundFlow = void 0;
      }
      let ztPoolCount = 0;
      try {
        const zt2 = await sdk.getZTPool("zt");
        ztPoolCount = Array.isArray(zt2) ? zt2.length : 0;
      } catch {
        ztPoolCount = 0;
      }
      const allQuotes = await loadAllQuotesCached();
      const stats = computeMarketStats(allQuotes);
      const overview = {
        indices,
        stats,
        industryTop,
        conceptTop,
        northbound,
        fundFlow,
        ztPoolCount,
        fetchedAt: (/* @__PURE__ */ new Date()).toISOString()
      };
      return overview;
    });
    return c.json(data);
  } catch (err) {
    return c.json({ error: err instanceof Error ? err.message : "Failed to load overview" }, 500);
  }
});
async function loadAllQuotesCached() {
  return withCache("quotes:all-a", CACHE_TTL.allQuotes, async () => {
    const raw2 = await sdk.getAllAShareQuotes({
      batchSize: 300,
      concurrency: 3
    });
    return (Array.isArray(raw2) ? raw2 : []).map(normalizeQuote);
  });
}
function computeMarketStats(quotes) {
  let up = 0;
  let down = 0;
  let flat = 0;
  let limitUp = 0;
  let limitDown = 0;
  for (const q of quotes) {
    const p = q.changePercent;
    if (p > 0.01)
      up++;
    else if (p < -0.01)
      down++;
    else
      flat++;
    if (p >= 9.9)
      limitUp++;
    if (p <= -9.9)
      limitDown++;
  }
  return { up, down, flat, limitUp, limitDown };
}

// apps/server/dist/routes/quotes.js
var quotesRoutes = new Hono2();
quotesRoutes.get("/", async (c) => {
  const codesParam = c.req.query("codes");
  if (!codesParam) {
    return c.json({ error: "codes query required" }, 400);
  }
  const codes = codesParam.split(",").map(normalizeCode).filter(Boolean);
  try {
    const raw2 = await sdk.getSimpleQuotes(codes);
    const items = (Array.isArray(raw2) ? raw2 : []).map(normalizeQuote);
    return c.json({ items });
  } catch (err) {
    return c.json({ error: err instanceof Error ? err.message : "Failed to fetch quotes" }, 500);
  }
});
quotesRoutes.get("/market", async (c) => {
  const page = Math.max(1, Number(c.req.query("page") ?? 1));
  const pageSize = Math.min(100, Math.max(10, Number(c.req.query("pageSize") ?? 50)));
  const sortBy = c.req.query("sortBy") ?? "changePercent";
  const sortOrder = c.req.query("sortOrder") === "asc" ? "asc" : "desc";
  const minChange = parseOptionalNum(c.req.query("minChange"));
  const maxChange = parseOptionalNum(c.req.query("maxChange"));
  const minAmount = parseOptionalNum(c.req.query("minAmount"));
  const keyword = c.req.query("keyword")?.trim().toLowerCase();
  try {
    let items = await loadAllQuotesCached();
    if (keyword) {
      items = items.filter((q) => q.code.toLowerCase().includes(keyword) || q.name.toLowerCase().includes(keyword));
    }
    if (minChange !== void 0)
      items = items.filter((q) => q.changePercent >= minChange);
    if (maxChange !== void 0)
      items = items.filter((q) => q.changePercent <= maxChange);
    if (minAmount !== void 0) {
      items = items.filter((q) => (q.amount ?? 0) >= minAmount);
    }
    const sortKey = sortBy;
    items.sort((a2, b) => {
      const av = Number(a2[sortKey] ?? 0);
      const bv = Number(b[sortKey] ?? 0);
      return sortOrder === "asc" ? av - bv : bv - av;
    });
    const total = items.length;
    const start = (page - 1) * pageSize;
    const slice = items.slice(start, start + pageSize);
    const result = { items: slice, total, page, pageSize };
    return c.json(result);
  } catch (err) {
    return c.json({ error: err instanceof Error ? err.message : "Failed to load market quotes" }, 500);
  }
});
quotesRoutes.get("/screener", async (c) => {
  const market = c.req.query("market") ?? "all";
  const minChange = parseOptionalNum(c.req.query("minChange"));
  const maxChange = parseOptionalNum(c.req.query("maxChange"));
  const minVolume = parseOptionalNum(c.req.query("minVolume"));
  const minAmount = parseOptionalNum(c.req.query("minAmount"));
  const minTurnover = parseOptionalNum(c.req.query("minTurnover"));
  const maxPE = parseOptionalNum(c.req.query("maxPE"));
  const minPE = parseOptionalNum(c.req.query("minPE"));
  const sortBy = c.req.query("sortBy") ?? "changePercent";
  const sortOrder = c.req.query("sortOrder") === "asc" ? "asc" : "desc";
  const limit = Math.min(200, Math.max(1, Number(c.req.query("limit") ?? 50)));
  try {
    let items = await loadAllQuotesCached();
    if (market !== "all") {
      items = items.filter((q) => {
        const m2 = marketFromCode(q.code);
        if (market === "kc")
          return q.code.startsWith("sh688");
        if (market === "cy")
          return q.code.startsWith("sz300");
        return m2 === market;
      });
    }
    if (minChange !== void 0)
      items = items.filter((q) => q.changePercent >= minChange);
    if (maxChange !== void 0)
      items = items.filter((q) => q.changePercent <= maxChange);
    if (minVolume !== void 0)
      items = items.filter((q) => (q.volume ?? 0) >= minVolume);
    if (minAmount !== void 0)
      items = items.filter((q) => (q.amount ?? 0) >= minAmount);
    if (minTurnover !== void 0) {
      items = items.filter((q) => (q.turnoverRate ?? 0) >= minTurnover);
    }
    if (maxPE !== void 0)
      items = items.filter((q) => (q.pe ?? 9999) <= maxPE);
    if (minPE !== void 0)
      items = items.filter((q) => (q.pe ?? 0) >= minPE);
    const sortKey = sortBy;
    items.sort((a2, b) => {
      const av = Number(a2[sortKey] ?? 0);
      const bv = Number(b[sortKey] ?? 0);
      return sortOrder === "asc" ? av - bv : bv - av;
    });
    return c.json({ items: items.slice(0, limit), total: items.length });
  } catch (err) {
    return c.json({ error: err instanceof Error ? err.message : "Screener failed" }, 500);
  }
});
function parseOptionalNum(v2) {
  if (v2 === void 0 || v2 === "")
    return void 0;
  const n = Number(v2);
  return Number.isFinite(n) ? n : void 0;
}

// apps/server/dist/routes/stock.js
var stockRoutes = new Hono2();
stockRoutes.get("/:code/quote", async (c) => {
  const code = normalizeCode(c.req.param("code"));
  try {
    const raw2 = await sdk.getSimpleQuotes([code]);
    const item = (Array.isArray(raw2) ? raw2 : [])[0];
    if (!item)
      return c.json({ error: "Not found" }, 404);
    return c.json(normalizeQuote(item));
  } catch (err) {
    return c.json({ error: err instanceof Error ? err.message : "Failed to fetch quote" }, 500);
  }
});
stockRoutes.get("/:code/kline", async (c) => {
  const code = normalizeCode(c.req.param("code"));
  const period = c.req.query("period") ?? "daily";
  const adjust = c.req.query("adjust") ?? "qfq";
  const startDate = c.req.query("startDate");
  const endDate = c.req.query("endDate");
  const symbol = code.replace(/^(sh|sz|bj)/i, "");
  const cacheKey = `kline:${code}:${period}:${adjust}:${startDate ?? ""}:${endDate ?? ""}`;
  try {
    const data = await withCache(cacheKey, CACHE_TTL.kline, async () => {
      const options = {
        period,
        adjust: adjust || "qfq",
        indicators: DEFAULT_KLINE_INDICATORS
      };
      if (startDate)
        options.startDate = startDate;
      if (endDate)
        options.endDate = endDate;
      const result = await sdk.getKlineWithIndicators(symbol, options);
      return result;
    });
    return c.json({ code, data });
  } catch (err) {
    return c.json({ error: err instanceof Error ? err.message : "Failed to fetch kline" }, 500);
  }
});
stockRoutes.get("/:code/timeline", async (c) => {
  const code = normalizeCode(c.req.param("code"));
  const symbol = code.replace(/^(sh|sz|bj)/i, "");
  try {
    const data = await sdk.getTodayTimeline(symbol);
    return c.json({ code, data });
  } catch (err) {
    return c.json({ error: err instanceof Error ? err.message : "Failed to fetch timeline" }, 500);
  }
});
stockRoutes.get("/:code/analysis", async (c) => {
  const code = normalizeCode(c.req.param("code"));
  const symbol = code.replace(/^(sh|sz|bj)/i, "");
  try {
    const [fundFlowHistory, northboundHistory, dividends] = await Promise.all([
      sdk.getIndividualFundFlow(symbol).catch(() => []),
      sdk.getNorthboundIndividual(symbol).catch(() => []),
      sdk.getDividendDetail(symbol).catch(() => [])
    ]);
    let fundFlow;
    try {
      const flows = await sdk.getFundFlow([code]);
      fundFlow = flows[0];
    } catch {
      fundFlow = void 0;
    }
    return c.json({
      code,
      fundFlow,
      fundFlowHistory: fundFlowHistory ?? [],
      northboundHistory: northboundHistory ?? [],
      dividends: dividends ?? []
    });
  } catch (err) {
    return c.json({ error: err instanceof Error ? err.message : "Failed to load analysis" }, 500);
  }
});

// apps/server/dist/routes/search.js
var searchRoutes = new Hono2();
searchRoutes.get("/", async (c) => {
  const q = c.req.query("q")?.trim();
  if (!q)
    return c.json({ items: [] });
  try {
    const items = await withCache(`search:${q}`, CACHE_TTL.search, async () => {
      const raw2 = await sdk.search(q);
      const list = Array.isArray(raw2) ? raw2 : [];
      return list.map((item) => ({
        code: normalizeCode(String(item.code ?? "")),
        name: String(item.name ?? ""),
        market: String(item.market ?? "A")
      })).filter((item) => {
        const m2 = (item.market ?? "A").toUpperCase();
        const code = item.code.toLowerCase();
        return m2 === "A" || m2 === "ASHARE" || /^(sh|sz|bj)\d+/.test(code);
      }).slice(0, 20);
    });
    return c.json({ items });
  } catch (err) {
    return c.json({ error: err instanceof Error ? err.message : "Search failed" }, 500);
  }
});

// apps/server/dist/routes/sector.js
var sectorRoutes = new Hono2();
sectorRoutes.get("/industry", async (c) => {
  try {
    const items = await withCache("sector:industry", CACHE_TTL.sector, async () => {
      const raw2 = await sdk.getIndustryList();
      return Array.isArray(raw2) ? raw2 : [];
    });
    return c.json({ items });
  } catch (err) {
    return c.json({ error: err instanceof Error ? err.message : "Failed to load industries" }, 500);
  }
});
sectorRoutes.get("/concept", async (c) => {
  try {
    const items = await withCache("sector:concept", CACHE_TTL.sector, async () => {
      const raw2 = await sdk.getConceptList();
      return Array.isArray(raw2) ? raw2 : [];
    });
    return c.json({ items });
  } catch (err) {
    return c.json({ error: err instanceof Error ? err.message : "Failed to load concepts" }, 500);
  }
});
sectorRoutes.get("/industry/:code/constituents", async (c) => {
  const code = c.req.param("code");
  try {
    const raw2 = await sdk.getIndustryConstituents(code);
    const items = (Array.isArray(raw2) ? raw2 : []).map(normalizeQuote);
    return c.json({ items });
  } catch (err) {
    return c.json({ error: err instanceof Error ? err.message : "Failed to load constituents" }, 500);
  }
});
sectorRoutes.get("/concept/:code/constituents", async (c) => {
  const code = c.req.param("code");
  try {
    const raw2 = await sdk.getConceptConstituents(code);
    const items = (Array.isArray(raw2) ? raw2 : []).map(normalizeQuote);
    return c.json({ items });
  } catch (err) {
    return c.json({ error: err instanceof Error ? err.message : "Failed to load constituents" }, 500);
  }
});

// apps/server/dist/static.js
var import_node_fs = __toESM(require("fs"), 1);
var import_node_path2 = __toESM(require("path"), 1);

// node_modules/hono/dist/utils/mime.js
var getMimeType = (filename, mimes = baseMimes) => {
  const regexp = /\.([a-zA-Z0-9]+?)$/;
  const match2 = filename.match(regexp);
  if (!match2) {
    return;
  }
  return mimes[match2[1].toLowerCase()];
};
var _baseMimes = {
  aac: "audio/aac",
  avi: "video/x-msvideo",
  avif: "image/avif",
  av1: "video/av1",
  bin: "application/octet-stream",
  bmp: "image/bmp",
  css: "text/css; charset=utf-8",
  csv: "text/csv; charset=utf-8",
  eot: "application/vnd.ms-fontobject",
  epub: "application/epub+zip",
  gif: "image/gif",
  gz: "application/gzip",
  htm: "text/html; charset=utf-8",
  html: "text/html; charset=utf-8",
  ico: "image/x-icon",
  ics: "text/calendar; charset=utf-8",
  jpeg: "image/jpeg",
  jpg: "image/jpeg",
  js: "text/javascript; charset=utf-8",
  json: "application/json",
  jsonld: "application/ld+json",
  map: "application/json",
  mid: "audio/x-midi",
  midi: "audio/x-midi",
  mjs: "text/javascript; charset=utf-8",
  mp3: "audio/mpeg",
  mp4: "video/mp4",
  mpeg: "video/mpeg",
  oga: "audio/ogg",
  ogv: "video/ogg",
  ogx: "application/ogg",
  opus: "audio/opus",
  otf: "font/otf",
  pdf: "application/pdf",
  png: "image/png",
  rtf: "application/rtf",
  svg: "image/svg+xml; charset=utf-8",
  tif: "image/tiff",
  tiff: "image/tiff",
  ts: "video/mp2t",
  ttf: "font/ttf",
  txt: "text/plain; charset=utf-8",
  wasm: "application/wasm",
  webm: "video/webm",
  weba: "audio/webm",
  webmanifest: "application/manifest+json",
  webp: "image/webp",
  woff: "font/woff",
  woff2: "font/woff2",
  xhtml: "application/xhtml+xml; charset=utf-8",
  xml: "application/xml; charset=utf-8",
  zip: "application/zip",
  "3gp": "video/3gpp",
  "3g2": "video/3gpp2",
  gltf: "model/gltf+json",
  glb: "model/gltf-binary"
};
var baseMimes = _baseMimes;

// node_modules/@hono/node-server/dist/serve-static.mjs
var import_fs = require("fs");
var import_path = require("path");
var import_process = require("process");
var import_stream = require("stream");
var COMPRESSIBLE_CONTENT_TYPE_REGEX = /^\s*(?:text\/[^;\s]+|application\/(?:javascript|json|xml|xml-dtd|ecmascript|dart|postscript|rtf|tar|toml|vnd\.dart|vnd\.ms-fontobject|vnd\.ms-opentype|wasm|x-httpd-php|x-javascript|x-ns-proxy-autoconfig|x-sh|x-tar|x-virtualbox-hdd|x-virtualbox-ova|x-virtualbox-ovf|x-virtualbox-vbox|x-virtualbox-vdi|x-virtualbox-vhd|x-virtualbox-vmdk|x-www-form-urlencoded)|font\/(?:otf|ttf)|image\/(?:bmp|vnd\.adobe\.photoshop|vnd\.microsoft\.icon|vnd\.ms-dds|x-icon|x-ms-bmp)|message\/rfc822|model\/gltf-binary|x-shader\/x-fragment|x-shader\/x-vertex|[^;\s]+?\+(?:json|text|xml|yaml))(?:[;\s]|$)/i;
var ENCODINGS = {
  br: ".br",
  zstd: ".zst",
  gzip: ".gz"
};
var ENCODINGS_ORDERED_KEYS = Object.keys(ENCODINGS);
var pr54206Applied = () => {
  const [major, minor] = import_process.versions.node.split(".").map((component) => parseInt(component));
  return major >= 23 || major === 22 && minor >= 7 || major === 20 && minor >= 18;
};
var useReadableToWeb = pr54206Applied();
var createStreamBody = (stream) => {
  if (useReadableToWeb) {
    return import_stream.Readable.toWeb(stream);
  }
  const body = new ReadableStream({
    start(controller) {
      stream.on("data", (chunk) => {
        controller.enqueue(chunk);
      });
      stream.on("error", (err) => {
        controller.error(err);
      });
      stream.on("end", () => {
        controller.close();
      });
    },
    cancel() {
      stream.destroy();
    }
  });
  return body;
};
var getStats = (path3) => {
  let stats;
  try {
    stats = (0, import_fs.statSync)(path3);
  } catch {
  }
  return stats;
};
var tryDecode2 = (str, decoder) => {
  try {
    return decoder(str);
  } catch {
    return str.replace(/(?:%[0-9A-Fa-f]{2})+/g, (match2) => {
      try {
        return decoder(match2);
      } catch {
        return match2;
      }
    });
  }
};
var tryDecodeURI2 = (str) => tryDecode2(str, decodeURI);
var serveStatic = (options = { root: "" }) => {
  const root = options.root || "";
  const optionPath = options.path;
  if (root !== "" && !(0, import_fs.existsSync)(root)) {
    console.error(`serveStatic: root path '${root}' is not found, are you sure it's correct?`);
  }
  return async (c, next) => {
    if (c.finalized) {
      return next();
    }
    let filename;
    if (optionPath) {
      filename = optionPath;
    } else {
      try {
        filename = tryDecodeURI2(c.req.path);
        if (/(?:^|[\/\\])\.{1,2}(?:$|[\/\\])|[\/\\]{2,}/.test(filename)) {
          throw new Error();
        }
      } catch {
        await options.onNotFound?.(c.req.path, c);
        return next();
      }
    }
    let path3 = (0, import_path.join)(
      root,
      !optionPath && options.rewriteRequestPath ? options.rewriteRequestPath(filename, c) : filename
    );
    let stats = getStats(path3);
    if (stats && stats.isDirectory()) {
      const indexFile = options.index ?? "index.html";
      path3 = (0, import_path.join)(path3, indexFile);
      stats = getStats(path3);
    }
    if (!stats) {
      await options.onNotFound?.(path3, c);
      return next();
    }
    const mimeType = getMimeType(path3);
    c.header("Content-Type", mimeType || "application/octet-stream");
    if (options.precompressed && (!mimeType || COMPRESSIBLE_CONTENT_TYPE_REGEX.test(mimeType))) {
      const acceptEncodingSet = new Set(
        c.req.header("Accept-Encoding")?.split(",").map((encoding) => encoding.trim())
      );
      for (const encoding of ENCODINGS_ORDERED_KEYS) {
        if (!acceptEncodingSet.has(encoding)) {
          continue;
        }
        const precompressedStats = getStats(path3 + ENCODINGS[encoding]);
        if (precompressedStats) {
          c.header("Content-Encoding", encoding);
          c.header("Vary", "Accept-Encoding", { append: true });
          stats = precompressedStats;
          path3 = path3 + ENCODINGS[encoding];
          break;
        }
      }
    }
    let result;
    const size = stats.size;
    const range = c.req.header("range") || "";
    if (c.req.method == "HEAD" || c.req.method == "OPTIONS") {
      c.header("Content-Length", size.toString());
      c.status(200);
      result = c.body(null);
    } else if (!range) {
      c.header("Content-Length", size.toString());
      result = c.body(createStreamBody((0, import_fs.createReadStream)(path3)), 200);
    } else {
      c.header("Accept-Ranges", "bytes");
      c.header("Date", stats.birthtime.toUTCString());
      const parts = range.replace(/bytes=/, "").split("-", 2);
      const start = parseInt(parts[0], 10) || 0;
      let end = parseInt(parts[1], 10) || size - 1;
      if (size < end - start + 1) {
        end = size - 1;
      }
      const chunksize = end - start + 1;
      const stream = (0, import_fs.createReadStream)(path3, { start, end });
      c.header("Content-Length", chunksize.toString());
      c.header("Content-Range", `bytes ${start}-${end}/${stats.size}`);
      result = c.body(createStreamBody(stream), 206);
    }
    await options.onFound?.(path3, c);
    return result;
  };
};

// apps/server/dist/config.js
var import_node_path = __toESM(require("path"), 1);
var import_node_url = require("url");
var import_meta = {};
var serverDir = import_node_path.default.dirname((0, import_node_url.fileURLToPath)(import_meta.url));
function resolveWebDist() {
  return import_node_path.default.resolve(serverDir, "../../web/dist");
}
function getCorsOrigins() {
  const raw2 = process.env.CORS_ORIGINS;
  if (raw2) {
    return raw2.split(",").map((s) => s.trim()).filter(Boolean);
  }
  return ["http://localhost:5173", "http://127.0.0.1:5173"];
}
function isProduction() {
  return process.env.NODE_ENV === "production";
}

// apps/server/dist/static.js
function registerStatic(app2) {
  const root = resolveWebDist();
  const indexPath = import_node_path2.default.join(root, "index.html");
  if (!import_node_fs.default.existsSync(indexPath)) {
    return false;
  }
  app2.use("/assets/*", serveStatic({ root }));
  app2.use("/*", serveStatic({
    root,
    rewriteRequestPath: (p) => p === "/" ? "/index.html" : p
  }));
  app2.get("*", async (c, next) => {
    if (c.req.path.startsWith("/api"))
      return next();
    return serveStatic({ path: "./index.html", root })(c, next);
  });
  return true;
}

// apps/server/dist/app.js
function createApp(options) {
  const withStatic = options?.withStatic ?? false;
  const app2 = new Hono2();
  app2.use("*", cors({
    origin: getCorsOrigins(),
    allowMethods: ["GET", "OPTIONS"]
  }));
  app2.use("/api/*", authSlot);
  app2.get("/api/health", (c) => c.json({
    ok: true,
    ts: (/* @__PURE__ */ new Date()).toISOString(),
    mode: isProduction() ? "production" : "development"
  }));
  const api = new Hono2();
  api.route("/market", marketRoutes);
  api.route("/quotes", quotesRoutes);
  api.route("/stocks", stockRoutes);
  api.route("/search", searchRoutes);
  api.route("/sector", sectorRoutes);
  app2.route("/api", api);
  const staticOk = withStatic ? registerStatic(app2) : false;
  return { app: app2, staticOk };
}

// netlify/functions/api.ts
var { app } = createApp({ withStatic: false });
function buildApiPath(eventPath) {
  const prefix = "/.netlify/functions/api";
  if (eventPath.startsWith(prefix)) {
    const rest = eventPath.slice(prefix.length) || "";
    return `/api${rest}`;
  }
  if (eventPath.startsWith("/api/")) return eventPath;
  if (eventPath === "/api") return "/api";
  return `/api${eventPath.startsWith("/") ? eventPath : `/${eventPath}`}`;
}
function buildQuery(event) {
  if (event.rawQuery) return event.rawQuery;
  const query = new URLSearchParams();
  for (const [k2, v2] of Object.entries(event.queryStringParameters ?? {})) {
    if (v2 !== void 0) query.set(k2, v2);
  }
  return query.toString();
}
async function handler(event) {
  const method = event.httpMethod || "GET";
  const headers = new Headers();
  for (const [k2, v2] of Object.entries(event.headers ?? {})) {
    if (v2 !== void 0) headers.set(k2, v2);
  }
  const path3 = buildApiPath(event.path);
  const query = buildQuery(event);
  const url = `https://netlify.local${path3}${query ? `?${query}` : ""}`;
  const init = { method, headers };
  if (event.body && method !== "GET" && method !== "HEAD") {
    init.body = event.isBase64Encoded ? Buffer.from(event.body, "base64") : event.body;
  }
  const response = await app.fetch(new Request(url, init));
  const text = await response.text();
  const outHeaders = {};
  response.headers.forEach((value, key) => {
    outHeaders[key] = value;
  });
  return {
    statusCode: response.status,
    headers: outHeaders,
    body: text
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
